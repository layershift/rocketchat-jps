(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var RocketChatTabBar = Package['rocketchat:lib'].RocketChatTabBar;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:authorization":{"lib":{"rocketchat.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/lib/rocketchat.js                                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.authz = {};                                                                                       // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"models":{"Permissions.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/models/Permissions.js                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});
                                                                                                             //
                                                                                                             //
                                                                                                             //
var ModelPermissions = function (_RocketChat$models$_B) {                                                    //
	_inherits(ModelPermissions, _RocketChat$models$_B);                                                         //
                                                                                                             //
	function ModelPermissions() {                                                                               // 2
		_classCallCheck(this, ModelPermissions);                                                                   // 2
                                                                                                             //
		return _possibleConstructorReturn(this, _RocketChat$models$_B.apply(this, arguments));                     // 2
	}                                                                                                           // 4
                                                                                                             //
	// FIND                                                                                                     // 6
                                                                                                             //
                                                                                                             //
	ModelPermissions.prototype.findByRole = function () {                                                       //
		function findByRole(role, options) {                                                                       //
			var query = {                                                                                             // 8
				roles: role                                                                                              // 9
			};                                                                                                        // 8
                                                                                                             //
			return this.find(query, options);                                                                         // 12
		}                                                                                                          // 13
                                                                                                             //
		return findByRole;                                                                                         //
	}();                                                                                                        //
                                                                                                             //
	ModelPermissions.prototype.findOneById = function () {                                                      //
		function findOneById(_id) {                                                                                //
			return this.findOne(_id);                                                                                 // 16
		}                                                                                                          // 17
                                                                                                             //
		return findOneById;                                                                                        //
	}();                                                                                                        //
                                                                                                             //
	ModelPermissions.prototype.createOrUpdate = function () {                                                   //
		function createOrUpdate(name, roles) {                                                                     //
			this.upsert({ _id: name }, { $set: { roles: roles } });                                                   // 20
		}                                                                                                          // 21
                                                                                                             //
		return createOrUpdate;                                                                                     //
	}();                                                                                                        //
                                                                                                             //
	ModelPermissions.prototype.addRole = function () {                                                          //
		function addRole(permission, role) {                                                                       //
			this.update({ _id: permission }, { $addToSet: { roles: role } });                                         // 24
		}                                                                                                          // 25
                                                                                                             //
		return addRole;                                                                                            //
	}();                                                                                                        //
                                                                                                             //
	ModelPermissions.prototype.removeRole = function () {                                                       //
		function removeRole(permission, role) {                                                                    //
			this.update({ _id: permission }, { $pull: { roles: role } });                                             // 28
		}                                                                                                          // 29
                                                                                                             //
		return removeRole;                                                                                         //
	}();                                                                                                        //
                                                                                                             //
	return ModelPermissions;                                                                                    //
}(RocketChat.models._Base);                                                                                  //
                                                                                                             //
RocketChat.models.Permissions = new ModelPermissions('permissions', true);                                   // 32
RocketChat.models.Permissions.cache.load();                                                                  // 33
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"Roles.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/models/Roles.js                                                  //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _possibleConstructorReturn;module.import('babel-runtime/helpers/possibleConstructorReturn',{"default":function(v){_possibleConstructorReturn=v}});var _inherits;module.import('babel-runtime/helpers/inherits',{"default":function(v){_inherits=v}});
                                                                                                             //
                                                                                                             //
                                                                                                             //
var ModelRoles = function (_RocketChat$models$_B) {                                                          //
	_inherits(ModelRoles, _RocketChat$models$_B);                                                               //
                                                                                                             //
	function ModelRoles() {                                                                                     // 2
		_classCallCheck(this, ModelRoles);                                                                         // 2
                                                                                                             //
		var _this = _possibleConstructorReturn(this, _RocketChat$models$_B.apply(this, arguments));                // 2
                                                                                                             //
		_this.tryEnsureIndex({ 'name': 1 });                                                                       // 4
		_this.tryEnsureIndex({ 'scope': 1 });                                                                      // 5
		return _this;                                                                                              // 2
	}                                                                                                           // 6
                                                                                                             //
	ModelRoles.prototype.findUsersInRole = function () {                                                        //
		function findUsersInRole(name, scope, options) {                                                           //
			var role = this.findOne(name);                                                                            // 9
			var roleScope = role && role.scope || 'Users';                                                            // 10
			var model = RocketChat.models[roleScope];                                                                 // 11
                                                                                                             //
			return model && model.findUsersInRoles && model.findUsersInRoles(name, scope, options);                   // 13
		}                                                                                                          // 14
                                                                                                             //
		return findUsersInRole;                                                                                    //
	}();                                                                                                        //
                                                                                                             //
	ModelRoles.prototype.isUserInRoles = function () {                                                          //
		function isUserInRoles(userId, roles, scope) {                                                             //
			var _this2 = this;                                                                                        // 16
                                                                                                             //
			roles = [].concat(roles);                                                                                 // 17
			return roles.some(function (roleName) {                                                                   // 18
				var role = _this2.findOne(roleName);                                                                     // 19
				var roleScope = role && role.scope || 'Users';                                                           // 20
				var model = RocketChat.models[roleScope];                                                                // 21
                                                                                                             //
				return model && model.isUserInRole && model.isUserInRole(userId, roleName, scope);                       // 23
			});                                                                                                       // 24
		}                                                                                                          // 25
                                                                                                             //
		return isUserInRoles;                                                                                      //
	}();                                                                                                        //
                                                                                                             //
	ModelRoles.prototype.createOrUpdate = function () {                                                         //
		function createOrUpdate(name) {                                                                            //
			var scope = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'Users';                  // 27
			var description = arguments[2];                                                                           // 27
			var protectedRole = arguments[3];                                                                         // 27
                                                                                                             //
			var updateData = {};                                                                                      // 28
			updateData.name = name;                                                                                   // 29
			updateData.scope = scope;                                                                                 // 30
                                                                                                             //
			if (description != null) {                                                                                // 32
				updateData.description = description;                                                                    // 33
			}                                                                                                         // 34
                                                                                                             //
			if (protectedRole) {                                                                                      // 36
				updateData['protected'] = protectedRole;                                                                 // 37
			}                                                                                                         // 38
                                                                                                             //
			this.upsert({ _id: name }, { $set: updateData });                                                         // 40
		}                                                                                                          // 41
                                                                                                             //
		return createOrUpdate;                                                                                     //
	}();                                                                                                        //
                                                                                                             //
	ModelRoles.prototype.addUserRoles = function () {                                                           //
		function addUserRoles(userId, roles, scope) {                                                              //
			roles = [].concat(roles);                                                                                 // 44
			for (var _iterator = roles, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
				var _ref;                                                                                                // 45
                                                                                                             //
				if (_isArray) {                                                                                          // 45
					if (_i >= _iterator.length) break;                                                                      // 45
					_ref = _iterator[_i++];                                                                                 // 45
				} else {                                                                                                 // 45
					_i = _iterator.next();                                                                                  // 45
					if (_i.done) break;                                                                                     // 45
					_ref = _i.value;                                                                                        // 45
				}                                                                                                        // 45
                                                                                                             //
				var roleName = _ref;                                                                                     // 45
                                                                                                             //
				var role = this.findOne(roleName);                                                                       // 46
				var roleScope = role && role.scope || 'Users';                                                           // 47
				var model = RocketChat.models[roleScope];                                                                // 48
                                                                                                             //
				return model && model.addRolesByUserId && model.addRolesByUserId(userId, roleName, scope);               // 50
			}                                                                                                         // 51
		}                                                                                                          // 52
                                                                                                             //
		return addUserRoles;                                                                                       //
	}();                                                                                                        //
                                                                                                             //
	ModelRoles.prototype.removeUserRoles = function () {                                                        //
		function removeUserRoles(userId, roles, scope) {                                                           //
			roles = [].concat(roles);                                                                                 // 55
			for (var _iterator2 = roles, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
				var _ref2;                                                                                               // 56
                                                                                                             //
				if (_isArray2) {                                                                                         // 56
					if (_i2 >= _iterator2.length) break;                                                                    // 56
					_ref2 = _iterator2[_i2++];                                                                              // 56
				} else {                                                                                                 // 56
					_i2 = _iterator2.next();                                                                                // 56
					if (_i2.done) break;                                                                                    // 56
					_ref2 = _i2.value;                                                                                      // 56
				}                                                                                                        // 56
                                                                                                             //
				var roleName = _ref2;                                                                                    // 56
                                                                                                             //
				var role = this.findOne(roleName);                                                                       // 57
				var roleScope = role && role.scope || 'Users';                                                           // 58
				var model = RocketChat.models[roleScope];                                                                // 59
                                                                                                             //
				return model && model.removeRolesByUserId && model.removeRolesByUserId(userId, roleName, scope);         // 61
			}                                                                                                         // 62
		}                                                                                                          // 63
                                                                                                             //
		return removeUserRoles;                                                                                    //
	}();                                                                                                        //
                                                                                                             //
	return ModelRoles;                                                                                          //
}(RocketChat.models._Base);                                                                                  //
                                                                                                             //
RocketChat.models.Roles = new ModelRoles('roles', true);                                                     // 66
RocketChat.models.Roles.cache.load();                                                                        // 67
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"Base.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/models/Base.js                                                   //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.models._Base.prototype.roleBaseQuery = function () /*userId, scope*/{                             // 1
	return;                                                                                                     // 2
};                                                                                                           // 3
                                                                                                             //
RocketChat.models._Base.prototype.findRolesByUserId = function (userId /*, options*/) {                      // 5
	var query = this.roleBaseQuery(userId);                                                                     // 6
	return this.find(query, { fields: { roles: 1 } });                                                          // 7
};                                                                                                           // 8
                                                                                                             //
RocketChat.models._Base.prototype.isUserInRole = function (userId, roleName, scope) {                        // 10
	var query = this.roleBaseQuery(userId, scope);                                                              // 11
                                                                                                             //
	if (query == null) {                                                                                        // 13
		return false;                                                                                              // 14
	}                                                                                                           // 15
                                                                                                             //
	query.roles = roleName;                                                                                     // 17
	return !_.isUndefined(this.findOne(query));                                                                 // 18
};                                                                                                           // 19
                                                                                                             //
RocketChat.models._Base.prototype.addRolesByUserId = function (userId, roles, scope) {                       // 21
	roles = [].concat(roles);                                                                                   // 22
	var query = this.roleBaseQuery(userId, scope);                                                              // 23
	var update = {                                                                                              // 24
		$addToSet: {                                                                                               // 25
			roles: { $each: roles }                                                                                   // 26
		}                                                                                                          // 25
	};                                                                                                          // 24
	return this.update(query, update);                                                                          // 29
};                                                                                                           // 30
                                                                                                             //
RocketChat.models._Base.prototype.removeRolesByUserId = function (userId, roles, scope) {                    // 32
	roles = [].concat(roles);                                                                                   // 33
	var query = this.roleBaseQuery(userId, scope);                                                              // 34
	var update = {                                                                                              // 35
		$pullAll: {                                                                                                // 36
			roles: roles                                                                                              // 37
		}                                                                                                          // 36
	};                                                                                                          // 35
	return this.update(query, update);                                                                          // 40
};                                                                                                           // 41
                                                                                                             //
RocketChat.models._Base.prototype.findUsersInRoles = function () {                                           // 43
	throw new Meteor.Error('overwrite-function', 'You must overwrite this function in the extended classes');   // 44
};                                                                                                           // 45
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Users.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/models/Users.js                                                  //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.models.Users.roleBaseQuery = function (userId) {                                                  // 1
	return { _id: userId };                                                                                     // 2
};                                                                                                           // 3
                                                                                                             //
RocketChat.models.Users.findUsersInRoles = function (roles, scope, options) {                                // 5
	roles = [].concat(roles);                                                                                   // 6
                                                                                                             //
	var query = {                                                                                               // 8
		roles: { $in: roles }                                                                                      // 9
	};                                                                                                          // 8
                                                                                                             //
	return this.find(query, options);                                                                           // 12
};                                                                                                           // 13
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"Subscriptions.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/models/Subscriptions.js                                          //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.models.Subscriptions.roleBaseQuery = function (userId, scope) {                                   // 1
	if (scope == null) {                                                                                        // 2
		return;                                                                                                    // 3
	}                                                                                                           // 4
                                                                                                             //
	var query = { 'u._id': userId };                                                                            // 6
	if (!_.isUndefined(scope)) {                                                                                // 7
		query.rid = scope;                                                                                         // 8
	}                                                                                                           // 9
	return query;                                                                                               // 10
};                                                                                                           // 11
                                                                                                             //
RocketChat.models.Subscriptions.findUsersInRoles = function (roles, scope, options) {                        // 13
	roles = [].concat(roles);                                                                                   // 14
                                                                                                             //
	var query = {                                                                                               // 16
		roles: { $in: roles }                                                                                      // 17
	};                                                                                                          // 16
                                                                                                             //
	if (scope) {                                                                                                // 20
		query.rid = scope;                                                                                         // 21
	}                                                                                                           // 22
                                                                                                             //
	var subscriptions = this.find(query).fetch();                                                               // 24
                                                                                                             //
	var users = _.compact(_.map(subscriptions, function (subscription) {                                        // 26
		if ('undefined' !== typeof subscription.u && 'undefined' !== typeof subscription.u._id) {                  // 27
			return subscription.u._id;                                                                                // 28
		}                                                                                                          // 29
	}));                                                                                                        // 30
                                                                                                             //
	return RocketChat.models.Users.find({ _id: { $in: users } }, options);                                      // 32
};                                                                                                           // 33
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"functions":{"addUserRoles.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/functions/addUserRoles.js                                        //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.authz.addUserRoles = function (userId, roleNames, scope) {                                        // 1
	if (!userId || !roleNames) {                                                                                // 2
		return false;                                                                                              // 3
	}                                                                                                           // 4
                                                                                                             //
	var user = RocketChat.models.Users.db.findOneById(userId);                                                  // 6
	if (!user) {                                                                                                // 7
		throw new Meteor.Error('error-invalid-user', 'Invalid user', {                                             // 8
			'function': 'RocketChat.authz.addUserRoles'                                                               // 9
		});                                                                                                        // 8
	}                                                                                                           // 11
                                                                                                             //
	roleNames = [].concat(roleNames);                                                                           // 13
	var existingRoleNames = _.pluck(RocketChat.authz.getRoles(), '_id');                                        // 14
	var invalidRoleNames = _.difference(roleNames, existingRoleNames);                                          // 15
                                                                                                             //
	if (!_.isEmpty(invalidRoleNames)) {                                                                         // 17
		for (var _iterator = invalidRoleNames, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
			var _ref;                                                                                                 // 18
                                                                                                             //
			if (_isArray) {                                                                                           // 18
				if (_i >= _iterator.length) break;                                                                       // 18
				_ref = _iterator[_i++];                                                                                  // 18
			} else {                                                                                                  // 18
				_i = _iterator.next();                                                                                   // 18
				if (_i.done) break;                                                                                      // 18
				_ref = _i.value;                                                                                         // 18
			}                                                                                                         // 18
                                                                                                             //
			var role = _ref;                                                                                          // 18
                                                                                                             //
			RocketChat.models.Roles.createOrUpdate(role);                                                             // 19
		}                                                                                                          // 20
	}                                                                                                           // 21
                                                                                                             //
	RocketChat.models.Roles.addUserRoles(userId, roleNames, scope);                                             // 23
                                                                                                             //
	return true;                                                                                                // 25
};                                                                                                           // 26
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"canAccessRoom.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/functions/canAccessRoom.js                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/* globals RocketChat */                                                                                     // 1
RocketChat.authz.roomAccessValidators = [function (room, user) {                                             // 2
	var subscription = RocketChat.models.Subscriptions.findOneByRoomIdAndUserId(room._id, user._id);            // 4
	if (subscription) {                                                                                         // 5
		return subscription._room;                                                                                 // 6
	}                                                                                                           // 7
}, function (room, user) {                                                                                   // 8
	if (room.t === 'c') {                                                                                       // 10
		return RocketChat.authz.hasPermission(user._id, 'view-c-room');                                            // 11
	}                                                                                                           // 12
}];                                                                                                          // 13
                                                                                                             //
RocketChat.authz.canAccessRoom = function (room, user) {                                                     // 16
	var _this = this;                                                                                           // 16
                                                                                                             //
	return RocketChat.authz.roomAccessValidators.some(function (validator) {                                    // 17
		return validator.call(_this, room, user);                                                                  // 18
	});                                                                                                         // 19
};                                                                                                           // 20
                                                                                                             //
RocketChat.authz.addRoomAccessValidator = function (validator) {                                             // 22
	RocketChat.authz.roomAccessValidators.push(validator);                                                      // 23
};                                                                                                           // 24
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"getRoles.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/functions/getRoles.js                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.authz.getRoles = function () {                                                                    // 1
	return RocketChat.models.Roles.find().fetch();                                                              // 2
};                                                                                                           // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"getUsersInRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/functions/getUsersInRole.js                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.authz.getUsersInRole = function (roleName, scope, options) {                                      // 1
	return RocketChat.models.Roles.findUsersInRole(roleName, scope, options);                                   // 2
};                                                                                                           // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hasPermission.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/functions/hasPermission.js                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
function atLeastOne(userId) {                                                                                // 1
	var permissions = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];                   // 1
	var scope = arguments[2];                                                                                   // 1
                                                                                                             //
	return permissions.some(function (permissionId) {                                                           // 2
		var permission = RocketChat.models.Permissions.findOne(permissionId);                                      // 3
		return RocketChat.models.Roles.isUserInRoles(userId, permission.roles, scope);                             // 4
	});                                                                                                         // 5
}                                                                                                            // 6
                                                                                                             //
function all(userId) {                                                                                       // 8
	var permissions = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];                   // 8
	var scope = arguments[2];                                                                                   // 8
                                                                                                             //
	return permissions.every(function (permissionId) {                                                          // 9
		var permission = RocketChat.models.Permissions.findOne(permissionId);                                      // 10
		return RocketChat.models.Roles.isUserInRoles(userId, permission.roles, scope);                             // 11
	});                                                                                                         // 12
}                                                                                                            // 13
                                                                                                             //
function hasPermission(userId, permissions, scope, strategy) {                                               // 15
	if (!userId) {                                                                                              // 16
		return false;                                                                                              // 17
	}                                                                                                           // 18
                                                                                                             //
	permissions = [].concat(permissions);                                                                       // 20
	return strategy(userId, permissions, scope);                                                                // 21
}                                                                                                            // 22
                                                                                                             //
RocketChat.authz.hasAllPermission = function (userId, permissions, scope) {                                  // 24
	return hasPermission(userId, permissions, scope, all);                                                      // 25
};                                                                                                           // 26
                                                                                                             //
RocketChat.authz.hasPermission = RocketChat.authz.hasAllPermission;                                          // 28
                                                                                                             //
RocketChat.authz.hasAtLeastOnePermission = function (userId, permissions, scope) {                           // 30
	return hasPermission(userId, permissions, scope, atLeastOne);                                               // 31
};                                                                                                           // 32
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"hasRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/functions/hasRole.js                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.authz.hasRole = function (userId, roleNames, scope) {                                             // 1
	roleNames = [].concat(roleNames);                                                                           // 2
	return RocketChat.models.Roles.isUserInRoles(userId, roleNames, scope);                                     // 3
};                                                                                                           // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"removeUserFromRoles.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/functions/removeUserFromRoles.js                                 //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
RocketChat.authz.removeUserFromRoles = function (userId, roleNames, scope) {                                 // 1
	if (!userId || !roleNames) {                                                                                // 2
		return false;                                                                                              // 3
	}                                                                                                           // 4
                                                                                                             //
	var user = RocketChat.models.Users.findOneById(userId);                                                     // 6
                                                                                                             //
	if (!user) {                                                                                                // 8
		throw new Meteor.Error('error-invalid-user', 'Invalid user', {                                             // 9
			'function': 'RocketChat.authz.removeUserFromRoles'                                                        // 10
		});                                                                                                        // 9
	}                                                                                                           // 12
                                                                                                             //
	roleNames = [].concat(roleNames);                                                                           // 14
	var existingRoleNames = _.pluck(RocketChat.authz.getRoles(), '_id');                                        // 15
	var invalidRoleNames = _.difference(roleNames, existingRoleNames);                                          // 16
                                                                                                             //
	if (!_.isEmpty(invalidRoleNames)) {                                                                         // 18
		throw new Meteor.Error('error-invalid-role', 'Invalid role', {                                             // 19
			'function': 'RocketChat.authz.removeUserFromRoles'                                                        // 20
		});                                                                                                        // 19
	}                                                                                                           // 22
                                                                                                             //
	RocketChat.models.Roles.removeUserRoles(userId, roleNames, scope);                                          // 24
                                                                                                             //
	return true;                                                                                                // 26
};                                                                                                           // 27
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"permissions.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/publications/permissions.js                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.methods({                                                                                             // 1
	'permissions/get': function () {                                                                            // 2
		function permissionsGet(updatedAt) {                                                                       // 1
			this.unblock();                                                                                           // 3
                                                                                                             //
			var records = RocketChat.models.Permissions.find().fetch();                                               // 5
                                                                                                             //
			if (updatedAt instanceof Date) {                                                                          // 7
				return {                                                                                                 // 8
					update: records.filter(function (record) {                                                              // 9
						return record._updatedAt > updatedAt;                                                                  // 10
					}),                                                                                                     // 11
					remove: RocketChat.models.Permissions.trashFindDeletedAfter(updatedAt, {}, { fields: { _id: 1, _deletedAt: 1 } }).fetch()
				};                                                                                                       // 8
			}                                                                                                         // 14
                                                                                                             //
			return records;                                                                                           // 16
		}                                                                                                          // 17
                                                                                                             //
		return permissionsGet;                                                                                     // 1
	}()                                                                                                         // 1
});                                                                                                          // 1
                                                                                                             //
RocketChat.models.Permissions.on('changed', function (type, permission) {                                    // 21
	RocketChat.Notifications.notifyLoggedInThisInstance('permissions-changed', type, permission);               // 22
});                                                                                                          // 23
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"roles.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/publications/roles.js                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.publish('roles', function () {                                                                        // 1
	if (!this.userId) {                                                                                         // 2
		return this.ready();                                                                                       // 3
	}                                                                                                           // 4
                                                                                                             //
	return RocketChat.models.Roles.find();                                                                      // 6
});                                                                                                          // 7
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"usersInRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/publications/usersInRole.js                                      //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.publish('usersInRole', function (roleName, scope) {                                                   // 1
	var limit = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 50;                         // 1
                                                                                                             //
	if (!this.userId) {                                                                                         // 2
		return this.ready();                                                                                       // 3
	}                                                                                                           // 4
                                                                                                             //
	if (!RocketChat.authz.hasPermission(this.userId, 'access-permissions')) {                                   // 6
		return this.error(new Meteor.Error('error-not-allowed', 'Not allowed', {                                   // 7
			publish: 'usersInRole'                                                                                    // 8
		}));                                                                                                       // 7
	}                                                                                                           // 10
                                                                                                             //
	var options = {                                                                                             // 12
		limit: limit,                                                                                              // 13
		sort: {                                                                                                    // 14
			name: 1                                                                                                   // 15
		}                                                                                                          // 14
	};                                                                                                          // 12
                                                                                                             //
	return RocketChat.authz.getUsersInRole(roleName, scope, options);                                           // 19
});                                                                                                          // 20
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"addUserToRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/methods/addUserToRole.js                                         //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.methods({                                                                                             // 1
	'authorization:addUserToRole': function () {                                                                // 2
		function authorizationAddUserToRole(roleName, username, scope) {                                           // 1
			if (!Meteor.userId() || !RocketChat.authz.hasPermission(Meteor.userId(), 'access-permissions')) {         // 3
				throw new Meteor.Error('error-action-not-allowed', 'Accessing permissions is not allowed', {             // 4
					method: 'authorization:addUserToRole',                                                                  // 5
					action: 'Accessing_permissions'                                                                         // 6
				});                                                                                                      // 4
			}                                                                                                         // 8
                                                                                                             //
			if (!roleName || !_.isString(roleName) || !username || !_.isString(username)) {                           // 10
				throw new Meteor.Error('error-invalid-arguments', 'Invalid arguments', {                                 // 11
					method: 'authorization:addUserToRole'                                                                   // 12
				});                                                                                                      // 11
			}                                                                                                         // 14
                                                                                                             //
			if (roleName === 'admin' && !RocketChat.authz.hasPermission(Meteor.userId(), 'assign-admin-role')) {      // 16
				throw new Meteor.Error('error-action-not-allowed', 'Assigning admin is not allowed', {                   // 17
					method: 'insertOrUpdateUser',                                                                           // 18
					action: 'Assign_admin'                                                                                  // 19
				});                                                                                                      // 17
			}                                                                                                         // 21
                                                                                                             //
			var user = RocketChat.models.Users.findOneByUsername(username, {                                          // 23
				fields: {                                                                                                // 24
					_id: 1                                                                                                  // 25
				}                                                                                                        // 24
			});                                                                                                       // 23
                                                                                                             //
			if (!user || !user._id) {                                                                                 // 29
				throw new Meteor.Error('error-invalid-user', 'Invalid user', {                                           // 30
					method: 'authorization:addUserToRole'                                                                   // 31
				});                                                                                                      // 30
			}                                                                                                         // 33
                                                                                                             //
			var add = RocketChat.models.Roles.addUserRoles(user._id, roleName, scope);                                // 35
                                                                                                             //
			if (RocketChat.settings.get('UI_DisplayRoles')) {                                                         // 37
				RocketChat.Notifications.notifyLogged('roles-change', {                                                  // 38
					type: 'added',                                                                                          // 39
					_id: roleName,                                                                                          // 40
					u: {                                                                                                    // 41
						_id: user._id,                                                                                         // 42
						username: username                                                                                     // 43
					},                                                                                                      // 41
					scope: scope                                                                                            // 45
				});                                                                                                      // 38
			}                                                                                                         // 47
                                                                                                             //
			return add;                                                                                               // 49
		}                                                                                                          // 50
                                                                                                             //
		return authorizationAddUserToRole;                                                                         // 1
	}()                                                                                                         // 1
});                                                                                                          // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"deleteRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/methods/deleteRole.js                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.methods({                                                                                             // 1
	'authorization:deleteRole': function () {                                                                   // 2
		function authorizationDeleteRole(roleName) {                                                               // 1
			if (!Meteor.userId() || !RocketChat.authz.hasPermission(Meteor.userId(), 'access-permissions')) {         // 3
				throw new Meteor.Error('error-action-not-allowed', 'Accessing permissions is not allowed', {             // 4
					method: 'authorization:deleteRole',                                                                     // 5
					action: 'Accessing_permissions'                                                                         // 6
				});                                                                                                      // 4
			}                                                                                                         // 8
                                                                                                             //
			var role = RocketChat.models.Roles.findOne(roleName);                                                     // 10
			if (!role) {                                                                                              // 11
				throw new Meteor.Error('error-invalid-role', 'Invalid role', {                                           // 12
					method: 'authorization:deleteRole'                                                                      // 13
				});                                                                                                      // 12
			}                                                                                                         // 15
                                                                                                             //
			if (role['protected']) {                                                                                  // 17
				throw new Meteor.Error('error-delete-protected-role', 'Cannot delete a protected role', {                // 18
					method: 'authorization:deleteRole'                                                                      // 19
				});                                                                                                      // 18
			}                                                                                                         // 21
                                                                                                             //
			var roleScope = role.scope || 'Users';                                                                    // 23
			var model = RocketChat.models[roleScope];                                                                 // 24
			var existingUsers = model && model.findUsersInRoles && model.findUsersInRoles(roleName);                  // 25
                                                                                                             //
			if (existingUsers && existingUsers.count() > 0) {                                                         // 27
				throw new Meteor.Error('error-role-in-use', 'Cannot delete role because it\'s in use', {                 // 28
					method: 'authorization:deleteRole'                                                                      // 29
				});                                                                                                      // 28
			}                                                                                                         // 31
                                                                                                             //
			return RocketChat.models.Roles.remove(role.name);                                                         // 33
		}                                                                                                          // 34
                                                                                                             //
		return authorizationDeleteRole;                                                                            // 1
	}()                                                                                                         // 1
});                                                                                                          // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"removeUserFromRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/methods/removeUserFromRole.js                                    //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.methods({                                                                                             // 1
	'authorization:removeUserFromRole': function () {                                                           // 2
		function authorizationRemoveUserFromRole(roleName, username, scope) {                                      // 1
			if (!Meteor.userId() || !RocketChat.authz.hasPermission(Meteor.userId(), 'access-permissions')) {         // 3
				throw new Meteor.Error('error-action-not-allowed', 'Access permissions is not allowed', {                // 4
					method: 'authorization:removeUserFromRole',                                                             // 5
					action: 'Accessing_permissions'                                                                         // 6
				});                                                                                                      // 4
			}                                                                                                         // 8
                                                                                                             //
			if (!roleName || !_.isString(roleName) || !username || !_.isString(username)) {                           // 10
				throw new Meteor.Error('error-invalid-arguments', 'Invalid arguments', {                                 // 11
					method: 'authorization:removeUserFromRole'                                                              // 12
				});                                                                                                      // 11
			}                                                                                                         // 14
                                                                                                             //
			var user = Meteor.users.findOne({                                                                         // 16
				username: username                                                                                       // 17
			}, {                                                                                                      // 16
				fields: {                                                                                                // 19
					_id: 1,                                                                                                 // 20
					roles: 1                                                                                                // 21
				}                                                                                                        // 19
			});                                                                                                       // 18
                                                                                                             //
			if (!user || !user._id) {                                                                                 // 25
				throw new Meteor.Error('error-invalid-user', 'Invalid user', {                                           // 26
					method: 'authorization:removeUserFromRole'                                                              // 27
				});                                                                                                      // 26
			}                                                                                                         // 29
                                                                                                             //
			// prevent removing last user from admin role                                                             // 31
			if (roleName === 'admin') {                                                                               // 32
				var adminCount = Meteor.users.find({                                                                     // 33
					roles: {                                                                                                // 34
						$in: ['admin']                                                                                         // 35
					}                                                                                                       // 34
				}).count();                                                                                              // 33
                                                                                                             //
				var userIsAdmin = user.roles.indexOf('admin') > -1;                                                      // 39
				if (adminCount === 1 && userIsAdmin) {                                                                   // 40
					throw new Meteor.Error('error-action-not-allowed', 'Leaving the app without admins is not allowed', {   // 41
						method: 'removeUserFromRole',                                                                          // 42
						action: 'Remove_last_admin'                                                                            // 43
					});                                                                                                     // 41
				}                                                                                                        // 45
			}                                                                                                         // 46
                                                                                                             //
			var remove = RocketChat.models.Roles.removeUserRoles(user._id, roleName, scope);                          // 48
			if (RocketChat.settings.get('UI_DisplayRoles')) {                                                         // 49
				RocketChat.Notifications.notifyLogged('roles-change', {                                                  // 50
					type: 'removed',                                                                                        // 51
					_id: roleName,                                                                                          // 52
					u: {                                                                                                    // 53
						_id: user._id,                                                                                         // 54
						username: username                                                                                     // 55
					},                                                                                                      // 53
					scope: scope                                                                                            // 57
				});                                                                                                      // 50
			}                                                                                                         // 59
                                                                                                             //
			return remove;                                                                                            // 61
		}                                                                                                          // 62
                                                                                                             //
		return authorizationRemoveUserFromRole;                                                                    // 1
	}()                                                                                                         // 1
});                                                                                                          // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"saveRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/methods/saveRole.js                                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.methods({                                                                                             // 1
	'authorization:saveRole': function () {                                                                     // 2
		function authorizationSaveRole(roleData) {                                                                 // 1
			if (!Meteor.userId() || !RocketChat.authz.hasPermission(Meteor.userId(), 'access-permissions')) {         // 3
				throw new Meteor.Error('error-action-not-allowed', 'Accessing permissions is not allowed', {             // 4
					method: 'authorization:saveRole',                                                                       // 5
					action: 'Accessing_permissions'                                                                         // 6
				});                                                                                                      // 4
			}                                                                                                         // 8
                                                                                                             //
			if (!roleData.name) {                                                                                     // 10
				throw new Meteor.Error('error-role-name-required', 'Role name is required', {                            // 11
					method: 'authorization:saveRole'                                                                        // 12
				});                                                                                                      // 11
			}                                                                                                         // 14
                                                                                                             //
			if (['Users', 'Subscriptions'].includes(roleData.scope) === false) {                                      // 16
				roleData.scope = 'Users';                                                                                // 17
			}                                                                                                         // 18
                                                                                                             //
			var update = RocketChat.models.Roles.createOrUpdate(roleData.name, roleData.scope, roleData.description);
			if (RocketChat.settings.get('UI_DisplayRoles')) {                                                         // 21
				RocketChat.Notifications.notifyLogged('roles-change', {                                                  // 22
					type: 'changed',                                                                                        // 23
					_id: roleData.name                                                                                      // 24
				});                                                                                                      // 22
			}                                                                                                         // 26
                                                                                                             //
			return update;                                                                                            // 28
		}                                                                                                          // 29
                                                                                                             //
		return authorizationSaveRole;                                                                              // 1
	}()                                                                                                         // 1
});                                                                                                          // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"addPermissionToRole.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/methods/addPermissionToRole.js                                   //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.methods({                                                                                             // 1
	'authorization:addPermissionToRole': function () {                                                          // 2
		function authorizationAddPermissionToRole(permission, role) {                                              // 1
			if (!Meteor.userId() || !RocketChat.authz.hasPermission(Meteor.userId(), 'access-permissions')) {         // 3
				throw new Meteor.Error('error-action-not-allowed', 'Adding permission is not allowed', {                 // 4
					method: 'authorization:addPermissionToRole',                                                            // 5
					action: 'Adding_permission'                                                                             // 6
				});                                                                                                      // 4
			}                                                                                                         // 8
                                                                                                             //
			return RocketChat.models.Permissions.addRole(permission, role);                                           // 10
		}                                                                                                          // 11
                                                                                                             //
		return authorizationAddPermissionToRole;                                                                   // 1
	}()                                                                                                         // 1
});                                                                                                          // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"removeRoleFromPermission.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/methods/removeRoleFromPermission.js                              //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
Meteor.methods({                                                                                             // 1
	'authorization:removeRoleFromPermission': function () {                                                     // 2
		function authorizationRemoveRoleFromPermission(permission, role) {                                         // 1
			if (!Meteor.userId() || !RocketChat.authz.hasPermission(Meteor.userId(), 'access-permissions')) {         // 3
				throw new Meteor.Error('error-action-not-allowed', 'Accessing permissions is not allowed', {             // 4
					method: 'authorization:removeRoleFromPermission',                                                       // 5
					action: 'Accessing_permissions'                                                                         // 6
				});                                                                                                      // 4
			}                                                                                                         // 8
                                                                                                             //
			return RocketChat.models.Permissions.removeRole(permission, role);                                        // 10
		}                                                                                                          // 11
                                                                                                             //
		return authorizationRemoveRoleFromPermission;                                                              // 1
	}()                                                                                                         // 1
});                                                                                                          // 1
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"startup.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/rocketchat_authorization/server/startup.js                                                       //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
/* eslint no-multi-spaces: 0 */                                                                              // 1
                                                                                                             //
Meteor.startup(function () {                                                                                 // 3
	// Note:                                                                                                    // 4
	// 1.if we need to create a role that can only edit channel message, but not edit group message             // 5
	// then we can define edit-<type>-message instead of edit-message                                           // 6
	// 2. admin, moderator, and user roles should not be deleted as they are referened in the code.             // 7
	var permissions = [{ _id: 'access-permissions', roles: ['admin'] }, { _id: 'add-oauth-service', roles: ['admin'] }, { _id: 'add-user-to-joined-room', roles: ['admin', 'owner', 'moderator'] }, { _id: 'add-user-to-any-c-room', roles: ['admin'] }, { _id: 'add-user-to-any-p-room', roles: [] }, { _id: 'archive-room', roles: ['admin', 'owner'] }, { _id: 'assign-admin-role', roles: ['admin'] }, { _id: 'ban-user', roles: ['admin', 'owner', 'moderator'] }, { _id: 'bulk-create-c', roles: ['admin'] }, { _id: 'bulk-register-user', roles: ['admin'] }, { _id: 'create-c', roles: ['admin', 'user', 'bot'] }, { _id: 'create-d', roles: ['admin', 'user', 'bot'] }, { _id: 'create-p', roles: ['admin', 'user', 'bot'] }, { _id: 'create-user', roles: ['admin'] }, { _id: 'clean-channel-history', roles: ['admin'] }, // special permission to bulk delete a channel's mesages
	{ _id: 'delete-c', roles: ['admin'] }, { _id: 'delete-d', roles: ['admin'] }, { _id: 'delete-message', roles: ['admin', 'owner', 'moderator'] }, { _id: 'delete-p', roles: ['admin'] }, { _id: 'delete-user', roles: ['admin'] }, { _id: 'edit-message', roles: ['admin', 'owner', 'moderator'] }, { _id: 'edit-other-user-active-status', roles: ['admin'] }, { _id: 'edit-other-user-info', roles: ['admin'] }, { _id: 'edit-other-user-password', roles: ['admin'] }, { _id: 'edit-privileged-setting', roles: ['admin'] }, { _id: 'edit-room', roles: ['admin', 'owner', 'moderator'] }, { _id: 'manage-assets', roles: ['admin'] }, { _id: 'manage-emoji', roles: ['admin'] }, { _id: 'manage-integrations', roles: ['admin'] }, { _id: 'manage-own-integrations', roles: ['admin', 'bot'] }, { _id: 'manage-oauth-apps', roles: ['admin'] }, { _id: 'mention-all', roles: ['admin', 'owner', 'moderator', 'user'] }, { _id: 'mute-user', roles: ['admin', 'owner', 'moderator'] }, { _id: 'remove-user', roles: ['admin', 'owner', 'moderator'] }, { _id: 'run-import', roles: ['admin'] }, { _id: 'run-migration', roles: ['admin'] }, { _id: 'set-moderator', roles: ['admin', 'owner'] }, { _id: 'set-owner', roles: ['admin', 'owner'] }, { _id: 'unarchive-room', roles: ['admin'] }, { _id: 'view-c-room', roles: ['admin', 'user', 'bot'] }, { _id: 'view-d-room', roles: ['admin', 'user', 'bot'] }, { _id: 'view-full-other-user-info', roles: ['admin'] }, { _id: 'view-history', roles: ['admin', 'user'] }, { _id: 'view-joined-room', roles: ['guest', 'bot'] }, { _id: 'view-join-code', roles: ['admin'] }, { _id: 'view-logs', roles: ['admin'] }, { _id: 'view-other-user-channels', roles: ['admin'] }, { _id: 'view-p-room', roles: ['admin', 'user'] }, { _id: 'view-privileged-setting', roles: ['admin'] }, { _id: 'view-room-administration', roles: ['admin'] }, { _id: 'view-statistics', roles: ['admin'] }, { _id: 'view-user-administration', roles: ['admin'] }, { _id: 'preview-c-room', roles: ['admin', 'user'] }];
                                                                                                             //
	for (var _iterator = permissions, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
		var _ref;                                                                                                  // 64
                                                                                                             //
		if (_isArray) {                                                                                            // 64
			if (_i >= _iterator.length) break;                                                                        // 64
			_ref = _iterator[_i++];                                                                                   // 64
		} else {                                                                                                   // 64
			_i = _iterator.next();                                                                                    // 64
			if (_i.done) break;                                                                                       // 64
			_ref = _i.value;                                                                                          // 64
		}                                                                                                          // 64
                                                                                                             //
		var permission = _ref;                                                                                     // 64
                                                                                                             //
		if (!RocketChat.models.Permissions.findOneById(permission._id)) {                                          // 65
			RocketChat.models.Permissions.upsert(permission._id, { $set: permission });                               // 66
		}                                                                                                          // 67
	}                                                                                                           // 68
                                                                                                             //
	var defaultRoles = [{ name: 'admin', scope: 'Users', description: 'Admin' }, { name: 'moderator', scope: 'Subscriptions', description: 'Moderator' }, { name: 'owner', scope: 'Subscriptions', description: 'Owner' }, { name: 'user', scope: 'Users', description: '' }, { name: 'bot', scope: 'Users', description: '' }, { name: 'guest', scope: 'Users', description: '' }];
                                                                                                             //
	for (var _iterator2 = defaultRoles, _isArray2 = Array.isArray(_iterator2), _i2 = 0, _iterator2 = _isArray2 ? _iterator2 : _iterator2[Symbol.iterator]();;) {
		var _ref2;                                                                                                 // 79
                                                                                                             //
		if (_isArray2) {                                                                                           // 79
			if (_i2 >= _iterator2.length) break;                                                                      // 79
			_ref2 = _iterator2[_i2++];                                                                                // 79
		} else {                                                                                                   // 79
			_i2 = _iterator2.next();                                                                                  // 79
			if (_i2.done) break;                                                                                      // 79
			_ref2 = _i2.value;                                                                                        // 79
		}                                                                                                          // 79
                                                                                                             //
		var role = _ref2;                                                                                          // 79
                                                                                                             //
		RocketChat.models.Roles.upsert({ _id: role.name }, { $setOnInsert: { scope: role.scope, description: role.description || '', 'protected': true } });
	}                                                                                                           // 81
});                                                                                                          // 82
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/rocketchat:authorization/lib/rocketchat.js");
require("./node_modules/meteor/rocketchat:authorization/server/models/Permissions.js");
require("./node_modules/meteor/rocketchat:authorization/server/models/Roles.js");
require("./node_modules/meteor/rocketchat:authorization/server/models/Base.js");
require("./node_modules/meteor/rocketchat:authorization/server/models/Users.js");
require("./node_modules/meteor/rocketchat:authorization/server/models/Subscriptions.js");
require("./node_modules/meteor/rocketchat:authorization/server/functions/addUserRoles.js");
require("./node_modules/meteor/rocketchat:authorization/server/functions/canAccessRoom.js");
require("./node_modules/meteor/rocketchat:authorization/server/functions/getRoles.js");
require("./node_modules/meteor/rocketchat:authorization/server/functions/getUsersInRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/functions/hasPermission.js");
require("./node_modules/meteor/rocketchat:authorization/server/functions/hasRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/functions/removeUserFromRoles.js");
require("./node_modules/meteor/rocketchat:authorization/server/publications/permissions.js");
require("./node_modules/meteor/rocketchat:authorization/server/publications/roles.js");
require("./node_modules/meteor/rocketchat:authorization/server/publications/usersInRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/methods/addUserToRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/methods/deleteRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/methods/removeUserFromRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/methods/saveRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/methods/addPermissionToRole.js");
require("./node_modules/meteor/rocketchat:authorization/server/methods/removeRoleFromPermission.js");
require("./node_modules/meteor/rocketchat:authorization/server/startup.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:authorization'] = {};

})();

//# sourceMappingURL=rocketchat_authorization.js.map
