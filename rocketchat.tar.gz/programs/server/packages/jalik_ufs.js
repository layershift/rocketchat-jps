(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var ECMAScript = Package.ecmascript.ECMAScript;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"jalik:ufs":{"ufs.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/meteor","meteor/mongo","./ufs-mime","meteor/random","./ufs-tokens","./ufs-config","./ufs-filter","./ufs-store","./ufs-store-permissions","./ufs-uploader","./ufs-template-helpers","./ufs-methods","./ufs-server",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs.js                                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({UploadFS:function(){return UploadFS}});var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var MIME;module.import('./ufs-mime',{"MIME":function(v){MIME=v}});var Random;module.import('meteor/random',{"Random":function(v){Random=v}});var Tokens;module.import('./ufs-tokens',{"Tokens":function(v){Tokens=v}});var Config;module.import('./ufs-config',{"Config":function(v){Config=v}});var Filter;module.import('./ufs-filter',{"Filter":function(v){Filter=v}});var Store;module.import('./ufs-store',{"Store":function(v){Store=v}});var StorePermissions;module.import('./ufs-store-permissions',{"StorePermissions":function(v){StorePermissions=v}});var Uploader;module.import('./ufs-uploader',{"Uploader":function(v){Uploader=v}});
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      // 27
                                                                                                                      // 28
                                                                                                                      // 29
                                                                                                                      // 30
                                                                                                                      // 31
                                                                                                                      //
var stores = {};                                                                                                      // 34
                                                                                                                      //
var UploadFS = {                                                                                                      // 36
                                                                                                                      //
    /**                                                                                                               // 38
     * Contains all stores                                                                                            //
     */                                                                                                               //
    store: {},                                                                                                        // 41
                                                                                                                      //
    /**                                                                                                               // 43
     * Collection of tokens                                                                                           //
     */                                                                                                               //
    tokens: Tokens,                                                                                                   // 46
                                                                                                                      //
    /**                                                                                                               // 48
     * Adds the "etag" attribute to files                                                                             //
     * @param where                                                                                                   //
     */                                                                                                               //
    addETagAttributeToFiles: function () {                                                                            // 52
        function addETagAttributeToFiles(where) {                                                                     // 36
            var _this = this;                                                                                         // 52
                                                                                                                      //
            _.each(this.getStores(), function (store) {                                                               // 53
                var files = store.getCollection();                                                                    // 54
                                                                                                                      //
                // By default update only files with no path set                                                      // 56
                files.find(where || { etag: null }, { fields: { _id: 1 } }).forEach(function (file) {                 // 57
                    files.direct.update(file._id, { $set: { etag: _this.generateEtag() } });                          // 58
                });                                                                                                   // 59
            });                                                                                                       // 60
        }                                                                                                             // 61
                                                                                                                      //
        return addETagAttributeToFiles;                                                                               // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 63
     * Adds the MIME type for an extension                                                                            //
     * @param extension                                                                                               //
     * @param mime                                                                                                    //
     */                                                                                                               //
    addMimeType: function () {                                                                                        // 68
        function addMimeType(extension, mime) {                                                                       // 36
            MIME[extension.toLowerCase()] = mime;                                                                     // 69
        }                                                                                                             // 70
                                                                                                                      //
        return addMimeType;                                                                                           // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 72
     * Adds the "path" attribute to files                                                                             //
     * @param where                                                                                                   //
     */                                                                                                               //
    addPathAttributeToFiles: function () {                                                                            // 76
        function addPathAttributeToFiles(where) {                                                                     // 36
            _.each(this.getStores(), function (store) {                                                               // 77
                var files = store.getCollection();                                                                    // 78
                                                                                                                      //
                // By default update only files with no path set                                                      // 80
                files.find(where || { path: null }, { fields: { _id: 1 } }).forEach(function (file) {                 // 81
                    files.direct.update(file._id, { $set: { path: store.getFileRelativeURL(file._id) } });            // 82
                });                                                                                                   // 83
            });                                                                                                       // 84
        }                                                                                                             // 85
                                                                                                                      //
        return addPathAttributeToFiles;                                                                               // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 87
     * Generates a unique ETag                                                                                        //
     * @return {string}                                                                                               //
     */                                                                                                               //
    generateEtag: function () {                                                                                       // 91
        function generateEtag() {                                                                                     // 36
            return Random.id();                                                                                       // 92
        }                                                                                                             // 93
                                                                                                                      //
        return generateEtag;                                                                                          // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 95
     * Returns the MIME type of the extension                                                                         //
     * @param extension                                                                                               //
     * @returns {*}                                                                                                   //
     */                                                                                                               //
    getMimeType: function () {                                                                                        // 100
        function getMimeType(extension) {                                                                             // 36
            extension = extension.toLowerCase();                                                                      // 101
            return MIME[extension];                                                                                   // 102
        }                                                                                                             // 103
                                                                                                                      //
        return getMimeType;                                                                                           // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 105
     * Returns all MIME types                                                                                         //
     */                                                                                                               //
    getMimeTypes: function () {                                                                                       // 108
        function getMimeTypes() {                                                                                     // 36
            return MIME;                                                                                              // 109
        }                                                                                                             // 110
                                                                                                                      //
        return getMimeTypes;                                                                                          // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 112
     * Returns the store by its name                                                                                  //
     * @param name                                                                                                    //
     * @return {UploadFS.Store}                                                                                       //
     */                                                                                                               //
    getStore: function () {                                                                                           // 117
        function getStore(name) {                                                                                     // 36
            return stores[name];                                                                                      // 118
        }                                                                                                             // 119
                                                                                                                      //
        return getStore;                                                                                              // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 121
     * Returns all stores                                                                                             //
     * @return {object}                                                                                               //
     */                                                                                                               //
    getStores: function () {                                                                                          // 125
        function getStores() {                                                                                        // 36
            return stores;                                                                                            // 126
        }                                                                                                             // 127
                                                                                                                      //
        return getStores;                                                                                             // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 129
     * Returns the temporary file path                                                                                //
     * @param fileId                                                                                                  //
     * @return {string}                                                                                               //
     */                                                                                                               //
    getTempFilePath: function () {                                                                                    // 134
        function getTempFilePath(fileId) {                                                                            // 36
            return this.config.tmpDir + '/' + fileId;                                                                 // 135
        }                                                                                                             // 136
                                                                                                                      //
        return getTempFilePath;                                                                                       // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 138
     * Imports a file from a URL                                                                                      //
     * @param url                                                                                                     //
     * @param file                                                                                                    //
     * @param store                                                                                                   //
     * @param callback                                                                                                //
     */                                                                                                               //
    importFromURL: function () {                                                                                      // 145
        function importFromURL(url, file, store, callback) {                                                          // 36
            if (typeof store === 'string') {                                                                          // 146
                Meteor.call('ufsImportURL', url, file, store, callback);                                              // 147
            } else if ((typeof store === 'undefined' ? 'undefined' : _typeof(store)) === 'object') {                  // 148
                store.importFromURL(url, file, callback);                                                             // 150
            }                                                                                                         // 151
        }                                                                                                             // 152
                                                                                                                      //
        return importFromURL;                                                                                         // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 154
     * Returns file and data as ArrayBuffer for each files in the event                                               //
     * @deprecated                                                                                                    //
     * @param event                                                                                                   //
     * @param callback                                                                                                //
     */                                                                                                               //
    readAsArrayBuffer: function () {                                                                                  // 160
        function readAsArrayBuffer(event, callback) {                                                                 // 36
            console.error('UploadFS.readAsArrayBuffer is deprecated, see https://github.com/jalik/jalik-ufs#uploading-from-a-file');
        }                                                                                                             // 162
                                                                                                                      //
        return readAsArrayBuffer;                                                                                     // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 164
     * Opens a dialog to select a single file                                                                         //
     * @param callback                                                                                                //
     */                                                                                                               //
    selectFile: function () {                                                                                         // 168
        function selectFile(callback) {                                                                               // 36
            var input = document.createElement('input');                                                              // 169
            input.type = 'file';                                                                                      // 170
            input.multiple = false;                                                                                   // 171
            input.onchange = function (ev) {                                                                          // 172
                var files = ev.target.files;                                                                          // 173
                callback.call(UploadFS, files[0]);                                                                    // 174
            };                                                                                                        // 175
            // Fix for iOS                                                                                            // 176
            input.style = 'display:none';                                                                             // 177
            document.body.appendChild(input);                                                                         // 178
            input.click();                                                                                            // 179
        }                                                                                                             // 180
                                                                                                                      //
        return selectFile;                                                                                            // 36
    }(),                                                                                                              // 36
                                                                                                                      //
                                                                                                                      //
    /**                                                                                                               // 182
     * Opens a dialog to select multiple files                                                                        //
     * @param callback                                                                                                //
     */                                                                                                               //
    selectFiles: function () {                                                                                        // 186
        function selectFiles(callback) {                                                                              // 36
            var input = document.createElement('input');                                                              // 187
            input.type = 'file';                                                                                      // 188
            input.multiple = true;                                                                                    // 189
            input.onchange = function (ev) {                                                                          // 190
                var files = ev.target.files;                                                                          // 191
                                                                                                                      //
                for (var i = 0; i < files.length; i += 1) {                                                           // 193
                    callback.call(UploadFS, files[i]);                                                                // 194
                }                                                                                                     // 195
            };                                                                                                        // 196
            // Fix for iOS                                                                                            // 197
            input.style = 'display:none';                                                                             // 198
            document.body.appendChild(input);                                                                         // 199
            input.click();                                                                                            // 200
        }                                                                                                             // 201
                                                                                                                      //
        return selectFiles;                                                                                           // 36
    }()                                                                                                               // 36
};                                                                                                                    // 36
                                                                                                                      //
                                                                                                                      // 205
                                                                                                                      // 206
                                                                                                                      // 207
                                                                                                                      // 208
                                                                                                                      // 209
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 211
    require('./ufs-template-helpers');                                                                                // 212
}                                                                                                                     // 213
if (Meteor.isServer) {                                                                                                // 214
    require('./ufs-methods');                                                                                         // 215
    require('./ufs-server');                                                                                          // 216
}                                                                                                                     // 217
                                                                                                                      //
/**                                                                                                                   // 219
 * UploadFS Configuration                                                                                             //
 * @type {Config}                                                                                                     //
 */                                                                                                                   //
UploadFS.config = new Config();                                                                                       // 223
                                                                                                                      //
// Add classes to global namespace                                                                                    // 225
UploadFS.Config = Config;                                                                                             // 226
UploadFS.Filter = Filter;                                                                                             // 227
UploadFS.Store = Store;                                                                                               // 228
UploadFS.StorePermissions = StorePermissions;                                                                         // 229
UploadFS.Uploader = Uploader;                                                                                         // 230
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 232
    // Expose the module globally                                                                                     // 233
    if (typeof global !== 'undefined') {                                                                              // 234
        global['UploadFS'] = UploadFS;                                                                                // 235
    }                                                                                                                 // 236
} else if (Meteor.isClient) {                                                                                         // 237
    // Expose the module globally                                                                                     // 239
    if (typeof window !== 'undefined') {                                                                              // 240
        window.UploadFS = UploadFS;                                                                                   // 241
    }                                                                                                                 // 242
}                                                                                                                     // 243
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-config.js":["babel-runtime/helpers/classCallCheck","meteor/underscore","meteor/meteor","./ufs-store-permissions",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-config.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Config:function(){return Config}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var StorePermissions;module.import('./ufs-store-permissions',{"StorePermissions":function(v){StorePermissions=v}});
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      // 27
                                                                                                                      // 28
                                                                                                                      //
/**                                                                                                                   // 31
 * UploadFS configuration                                                                                             //
 */                                                                                                                   //
var Config = function () {                                                                                            // 34
    function Config(options) {                                                                                        // 36
        _classCallCheck(this, Config);                                                                                // 36
                                                                                                                      //
        // Default options                                                                                            // 37
        options = _.extend({                                                                                          // 38
            defaultStorePermissions: null,                                                                            // 39
            https: false,                                                                                             // 40
            simulateReadDelay: 0,                                                                                     // 41
            simulateUploadSpeed: 0,                                                                                   // 42
            simulateWriteDelay: 0,                                                                                    // 43
            storesPath: 'ufs',                                                                                        // 44
            tmpDir: '/tmp/ufs',                                                                                       // 45
            tmpDirPermissions: '0700'                                                                                 // 46
        }, options);                                                                                                  // 38
                                                                                                                      //
        // Check options                                                                                              // 49
        if (options.defaultStorePermissions && !(options.defaultStorePermissions instanceof StorePermissions)) {      // 50
            throw new TypeError('Config: defaultStorePermissions is not an instance of StorePermissions');            // 51
        }                                                                                                             // 52
        if (typeof options.https !== 'boolean') {                                                                     // 53
            throw new TypeError('Config: https is not a function');                                                   // 54
        }                                                                                                             // 55
        if (typeof options.simulateReadDelay !== 'number') {                                                          // 56
            throw new TypeError('Config: simulateReadDelay is not a number');                                         // 57
        }                                                                                                             // 58
        if (typeof options.simulateUploadSpeed !== 'number') {                                                        // 59
            throw new TypeError('Config: simulateUploadSpeed is not a number');                                       // 60
        }                                                                                                             // 61
        if (typeof options.simulateWriteDelay !== 'number') {                                                         // 62
            throw new TypeError('Config: simulateWriteDelay is not a number');                                        // 63
        }                                                                                                             // 64
        if (typeof options.storesPath !== 'string') {                                                                 // 65
            throw new TypeError('Config: storesPath is not a string');                                                // 66
        }                                                                                                             // 67
        if (typeof options.tmpDir !== 'string') {                                                                     // 68
            throw new TypeError('Config: tmpDir is not a string');                                                    // 69
        }                                                                                                             // 70
        if (typeof options.tmpDirPermissions !== 'string') {                                                          // 71
            throw new TypeError('Config: tmpDirPermissions is not a string');                                         // 72
        }                                                                                                             // 73
                                                                                                                      //
        /**                                                                                                           // 75
         * Default store permissions                                                                                  //
         * @type {UploadFS.StorePermissions}                                                                          //
         */                                                                                                           //
        this.defaultStorePermissions = options.defaultStorePermissions;                                               // 79
        /**                                                                                                           // 80
         * Use or not secured protocol in URLS                                                                        //
         * @type {boolean}                                                                                            //
         */                                                                                                           //
        this.https = options.https;                                                                                   // 84
        /**                                                                                                           // 85
         * The simulation read delay                                                                                  //
         * @type {Number}                                                                                             //
         */                                                                                                           //
        this.simulateReadDelay = parseInt(options.simulateReadDelay);                                                 // 89
        /**                                                                                                           // 90
         * The simulation upload speed                                                                                //
         * @type {Number}                                                                                             //
         */                                                                                                           //
        this.simulateUploadSpeed = parseInt(options.simulateUploadSpeed);                                             // 94
        /**                                                                                                           // 95
         * The simulation write delay                                                                                 //
         * @type {Number}                                                                                             //
         */                                                                                                           //
        this.simulateWriteDelay = parseInt(options.simulateWriteDelay);                                               // 99
        /**                                                                                                           // 100
         * The URL root path of stores                                                                                //
         * @type {string}                                                                                             //
         */                                                                                                           //
        this.storesPath = options.storesPath;                                                                         // 104
        /**                                                                                                           // 105
         * The temporary directory of uploading files                                                                 //
         * @type {string}                                                                                             //
         */                                                                                                           //
        this.tmpDir = options.tmpDir;                                                                                 // 109
        /**                                                                                                           // 110
         * The permissions of the temporary directory                                                                 //
         * @type {string}                                                                                             //
         */                                                                                                           //
        this.tmpDirPermissions = options.tmpDirPermissions;                                                           // 114
    }                                                                                                                 // 115
                                                                                                                      //
    return Config;                                                                                                    // 34
}();                                                                                                                  // 34
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-filter.js":["babel-runtime/helpers/typeof","babel-runtime/helpers/classCallCheck","meteor/underscore","meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-filter.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Filter:function(){return Filter}});var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});
                                                                                                                      //
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      // 27
                                                                                                                      //
/**                                                                                                                   // 30
 * File filter                                                                                                        //
 */                                                                                                                   //
var Filter = function () {                                                                                            // 33
    function Filter(options) {                                                                                        // 35
        _classCallCheck(this, Filter);                                                                                // 35
                                                                                                                      //
        // Default options                                                                                            // 36
        options = _.extend({                                                                                          // 37
            contentTypes: null,                                                                                       // 38
            extensions: null,                                                                                         // 39
            minSize: 1,                                                                                               // 40
            maxSize: 0,                                                                                               // 41
            onCheck: null                                                                                             // 42
        }, options);                                                                                                  // 37
                                                                                                                      //
        // Check options                                                                                              // 45
        if (options.contentTypes && !(options.contentTypes instanceof Array)) {                                       // 46
            throw new TypeError("Filter: contentTypes is not an Array");                                              // 47
        }                                                                                                             // 48
        if (options.extensions && !(options.extensions instanceof Array)) {                                           // 49
            throw new TypeError("Filter: extensions is not an Array");                                                // 50
        }                                                                                                             // 51
        if (typeof options.minSize !== "number") {                                                                    // 52
            throw new TypeError("Filter: minSize is not a number");                                                   // 53
        }                                                                                                             // 54
        if (typeof options.maxSize !== "number") {                                                                    // 55
            throw new TypeError("Filter: maxSize is not a number");                                                   // 56
        }                                                                                                             // 57
        if (options.onCheck && typeof options.onCheck !== "function") {                                               // 58
            throw new TypeError("Filter: onCheck is not a function");                                                 // 59
        }                                                                                                             // 60
                                                                                                                      //
        // Private attributes                                                                                         // 62
        var contentTypes = options.contentTypes;                                                                      // 63
        var extensions = options.extensions;                                                                          // 64
        var maxSize = parseInt(options.maxSize);                                                                      // 65
        var minSize = parseInt(options.minSize);                                                                      // 66
                                                                                                                      //
        this.onCheck = options.onCheck;                                                                               // 68
                                                                                                                      //
        /**                                                                                                           // 70
         * Returns the allowed content types                                                                          //
         * @return {Array}                                                                                            //
         */                                                                                                           //
        this.getContentTypes = function () {                                                                          // 74
            return contentTypes;                                                                                      // 75
        };                                                                                                            // 76
                                                                                                                      //
        /**                                                                                                           // 78
         * Returns the allowed extensions                                                                             //
         * @return {Array}                                                                                            //
         */                                                                                                           //
        this.getExtensions = function () {                                                                            // 82
            return extensions;                                                                                        // 83
        };                                                                                                            // 84
                                                                                                                      //
        /**                                                                                                           // 86
         * Returns the maximum file size                                                                              //
         * @return {Number}                                                                                           //
         */                                                                                                           //
        this.getMaxSize = function () {                                                                               // 90
            return maxSize;                                                                                           // 91
        };                                                                                                            // 92
                                                                                                                      //
        /**                                                                                                           // 94
         * Returns the minimum file size                                                                              //
         * @return {Number}                                                                                           //
         */                                                                                                           //
        this.getMinSize = function () {                                                                               // 98
            return minSize;                                                                                           // 99
        };                                                                                                            // 100
    }                                                                                                                 // 101
                                                                                                                      //
    /**                                                                                                               // 103
     * Checks the file                                                                                                //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Filter.prototype.check = function () {                                                                            // 33
        function check(file) {                                                                                        // 33
            if ((typeof file === 'undefined' ? 'undefined' : _typeof(file)) !== "object" || !file) {                  // 108
                throw new Meteor.Error('invalid-file', "File is not valid");                                          // 109
            }                                                                                                         // 110
            // Check size                                                                                             // 111
            if (file.size <= 0 || file.size < this.getMinSize()) {                                                    // 112
                throw new Meteor.Error('file-too-small', 'File size is too small (min = ' + this.getMinSize() + ')');
            }                                                                                                         // 114
            if (this.getMaxSize() > 0 && file.size > this.getMaxSize()) {                                             // 115
                throw new Meteor.Error('file-too-large', 'File size is too large (max = ' + this.getMaxSize() + ')');
            }                                                                                                         // 117
            // Check extension                                                                                        // 118
            if (this.getExtensions() && !_.contains(this.getExtensions(), file.extension)) {                          // 119
                throw new Meteor.Error('invalid-file-extension', 'File extension "' + file.extension + '" is not accepted');
            }                                                                                                         // 121
            // Check content type                                                                                     // 122
            if (this.getContentTypes() && !this.isContentTypeInList(file.type, this.getContentTypes())) {             // 123
                throw new Meteor.Error('invalid-file-type', 'File type "' + file.type + '" is not accepted');         // 124
            }                                                                                                         // 125
            // Apply custom check                                                                                     // 126
            if (typeof this.onCheck === 'function' && !this.onCheck(file)) {                                          // 127
                throw new Meteor.Error('invalid-file', "File does not match filter");                                 // 128
            }                                                                                                         // 129
        }                                                                                                             // 130
                                                                                                                      //
        return check;                                                                                                 // 33
    }();                                                                                                              // 33
                                                                                                                      //
    /**                                                                                                               // 132
     * Checks if content type is in the given list                                                                    //
     * @param type                                                                                                    //
     * @param list                                                                                                    //
     * @return {boolean}                                                                                              //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Filter.prototype.isContentTypeInList = function () {                                                              // 33
        function isContentTypeInList(type, list) {                                                                    // 33
            if (typeof type === 'string' && list instanceof Array) {                                                  // 139
                if (_.contains(list, type)) {                                                                         // 140
                    return true;                                                                                      // 141
                } else {                                                                                              // 142
                    var _ret = function () {                                                                          // 142
                        var wildCardGlob = '/*';                                                                      // 143
                        var wildcards = _.filter(list, function (item) {                                              // 144
                            return item.indexOf(wildCardGlob) > 0;                                                    // 145
                        });                                                                                           // 146
                                                                                                                      //
                        if (_.contains(wildcards, type.replace(/(\/.*)$/, wildCardGlob))) {                           // 148
                            return {                                                                                  // 149
                                v: true                                                                               // 149
                            };                                                                                        // 149
                        }                                                                                             // 150
                    }();                                                                                              // 142
                                                                                                                      //
                    if ((typeof _ret === 'undefined' ? 'undefined' : _typeof(_ret)) === "object") return _ret.v;      // 142
                }                                                                                                     // 151
            }                                                                                                         // 152
            return false;                                                                                             // 153
        }                                                                                                             // 154
                                                                                                                      //
        return isContentTypeInList;                                                                                   // 33
    }();                                                                                                              // 33
                                                                                                                      //
    /**                                                                                                               // 156
     * Checks if the file matches filter                                                                              //
     * @param file                                                                                                    //
     * @return {boolean}                                                                                              //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Filter.prototype.isValid = function () {                                                                          // 33
        function isValid(file) {                                                                                      // 33
            var result = true;                                                                                        // 162
            try {                                                                                                     // 163
                this.check(file);                                                                                     // 164
            } catch (err) {                                                                                           // 165
                result = false;                                                                                       // 166
            }                                                                                                         // 167
            return result;                                                                                            // 168
        }                                                                                                             // 169
                                                                                                                      //
        return isValid;                                                                                               // 33
    }();                                                                                                              // 33
                                                                                                                      //
    /**                                                                                                               // 171
     * Executes custom checks                                                                                         //
     * @param file                                                                                                    //
     * @return {boolean}                                                                                              //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Filter.prototype.onCheck = function () {                                                                          // 33
        function onCheck(file) {                                                                                      // 33
            return true;                                                                                              // 177
        }                                                                                                             // 178
                                                                                                                      //
        return onCheck;                                                                                               // 33
    }();                                                                                                              // 33
                                                                                                                      //
    return Filter;                                                                                                    // 33
}();                                                                                                                  // 33
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-methods.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/check","meteor/meteor","./ufs","./ufs-filter","./ufs-tokens",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-methods.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var UploadFS;module.import('./ufs',{"UploadFS":function(v){UploadFS=v}});var Filter;module.import('./ufs-filter',{"Filter":function(v){Filter=v}});var Tokens;module.import('./ufs-tokens',{"Tokens":function(v){Tokens=v}});
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      // 27
                                                                                                                      // 28
                                                                                                                      // 29
                                                                                                                      // 30
                                                                                                                      // 31
                                                                                                                      //
var fs = Npm.require('fs');                                                                                           // 33
var http = Npm.require('http');                                                                                       // 34
var https = Npm.require('https');                                                                                     // 35
var Future = Npm.require('fibers/future');                                                                            // 36
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 39
    Meteor.methods({                                                                                                  // 40
                                                                                                                      //
        /**                                                                                                           // 42
         * Completes the file transfer                                                                                //
         * @param fileId                                                                                              //
         * @param storeName                                                                                           //
         * @param token                                                                                               //
         */                                                                                                           //
        ufsComplete: function () {                                                                                    // 48
            function ufsComplete(fileId, storeName, token) {                                                          // 40
                check(fileId, String);                                                                                // 49
                check(storeName, String);                                                                             // 50
                check(token, String);                                                                                 // 51
                                                                                                                      //
                // Get store                                                                                          // 53
                var store = UploadFS.getStore(storeName);                                                             // 54
                if (!store) {                                                                                         // 55
                    throw new Meteor.Error('invalid-store', "Store not found");                                       // 56
                }                                                                                                     // 57
                // Check token                                                                                        // 58
                if (!store.checkToken(token, fileId)) {                                                               // 59
                    throw new Meteor.Error('invalid-token', "Token is not valid");                                    // 60
                }                                                                                                     // 61
                                                                                                                      //
                var fut = new Future();                                                                               // 63
                var tmpFile = UploadFS.getTempFilePath(fileId);                                                       // 64
                                                                                                                      //
                var removeTempFile = function () {                                                                    // 66
                    function removeTempFile() {                                                                       // 66
                        fs.unlink(tmpFile, function (err) {                                                           // 67
                            err && console.error('ufs: cannot delete temp file "' + tmpFile + '" (' + err.message + ')');
                        });                                                                                           // 69
                    }                                                                                                 // 70
                                                                                                                      //
                    return removeTempFile;                                                                            // 66
                }();                                                                                                  // 66
                                                                                                                      //
                try {                                                                                                 // 72
                    // todo check if temp file exists                                                                 // 73
                                                                                                                      //
                    // Get file                                                                                       // 75
                    var file = store.getCollection().findOne({ _id: fileId });                                        // 76
                                                                                                                      //
                    // Validate file before moving to the store                                                       // 78
                    store.validate(file);                                                                             // 79
                                                                                                                      //
                    // Get the temp file                                                                              // 81
                    var rs = fs.createReadStream(tmpFile, {                                                           // 82
                        flags: 'r',                                                                                   // 83
                        encoding: null,                                                                               // 84
                        autoClose: true                                                                               // 85
                    });                                                                                               // 82
                                                                                                                      //
                    // Clean upload if error occurs                                                                   // 88
                    rs.on('error', Meteor.bindEnvironment(function (err) {                                            // 89
                        console.error(err);                                                                           // 90
                        store.getCollection().remove({ _id: fileId });                                                // 91
                        fut['throw'](err);                                                                            // 92
                    }));                                                                                              // 93
                                                                                                                      //
                    // Save file in the store                                                                         // 95
                    store.write(rs, fileId, Meteor.bindEnvironment(function (err, file) {                             // 96
                        removeTempFile();                                                                             // 97
                                                                                                                      //
                        if (err) {                                                                                    // 99
                            fut['throw'](err);                                                                        // 100
                        } else {                                                                                      // 101
                            // File has been fully uploaded                                                           // 102
                            // so we don't need to keep the token anymore.                                            // 103
                            // Also this ensure that the file cannot be modified with extra chunks later.             // 104
                            Tokens.remove({ fileId: fileId });                                                        // 105
                            fut['return'](file);                                                                      // 106
                        }                                                                                             // 107
                    }));                                                                                              // 108
                } catch (err) {                                                                                       // 109
                    // If write failed, remove the file                                                               // 111
                    store.getCollection().remove({ _id: fileId });                                                    // 112
                    // removeTempFile();                                                                              // 113
                    fut['throw'](err);                                                                                // 114
                }                                                                                                     // 115
                return fut.wait();                                                                                    // 116
            }                                                                                                         // 117
                                                                                                                      //
            return ufsComplete;                                                                                       // 40
        }(),                                                                                                          // 40
                                                                                                                      //
                                                                                                                      //
        /**                                                                                                           // 119
         * Creates the file and returns the file upload token                                                         //
         * @param file                                                                                                //
         * @return {{fileId: string, token: *, url: *}}                                                               //
         */                                                                                                           //
        ufsCreate: function () {                                                                                      // 124
            function ufsCreate(file) {                                                                                // 40
                check(file, Object);                                                                                  // 125
                                                                                                                      //
                if (typeof file.name !== 'string' || !file.name.length) {                                             // 127
                    throw new Meteor.Error('invalid-file-name', "file name is not valid");                            // 128
                }                                                                                                     // 129
                if (typeof file.store !== 'string' || !file.store.length) {                                           // 130
                    throw new Meteor.Error('invalid-store', "store is not valid");                                    // 131
                }                                                                                                     // 132
                // Get store                                                                                          // 133
                var store = UploadFS.getStore(file.store);                                                            // 134
                if (!store) {                                                                                         // 135
                    throw new Meteor.Error('invalid-store', "Store not found");                                       // 136
                }                                                                                                     // 137
                                                                                                                      //
                // Set default info                                                                                   // 139
                file.complete = false;                                                                                // 140
                file.uploading = false;                                                                               // 141
                file.extension = file.name && file.name.substr((~-file.name.lastIndexOf('.') >>> 0) + 2).toLowerCase();
                // Assign file MIME type based on the extension                                                       // 143
                if (file.extension && !file.type) {                                                                   // 144
                    file.type = UploadFS.getMimeType(file.extension) || 'application/octet-stream';                   // 145
                }                                                                                                     // 146
                file.progress = 0;                                                                                    // 147
                file.size = parseInt(file.size) || 0;                                                                 // 148
                file.userId = file.userId || this.userId;                                                             // 149
                                                                                                                      //
                // Check if the file matches store filter                                                             // 151
                var filter = store.getFilter();                                                                       // 152
                if (filter instanceof Filter) {                                                                       // 153
                    filter.check(file);                                                                               // 154
                }                                                                                                     // 155
                                                                                                                      //
                // Create the file                                                                                    // 157
                var fileId = store.create(file);                                                                      // 158
                var token = store.createToken(fileId);                                                                // 159
                var uploadUrl = store.getURL(fileId + '?token=' + token);                                             // 160
                                                                                                                      //
                return {                                                                                              // 162
                    fileId: fileId,                                                                                   // 163
                    token: token,                                                                                     // 164
                    url: uploadUrl                                                                                    // 165
                };                                                                                                    // 162
            }                                                                                                         // 167
                                                                                                                      //
            return ufsCreate;                                                                                         // 40
        }(),                                                                                                          // 40
                                                                                                                      //
                                                                                                                      //
        /**                                                                                                           // 169
         * Deletes a file                                                                                             //
         * @param fileId                                                                                              //
         * @param storeName                                                                                           //
         * @param token                                                                                               //
         * @returns {*}                                                                                               //
         */                                                                                                           //
        ufsDelete: function () {                                                                                      // 176
            function ufsDelete(fileId, storeName, token) {                                                            // 40
                check(fileId, String);                                                                                // 177
                check(storeName, String);                                                                             // 178
                check(token, String);                                                                                 // 179
                                                                                                                      //
                // Check store                                                                                        // 181
                var store = UploadFS.getStore(storeName);                                                             // 182
                if (!store) {                                                                                         // 183
                    throw new Meteor.Error('invalid-store', "Store not found");                                       // 184
                }                                                                                                     // 185
                // Ignore files that does not exist                                                                   // 186
                if (store.getCollection().find({ _id: fileId }).count() === 0) {                                      // 187
                    return 1;                                                                                         // 188
                }                                                                                                     // 189
                // Check token                                                                                        // 190
                if (!store.checkToken(token, fileId)) {                                                               // 191
                    throw new Meteor.Error('invalid-token', "Token is not valid");                                    // 192
                }                                                                                                     // 193
                return store.getCollection().remove({ _id: fileId });                                                 // 194
            }                                                                                                         // 195
                                                                                                                      //
            return ufsDelete;                                                                                         // 40
        }(),                                                                                                          // 40
                                                                                                                      //
                                                                                                                      //
        /**                                                                                                           // 197
         * Imports a file from the URL                                                                                //
         * @param url                                                                                                 //
         * @param file                                                                                                //
         * @param storeName                                                                                           //
         * @return {*}                                                                                                //
         */                                                                                                           //
        ufsImportURL: function () {                                                                                   // 204
            function ufsImportURL(url, file, storeName) {                                                             // 40
                check(url, String);                                                                                   // 205
                check(file, Object);                                                                                  // 206
                check(storeName, String);                                                                             // 207
                                                                                                                      //
                // Check URL                                                                                          // 209
                if (typeof url !== 'string' || url.length <= 0) {                                                     // 210
                    throw new Meteor.Error('invalid-url', "The url is not valid");                                    // 211
                }                                                                                                     // 212
                // Check file                                                                                         // 213
                if ((typeof file === 'undefined' ? 'undefined' : _typeof(file)) !== 'object' || file === null) {      // 214
                    throw new Meteor.Error('invalid-file', "The file is not valid");                                  // 215
                }                                                                                                     // 216
                // Check store                                                                                        // 217
                var store = UploadFS.getStore(storeName);                                                             // 218
                if (!store) {                                                                                         // 219
                    throw new Meteor.Error('invalid-store', 'The store does not exist');                              // 220
                }                                                                                                     // 221
                                                                                                                      //
                // Extract file info                                                                                  // 223
                if (!file.name) {                                                                                     // 224
                    file.name = url.replace(/\?.*$/, '').split('/').pop();                                            // 225
                }                                                                                                     // 226
                if (file.name && !file.extension) {                                                                   // 227
                    file.extension = file.name && file.name.substr((~-file.name.lastIndexOf('.') >>> 0) + 2).toLowerCase();
                }                                                                                                     // 229
                if (file.extension && !file.type) {                                                                   // 230
                    // Assign file MIME type based on the extension                                                   // 231
                    file.type = UploadFS.getMimeType(file.extension) || 'application/octet-stream';                   // 232
                }                                                                                                     // 233
                // Check if file is valid                                                                             // 234
                if (store.getFilter() instanceof Filter) {                                                            // 235
                    store.getFilter().check(file);                                                                    // 236
                }                                                                                                     // 237
                                                                                                                      //
                if (file.originalUrl) {                                                                               // 239
                    console.warn('ufs: The "originalUrl" attribute is automatically set when importing a file from a URL');
                }                                                                                                     // 241
                                                                                                                      //
                // Add original URL                                                                                   // 243
                file.originalUrl = url;                                                                               // 244
                                                                                                                      //
                // Create the file                                                                                    // 246
                file.complete = false;                                                                                // 247
                file.uploading = true;                                                                                // 248
                file.progress = 0;                                                                                    // 249
                file._id = store.create(file);                                                                        // 250
                                                                                                                      //
                var fut = new Future();                                                                               // 252
                var proto = void 0;                                                                                   // 253
                                                                                                                      //
                // Detect protocol to use                                                                             // 255
                if (/http:\/\//i.test(url)) {                                                                         // 256
                    proto = http;                                                                                     // 257
                } else if (/https:\/\//i.test(url)) {                                                                 // 258
                    proto = https;                                                                                    // 259
                }                                                                                                     // 260
                                                                                                                      //
                this.unblock();                                                                                       // 262
                                                                                                                      //
                // Download file                                                                                      // 264
                proto.get(url, Meteor.bindEnvironment(function (res) {                                                // 265
                    // Save the file in the store                                                                     // 266
                    store.write(res, file._id, function (err, file) {                                                 // 267
                        if (err) {                                                                                    // 268
                            fut['throw'](err);                                                                        // 269
                        } else {                                                                                      // 270
                            fut['return'](file);                                                                      // 271
                        }                                                                                             // 272
                    });                                                                                               // 273
                })).on('error', function (err) {                                                                      // 274
                    fut['throw'](err);                                                                                // 275
                });                                                                                                   // 276
                return fut.wait();                                                                                    // 277
            }                                                                                                         // 278
                                                                                                                      //
            return ufsImportURL;                                                                                      // 40
        }(),                                                                                                          // 40
                                                                                                                      //
                                                                                                                      //
        /**                                                                                                           // 280
         * Marks the file uploading as stopped                                                                        //
         * @param fileId                                                                                              //
         * @param storeName                                                                                           //
         * @param token                                                                                               //
         * @returns {*}                                                                                               //
         */                                                                                                           //
        ufsStop: function () {                                                                                        // 287
            function ufsStop(fileId, storeName, token) {                                                              // 40
                check(fileId, String);                                                                                // 288
                check(storeName, String);                                                                             // 289
                check(token, String);                                                                                 // 290
                                                                                                                      //
                // Check store                                                                                        // 292
                var store = UploadFS.getStore(storeName);                                                             // 293
                if (!store) {                                                                                         // 294
                    throw new Meteor.Error('invalid-store', "Store not found");                                       // 295
                }                                                                                                     // 296
                // Check file                                                                                         // 297
                var file = store.getCollection().find({ _id: fileId }, { fields: { userId: 1 } });                    // 298
                if (!file) {                                                                                          // 299
                    throw new Meteor.Error('invalid-file', "File not found");                                         // 300
                }                                                                                                     // 301
                // Check token                                                                                        // 302
                if (!store.checkToken(token, fileId)) {                                                               // 303
                    throw new Meteor.Error('invalid-token', "Token is not valid");                                    // 304
                }                                                                                                     // 305
                                                                                                                      //
                return store.getCollection().update({ _id: fileId }, {                                                // 307
                    $set: { uploading: false }                                                                        // 308
                });                                                                                                   // 307
            }                                                                                                         // 310
                                                                                                                      //
            return ufsStop;                                                                                           // 40
        }()                                                                                                           // 40
    });                                                                                                               // 40
}                                                                                                                     // 312
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-mime.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-mime.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({MIME:function(){return MIME}});/*                                                                      // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
/**                                                                                                                   // 26
 * MIME types and extensions                                                                                          //
 */                                                                                                                   //
var MIME = {                                                                                                          // 29
                                                                                                                      //
    // application                                                                                                    // 31
    '7z': 'application/x-7z-compressed',                                                                              // 32
    'arc': 'application/octet-stream',                                                                                // 33
    'ai': 'application/postscript',                                                                                   // 34
    'bin': 'application/octet-stream',                                                                                // 35
    'bz': 'application/x-bzip',                                                                                       // 36
    'bz2': 'application/x-bzip2',                                                                                     // 37
    'eps': 'application/postscript',                                                                                  // 38
    'exe': 'application/octet-stream',                                                                                // 39
    'gz': 'application/x-gzip',                                                                                       // 40
    'gzip': 'application/x-gzip',                                                                                     // 41
    'js': 'application/javascript',                                                                                   // 42
    'json': 'application/json',                                                                                       // 43
    'ogx': 'application/ogg',                                                                                         // 44
    'pdf': 'application/pdf',                                                                                         // 45
    'ps': 'application/postscript',                                                                                   // 46
    'psd': 'application/octet-stream',                                                                                // 47
    'rar': 'application/x-rar-compressed',                                                                            // 48
    'rev': 'application/x-rar-compressed',                                                                            // 49
    'swf': 'application/x-shockwave-flash',                                                                           // 50
    'tar': 'application/x-tar',                                                                                       // 51
    'xhtml': 'application/xhtml+xml',                                                                                 // 52
    'xml': 'application/xml',                                                                                         // 53
    'zip': 'application/zip',                                                                                         // 54
                                                                                                                      //
    // audio                                                                                                          // 56
    'aif': 'audio/aiff',                                                                                              // 57
    'aifc': 'audio/aiff',                                                                                             // 58
    'aiff': 'audio/aiff',                                                                                             // 59
    'au': 'audio/basic',                                                                                              // 60
    'flac': 'audio/flac',                                                                                             // 61
    'midi': 'audio/midi',                                                                                             // 62
    'mp2': 'audio/mpeg',                                                                                              // 63
    'mp3': 'audio/mpeg',                                                                                              // 64
    'mpa': 'audio/mpeg',                                                                                              // 65
    'oga': 'audio/ogg',                                                                                               // 66
    'ogg': 'audio/ogg',                                                                                               // 67
    'opus': 'audio/ogg',                                                                                              // 68
    'ra': 'audio/vnd.rn-realaudio',                                                                                   // 69
    'spx': 'audio/ogg',                                                                                               // 70
    'wav': 'audio/x-wav',                                                                                             // 71
    'weba': 'audio/webm',                                                                                             // 72
    'wma': 'audio/x-ms-wma',                                                                                          // 73
                                                                                                                      //
    // image                                                                                                          // 75
    'avs': 'image/avs-video',                                                                                         // 76
    'bmp': 'image/x-windows-bmp',                                                                                     // 77
    'gif': 'image/gif',                                                                                               // 78
    'ico': 'image/vnd.microsoft.icon',                                                                                // 79
    'jpeg': 'image/jpeg',                                                                                             // 80
    'jpg': 'image/jpg',                                                                                               // 81
    'mjpg': 'image/x-motion-jpeg',                                                                                    // 82
    'pic': 'image/pic',                                                                                               // 83
    'png': 'image/png',                                                                                               // 84
    'svg': 'image/svg+xml',                                                                                           // 85
    'tif': 'image/tiff',                                                                                              // 86
    'tiff': 'image/tiff',                                                                                             // 87
                                                                                                                      //
    // text                                                                                                           // 89
    'css': 'text/css',                                                                                                // 90
    'csv': 'text/csv',                                                                                                // 91
    'html': 'text/html',                                                                                              // 92
    'txt': 'text/plain',                                                                                              // 93
                                                                                                                      //
    // video                                                                                                          // 95
    'avi': 'video/avi',                                                                                               // 96
    'dv': 'video/x-dv',                                                                                               // 97
    'flv': 'video/x-flv',                                                                                             // 98
    'mov': 'video/quicktime',                                                                                         // 99
    'mp4': 'video/mp4',                                                                                               // 100
    'mpeg': 'video/mpeg',                                                                                             // 101
    'mpg': 'video/mpg',                                                                                               // 102
    'ogv': 'video/ogg',                                                                                               // 103
    'vdo': 'video/vdo',                                                                                               // 104
    'webm': 'video/webm',                                                                                             // 105
    'wmv': 'video/x-ms-wmv',                                                                                          // 106
                                                                                                                      //
    // specific to vendors                                                                                            // 108
    'doc': 'application/msword',                                                                                      // 109
    'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',                                // 110
    'odb': 'application/vnd.oasis.opendocument.database',                                                             // 111
    'odc': 'application/vnd.oasis.opendocument.chart',                                                                // 112
    'odf': 'application/vnd.oasis.opendocument.formula',                                                              // 113
    'odg': 'application/vnd.oasis.opendocument.graphics',                                                             // 114
    'odi': 'application/vnd.oasis.opendocument.image',                                                                // 115
    'odm': 'application/vnd.oasis.opendocument.text-master',                                                          // 116
    'odp': 'application/vnd.oasis.opendocument.presentation',                                                         // 117
    'ods': 'application/vnd.oasis.opendocument.spreadsheet',                                                          // 118
    'odt': 'application/vnd.oasis.opendocument.text',                                                                 // 119
    'otg': 'application/vnd.oasis.opendocument.graphics-template',                                                    // 120
    'otp': 'application/vnd.oasis.opendocument.presentation-template',                                                // 121
    'ots': 'application/vnd.oasis.opendocument.spreadsheet-template',                                                 // 122
    'ott': 'application/vnd.oasis.opendocument.text-template',                                                        // 123
    'ppt': 'application/vnd.ms-powerpoint',                                                                           // 124
    'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',                              // 125
    'xls': 'application/vnd.ms-excel',                                                                                // 126
    'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'                                       // 127
};                                                                                                                    // 29
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"ufs-server.js":["babel-runtime/helpers/typeof","meteor/underscore","meteor/meteor","meteor/webapp","./ufs",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-server.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var WebApp;module.import('meteor/webapp',{"WebApp":function(v){WebApp=v}});var UploadFS;module.import('./ufs',{"UploadFS":function(v){UploadFS=v}});
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      // 27
                                                                                                                      // 28
                                                                                                                      // 29
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 32
    (function () {                                                                                                    // 32
                                                                                                                      //
        var domain = Npm.require('domain');                                                                           // 34
        var fs = Npm.require('fs');                                                                                   // 35
        var http = Npm.require('http');                                                                               // 36
        var https = Npm.require('https');                                                                             // 37
        var mkdirp = Npm.require('mkdirp');                                                                           // 38
        var stream = Npm.require('stream');                                                                           // 39
        var URL = Npm.require('url');                                                                                 // 40
        var zlib = Npm.require('zlib');                                                                               // 41
                                                                                                                      //
        Meteor.startup(function () {                                                                                  // 44
            var path = UploadFS.config.tmpDir;                                                                        // 45
            var mode = UploadFS.config.tmpDirPermissions;                                                             // 46
                                                                                                                      //
            fs.stat(path, function (err) {                                                                            // 48
                if (err) {                                                                                            // 49
                    // Create the temp directory                                                                      // 50
                    mkdirp(path, { mode: mode }, function (err) {                                                     // 51
                        if (err) {                                                                                    // 52
                            console.error('ufs: cannot create temp directory at "' + path + '" (' + err.message + ')');
                        } else {                                                                                      // 54
                            console.log('ufs: temp directory created at "' + path + '"');                             // 55
                        }                                                                                             // 56
                    });                                                                                               // 57
                } else {                                                                                              // 58
                    // Set directory permissions                                                                      // 59
                    fs.chmod(path, mode, function (err) {                                                             // 60
                        err && console.error('ufs: cannot set temp directory permissions ' + mode + ' (' + err.message + ')');
                    });                                                                                               // 62
                }                                                                                                     // 63
            });                                                                                                       // 64
        });                                                                                                           // 65
                                                                                                                      //
        // Create domain to handle errors                                                                             // 67
        // and possibly avoid server crashes.                                                                         // 68
        var d = domain.create();                                                                                      // 69
                                                                                                                      //
        d.on('error', function (err) {                                                                                // 71
            console.error('ufs: ' + err.message);                                                                     // 72
        });                                                                                                           // 73
                                                                                                                      //
        // Listen HTTP requests to serve files                                                                        // 75
        WebApp.connectHandlers.use(function (req, res, next) {                                                        // 76
            // Quick check to see if request should be catch                                                          // 77
            if (req.url.indexOf(UploadFS.config.storesPath) === -1) {                                                 // 78
                next();                                                                                               // 79
                return;                                                                                               // 80
            }                                                                                                         // 81
                                                                                                                      //
            // Remove store path                                                                                      // 83
            var parsedUrl = URL.parse(req.url);                                                                       // 84
            var path = parsedUrl.pathname.substr(UploadFS.config.storesPath.length + 1);                              // 85
                                                                                                                      //
            var allowCORS = function allowCORS() {                                                                    // 87
                // res.setHeader('Access-Control-Allow-Origin', req.headers.origin);                                  // 88
                res.setHeader("Access-Control-Allow-Methods", "POST");                                                // 89
                res.setHeader("Access-Control-Allow-Origin", "*");                                                    // 90
                res.setHeader("Access-Control-Allow-Headers", "Content-Type");                                        // 91
            };                                                                                                        // 92
                                                                                                                      //
            if (req.method === "OPTIONS") {                                                                           // 94
                var regExp = new RegExp('^\/([^\/\?]+)\/([^\/\?]+)$');                                                // 95
                var match = regExp.exec(path);                                                                        // 96
                                                                                                                      //
                // Request is not valid                                                                               // 98
                if (match === null) {                                                                                 // 99
                    res.writeHead(400);                                                                               // 100
                    res.end();                                                                                        // 101
                    return;                                                                                           // 102
                }                                                                                                     // 103
                                                                                                                      //
                // Get store                                                                                          // 105
                var store = UploadFS.getStore(match[1]);                                                              // 106
                if (!store) {                                                                                         // 107
                    res.writeHead(404);                                                                               // 108
                    res.end();                                                                                        // 109
                    return;                                                                                           // 110
                }                                                                                                     // 111
                                                                                                                      //
                // If a store is found, go ahead and allow the origin                                                 // 113
                allowCORS();                                                                                          // 114
                                                                                                                      //
                next();                                                                                               // 116
            } else if (req.method === 'POST') {                                                                       // 117
                var _ret2 = function () {                                                                             // 118
                    // Get store                                                                                      // 119
                    var regExp = new RegExp('^\/([^\/\?]+)\/([^\/\?]+)$');                                            // 120
                    var match = regExp.exec(path);                                                                    // 121
                                                                                                                      //
                    // Request is not valid                                                                           // 123
                    if (match === null) {                                                                             // 124
                        res.writeHead(400);                                                                           // 125
                        res.end();                                                                                    // 126
                        return {                                                                                      // 127
                            v: void 0                                                                                 // 127
                        };                                                                                            // 127
                    }                                                                                                 // 128
                                                                                                                      //
                    // Get store                                                                                      // 130
                    var store = UploadFS.getStore(match[1]);                                                          // 131
                    if (!store) {                                                                                     // 132
                        res.writeHead(404);                                                                           // 133
                        res.end();                                                                                    // 134
                        return {                                                                                      // 135
                            v: void 0                                                                                 // 135
                        };                                                                                            // 135
                    }                                                                                                 // 136
                                                                                                                      //
                    // If a store is found, go ahead and allow the origin                                             // 138
                    allowCORS();                                                                                      // 139
                                                                                                                      //
                    // Get file                                                                                       // 141
                    var fileId = match[2];                                                                            // 142
                    if (store.getCollection().find({ _id: fileId }).count() === 0) {                                  // 143
                        res.writeHead(404);                                                                           // 144
                        res.end();                                                                                    // 145
                        return {                                                                                      // 146
                            v: void 0                                                                                 // 146
                        };                                                                                            // 146
                    }                                                                                                 // 147
                                                                                                                      //
                    // Check upload token                                                                             // 149
                    if (!store.checkToken(req.query.token, fileId)) {                                                 // 150
                        res.writeHead(403);                                                                           // 151
                        res.end();                                                                                    // 152
                        return {                                                                                      // 153
                            v: void 0                                                                                 // 153
                        };                                                                                            // 153
                    }                                                                                                 // 154
                                                                                                                      //
                    var tmpFile = UploadFS.getTempFilePath(fileId);                                                   // 156
                    var ws = fs.createWriteStream(tmpFile, { flags: 'a' });                                           // 157
                    var fields = { uploading: true };                                                                 // 158
                    var progress = parseFloat(req.query.progress);                                                    // 159
                    if (!isNaN(progress) && progress > 0) {                                                           // 160
                        fields.progress = Math.min(progress, 1);                                                      // 161
                    }                                                                                                 // 162
                                                                                                                      //
                    req.on('data', function (chunk) {                                                                 // 164
                        ws.write(chunk);                                                                              // 165
                    });                                                                                               // 166
                    req.on('error', function (err) {                                                                  // 167
                        res.writeHead(500);                                                                           // 168
                        res.end();                                                                                    // 169
                    });                                                                                               // 170
                    req.on('end', Meteor.bindEnvironment(function () {                                                // 171
                        // Update completed state without triggering hooks                                            // 172
                        store.getCollection().direct.update({ _id: fileId }, { $set: fields });                       // 173
                        ws.end();                                                                                     // 174
                    }));                                                                                              // 175
                    ws.on('error', function (err) {                                                                   // 176
                        console.error('ufs: cannot write chunk of file "' + fileId + '" (' + err.message + ')');      // 177
                        fs.unlink(tmpFile, function (err) {                                                           // 178
                            err && console.error('ufs: cannot delete temp file "' + tmpFile + '" (' + err.message + ')');
                        });                                                                                           // 180
                        res.writeHead(500);                                                                           // 181
                        res.end();                                                                                    // 182
                    });                                                                                               // 183
                    ws.on('finish', function () {                                                                     // 184
                        res.writeHead(204, { "Content-Type": 'text/plain' });                                         // 185
                        res.end();                                                                                    // 186
                    });                                                                                               // 187
                }();                                                                                                  // 118
                                                                                                                      //
                if ((typeof _ret2 === 'undefined' ? 'undefined' : _typeof(_ret2)) === "object") return _ret2.v;       // 118
            } else if (req.method == 'GET') {                                                                         // 188
                var _ret3 = function () {                                                                             // 189
                    // Get store, file Id and file name                                                               // 190
                    var regExp = new RegExp('^\/([^\/\?]+)\/([^\/\?]+)(?:\/([^\/\?]+))?$');                           // 191
                    var match = regExp.exec(path);                                                                    // 192
                                                                                                                      //
                    // Avoid 504 Gateway timeout error                                                                // 194
                    // if file is not handled by UploadFS.                                                            // 195
                    if (match === null) {                                                                             // 196
                        next();                                                                                       // 197
                        return {                                                                                      // 198
                            v: void 0                                                                                 // 198
                        };                                                                                            // 198
                    }                                                                                                 // 199
                                                                                                                      //
                    // Get store                                                                                      // 201
                    var storeName = match[1];                                                                         // 202
                    var store = UploadFS.getStore(storeName);                                                         // 203
                                                                                                                      //
                    if (!store) {                                                                                     // 205
                        res.writeHead(404);                                                                           // 206
                        res.end();                                                                                    // 207
                        return {                                                                                      // 208
                            v: void 0                                                                                 // 208
                        };                                                                                            // 208
                    }                                                                                                 // 209
                                                                                                                      //
                    if (store.onRead !== null && store.onRead !== undefined && typeof store.onRead !== 'function') {  // 211
                        console.error('ufs: store "' + storeName + '" onRead is not a function');                     // 212
                        res.writeHead(500);                                                                           // 213
                        res.end();                                                                                    // 214
                        return {                                                                                      // 215
                            v: void 0                                                                                 // 215
                        };                                                                                            // 215
                    }                                                                                                 // 216
                                                                                                                      //
                    // Remove file extension from file Id                                                             // 218
                    var index = match[2].indexOf('.');                                                                // 219
                    var fileId = index !== -1 ? match[2].substr(0, index) : match[2];                                 // 220
                                                                                                                      //
                    // Get file from database                                                                         // 222
                    var file = store.getCollection().findOne({ _id: fileId });                                        // 223
                    if (!file) {                                                                                      // 224
                        res.writeHead(404);                                                                           // 225
                        res.end();                                                                                    // 226
                        return {                                                                                      // 227
                            v: void 0                                                                                 // 227
                        };                                                                                            // 227
                    }                                                                                                 // 228
                                                                                                                      //
                    // Simulate read speed                                                                            // 230
                    if (UploadFS.config.simulateReadDelay) {                                                          // 231
                        Meteor._sleepForMs(UploadFS.config.simulateReadDelay);                                        // 232
                    }                                                                                                 // 233
                                                                                                                      //
                    d.run(function () {                                                                               // 235
                        // Check if the file can be accessed                                                          // 236
                        if (store.onRead.call(store, fileId, file, req, res) !== false) {                             // 237
                            var _ret4 = function () {                                                                 // 237
                                var options = {};                                                                     // 238
                                var status = 200;                                                                     // 239
                                                                                                                      //
                                // Prepare response headers                                                           // 241
                                var headers = {                                                                       // 242
                                    'Content-Type': file.type,                                                        // 243
                                    'Content-Length': file.size                                                       // 244
                                };                                                                                    // 242
                                                                                                                      //
                                // Add ETag header                                                                    // 247
                                if (typeof file.etag === 'string') {                                                  // 248
                                    headers['ETag'] = file.etag;                                                      // 249
                                }                                                                                     // 250
                                                                                                                      //
                                // Add Last-Modified header                                                           // 252
                                if (file.modifiedAt instanceof Date) {                                                // 253
                                    headers['Last-Modified'] = file.modifiedAt.toUTCString();                         // 254
                                } else if (file.uploadedAt instanceof Date) {                                         // 255
                                    headers['Last-Modified'] = file.uploadedAt.toUTCString();                         // 257
                                }                                                                                     // 258
                                                                                                                      //
                                // Parse request headers                                                              // 260
                                if (_typeof(req.headers) === 'object') {                                              // 261
                                                                                                                      //
                                    // Compare ETag                                                                   // 263
                                    if (req.headers['if-none-match']) {                                               // 264
                                        if (file.etag === req.headers['if-none-match']) {                             // 265
                                            res.writeHead(304); // Not Modified                                       // 266
                                            res.end();                                                                // 267
                                            return {                                                                  // 268
                                                v: void 0                                                             // 268
                                            };                                                                        // 268
                                        }                                                                             // 269
                                    }                                                                                 // 270
                                                                                                                      //
                                    // Compare file modification date                                                 // 272
                                    if (req.headers['if-modified-since']) {                                           // 273
                                        var modifiedSince = new Date(req.headers['if-modified-since']);               // 274
                                                                                                                      //
                                        if (file.modifiedAt instanceof Date && file.modifiedAt > modifiedSince || file.uploadedAt instanceof Date && file.uploadedAt > modifiedSince) {
                                            res.writeHead(304); // Not Modified                                       // 278
                                            res.end();                                                                // 279
                                            return {                                                                  // 280
                                                v: void 0                                                             // 280
                                            };                                                                        // 280
                                        }                                                                             // 281
                                    }                                                                                 // 282
                                                                                                                      //
                                    // Send data in range                                                             // 284
                                    if (typeof req.headers.range === 'string') {                                      // 285
                                        var range = req.headers.range;                                                // 286
                                                                                                                      //
                                        // Range is not valid                                                         // 288
                                        if (!range) {                                                                 // 289
                                            res.writeHead(416);                                                       // 290
                                            res.end();                                                                // 291
                                            return {                                                                  // 292
                                                v: void 0                                                             // 292
                                            };                                                                        // 292
                                        }                                                                             // 293
                                                                                                                      //
                                        var positions = range.replace(/bytes=/, '').split('-');                       // 295
                                        var start = parseInt(positions[0], 10);                                       // 296
                                        var total = file.size;                                                        // 297
                                        var end = positions[1] ? parseInt(positions[1], 10) : total - 1;              // 298
                                                                                                                      //
                                        // Update headers                                                             // 300
                                        headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + total;        // 301
                                        headers['Accept-Ranges'] = 'bytes';                                           // 302
                                        headers['Content-Length'] = end - start + 1;                                  // 303
                                                                                                                      //
                                        status = 206; // partial content                                              // 305
                                        options.start = start;                                                        // 306
                                        options.end = end;                                                            // 307
                                    }                                                                                 // 308
                                }                                                                                     // 309
                                                                                                                      //
                                // Open the file stream                                                               // 311
                                var rs = store.getReadStream(fileId, file, options);                                  // 312
                                var ws = new stream.PassThrough();                                                    // 313
                                                                                                                      //
                                rs.on('error', Meteor.bindEnvironment(function (err) {                                // 315
                                    store.onReadError.call(store, err, fileId, file);                                 // 316
                                    res.end();                                                                        // 317
                                }));                                                                                  // 318
                                ws.on('error', Meteor.bindEnvironment(function (err) {                                // 319
                                    store.onReadError.call(store, err, fileId, file);                                 // 320
                                    res.end();                                                                        // 321
                                }));                                                                                  // 322
                                ws.on('close', function () {                                                          // 323
                                    // Close output stream at the end                                                 // 324
                                    ws.emit('end');                                                                   // 325
                                });                                                                                   // 326
                                                                                                                      //
                                // Transform stream                                                                   // 328
                                store.transformRead(rs, ws, fileId, file, req, headers);                              // 329
                                                                                                                      //
                                // Parse request headers                                                              // 331
                                if (_typeof(req.headers) === 'object') {                                              // 332
                                    // Compress data using if needed (ignore audio/video as they are already compressed)
                                    if (typeof req.headers['accept-encoding'] === 'string' && !/^(audio|video)/.test(file.type)) {
                                        var accept = req.headers['accept-encoding'];                                  // 335
                                                                                                                      //
                                        // Compress with gzip                                                         // 337
                                        if (accept.match(/\bgzip\b/)) {                                               // 338
                                            headers['Content-Encoding'] = 'gzip';                                     // 339
                                            delete headers['Content-Length'];                                         // 340
                                            res.writeHead(status, headers);                                           // 341
                                            ws.pipe(zlib.createGzip()).pipe(res);                                     // 342
                                            return {                                                                  // 343
                                                v: void 0                                                             // 343
                                            };                                                                        // 343
                                        }                                                                             // 344
                                        // Compress with deflate                                                      // 345
                                        else if (accept.match(/\bdeflate\b/)) {                                       // 338
                                                headers['Content-Encoding'] = 'deflate';                              // 347
                                                delete headers['Content-Length'];                                     // 348
                                                res.writeHead(status, headers);                                       // 349
                                                ws.pipe(zlib.createDeflate()).pipe(res);                              // 350
                                                return {                                                              // 351
                                                    v: void 0                                                         // 351
                                                };                                                                    // 351
                                            }                                                                         // 352
                                    }                                                                                 // 353
                                }                                                                                     // 354
                                                                                                                      //
                                // Send raw data                                                                      // 356
                                if (!headers['Content-Encoding']) {                                                   // 357
                                    res.writeHead(status, headers);                                                   // 358
                                    ws.pipe(res);                                                                     // 359
                                }                                                                                     // 360
                            }();                                                                                      // 237
                                                                                                                      //
                            if ((typeof _ret4 === 'undefined' ? 'undefined' : _typeof(_ret4)) === "object") return _ret4.v;
                        } else {                                                                                      // 362
                            res.end();                                                                                // 363
                        }                                                                                             // 364
                    });                                                                                               // 365
                }();                                                                                                  // 189
                                                                                                                      //
                if ((typeof _ret3 === 'undefined' ? 'undefined' : _typeof(_ret3)) === "object") return _ret3.v;       // 189
            } else {                                                                                                  // 366
                next();                                                                                               // 367
            }                                                                                                         // 368
        });                                                                                                           // 369
    })();                                                                                                             // 32
}                                                                                                                     // 370
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-store-permissions.js":["babel-runtime/helpers/classCallCheck","meteor/underscore",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-store-permissions.js                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({StorePermissions:function(){return StorePermissions}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      //
/**                                                                                                                   // 29
 * Store permissions                                                                                                  //
 */                                                                                                                   //
var StorePermissions = function () {                                                                                  // 32
    function StorePermissions(options) {                                                                              // 34
        _classCallCheck(this, StorePermissions);                                                                      // 34
                                                                                                                      //
        // Default options                                                                                            // 35
        options = _.extend({                                                                                          // 36
            insert: null,                                                                                             // 37
            remove: null,                                                                                             // 38
            update: null                                                                                              // 39
        }, options);                                                                                                  // 36
                                                                                                                      //
        // Check options                                                                                              // 42
        if (options.insert && typeof options.insert !== 'function') {                                                 // 43
            throw new TypeError("StorePermissions: insert is not a function");                                        // 44
        }                                                                                                             // 45
        if (options.remove && typeof options.remove !== 'function') {                                                 // 46
            throw new TypeError("StorePermissions: remove is not a function");                                        // 47
        }                                                                                                             // 48
        if (options.update && typeof options.update !== 'function') {                                                 // 49
            throw new TypeError("StorePermissions: update is not a function");                                        // 50
        }                                                                                                             // 51
                                                                                                                      //
        this.actions = {                                                                                              // 53
            insert: options.insert,                                                                                   // 54
            remove: options.remove,                                                                                   // 55
            update: options.update                                                                                    // 56
        };                                                                                                            // 53
    }                                                                                                                 // 58
                                                                                                                      //
    /**                                                                                                               // 60
     * Checks the permission for the action                                                                           //
     * @param action                                                                                                  //
     * @param userId                                                                                                  //
     * @param file                                                                                                    //
     * @param fields                                                                                                  //
     * @param modifiers                                                                                               //
     * @return {*}                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    StorePermissions.prototype.check = function () {                                                                  // 32
        function check(action, userId, file, fields, modifiers) {                                                     // 32
            if (typeof this.actions[action] === 'function') {                                                         // 70
                return this.actions[action](userId, file, fields, modifiers);                                         // 71
            }                                                                                                         // 72
            return true; // by default allow all                                                                      // 73
        }                                                                                                             // 74
                                                                                                                      //
        return check;                                                                                                 // 32
    }();                                                                                                              // 32
                                                                                                                      //
    /**                                                                                                               // 76
     * Checks the insert permission                                                                                   //
     * @param userId                                                                                                  //
     * @param file                                                                                                    //
     * @returns {*}                                                                                                   //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    StorePermissions.prototype.checkInsert = function () {                                                            // 32
        function checkInsert(userId, file) {                                                                          // 32
            return this.check('insert', userId, file);                                                                // 83
        }                                                                                                             // 84
                                                                                                                      //
        return checkInsert;                                                                                           // 32
    }();                                                                                                              // 32
                                                                                                                      //
    /**                                                                                                               // 86
     * Checks the remove permission                                                                                   //
     * @param userId                                                                                                  //
     * @param file                                                                                                    //
     * @returns {*}                                                                                                   //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    StorePermissions.prototype.checkRemove = function () {                                                            // 32
        function checkRemove(userId, file) {                                                                          // 32
            return this.check('remove', userId, file);                                                                // 93
        }                                                                                                             // 94
                                                                                                                      //
        return checkRemove;                                                                                           // 32
    }();                                                                                                              // 32
                                                                                                                      //
    /**                                                                                                               // 96
     * Checks the update permission                                                                                   //
     * @param userId                                                                                                  //
     * @param file                                                                                                    //
     * @param fields                                                                                                  //
     * @param modifiers                                                                                               //
     * @returns {*}                                                                                                   //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    StorePermissions.prototype.checkUpdate = function () {                                                            // 32
        function checkUpdate(userId, file, fields, modifiers) {                                                       // 32
            return this.check('update', userId, file, fields, modifiers);                                             // 105
        }                                                                                                             // 106
                                                                                                                      //
        return checkUpdate;                                                                                           // 32
    }();                                                                                                              // 32
                                                                                                                      //
    return StorePermissions;                                                                                          // 32
}();                                                                                                                  // 32
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-store.js":["babel-runtime/helpers/classCallCheck","meteor/underscore","meteor/check","meteor/meteor","meteor/mongo","./ufs","./ufs-filter","./ufs-store-permissions","./ufs-tokens",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-store.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Store:function(){return Store}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var UploadFS;module.import('./ufs',{"UploadFS":function(v){UploadFS=v}});var Filter;module.import('./ufs-filter',{"Filter":function(v){Filter=v}});var StorePermissions;module.import('./ufs-store-permissions',{"StorePermissions":function(v){StorePermissions=v}});var Tokens;module.import('./ufs-tokens',{"Tokens":function(v){Tokens=v}});
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      // 27
                                                                                                                      // 28
                                                                                                                      // 29
                                                                                                                      // 30
                                                                                                                      // 31
                                                                                                                      // 32
                                                                                                                      // 33
                                                                                                                      //
/**                                                                                                                   // 36
 * File store                                                                                                         //
 */                                                                                                                   //
var Store = function () {                                                                                             // 39
    function Store(options) {                                                                                         // 41
        _classCallCheck(this, Store);                                                                                 // 41
                                                                                                                      //
        var self = this;                                                                                              // 42
                                                                                                                      //
        // Default options                                                                                            // 44
        options = _.extend({                                                                                          // 45
            collection: null,                                                                                         // 46
            filter: null,                                                                                             // 47
            name: null,                                                                                               // 48
            onCopyError: null,                                                                                        // 49
            onFinishUpload: null,                                                                                     // 50
            onRead: null,                                                                                             // 51
            onReadError: null,                                                                                        // 52
            onValidate: this.onValidate,                                                                              // 53
            onWriteError: null,                                                                                       // 54
            permissions: null,                                                                                        // 55
            transformRead: null,                                                                                      // 56
            transformWrite: null                                                                                      // 57
        }, options);                                                                                                  // 45
                                                                                                                      //
        // Check instance                                                                                             // 60
        if (!(self instanceof Store)) {                                                                               // 61
            throw new Error('UploadFS.Store is not an instance');                                                     // 62
        }                                                                                                             // 63
                                                                                                                      //
        // Check options                                                                                              // 65
        if (!(options.collection instanceof Mongo.Collection)) {                                                      // 66
            throw new TypeError('Store: collection is not a Mongo.Collection');                                       // 67
        }                                                                                                             // 68
        if (options.filter && !(options.filter instanceof Filter)) {                                                  // 69
            throw new TypeError('Store: filter is not a UploadFS.Filter');                                            // 70
        }                                                                                                             // 71
        if (typeof options.name !== 'string') {                                                                       // 72
            throw new TypeError('Store: name is not a string');                                                       // 73
        }                                                                                                             // 74
        if (UploadFS.getStore(options.name)) {                                                                        // 75
            throw new TypeError('Store: name already exists');                                                        // 76
        }                                                                                                             // 77
        if (options.onCopyError && typeof options.onCopyError !== 'function') {                                       // 78
            throw new TypeError('Store: onCopyError is not a function');                                              // 79
        }                                                                                                             // 80
        if (options.onFinishUpload && typeof options.onFinishUpload !== 'function') {                                 // 81
            throw new TypeError('Store: onFinishUpload is not a function');                                           // 82
        }                                                                                                             // 83
        if (options.onRead && typeof options.onRead !== 'function') {                                                 // 84
            throw new TypeError('Store: onRead is not a function');                                                   // 85
        }                                                                                                             // 86
        if (options.onReadError && typeof options.onReadError !== 'function') {                                       // 87
            throw new TypeError('Store: onReadError is not a function');                                              // 88
        }                                                                                                             // 89
        if (options.onWriteError && typeof options.onWriteError !== 'function') {                                     // 90
            throw new TypeError('Store: onWriteError is not a function');                                             // 91
        }                                                                                                             // 92
        if (options.permissions && !(options.permissions instanceof StorePermissions)) {                              // 93
            throw new TypeError('Store: permissions is not a UploadFS.StorePermissions');                             // 94
        }                                                                                                             // 95
        if (options.transformRead && typeof options.transformRead !== 'function') {                                   // 96
            throw new TypeError('Store: transformRead is not a function');                                            // 97
        }                                                                                                             // 98
        if (options.transformWrite && typeof options.transformWrite !== 'function') {                                 // 99
            throw new TypeError('Store: transformWrite is not a function');                                           // 100
        }                                                                                                             // 101
        if (options.onValidate && typeof options.onValidate !== 'function') {                                         // 102
            throw new TypeError('Store: onValidate is not a function');                                               // 103
        }                                                                                                             // 104
                                                                                                                      //
        // Public attributes                                                                                          // 106
        self.onCopyError = options.onCopyError || self.onCopyError;                                                   // 107
        self.onFinishUpload = options.onFinishUpload || self.onFinishUpload;                                          // 108
        self.onRead = options.onRead || self.onRead;                                                                  // 109
        self.onReadError = options.onReadError || self.onReadError;                                                   // 110
        self.onWriteError = options.onWriteError || self.onWriteError;                                                // 111
        self.permissions = options.permissions;                                                                       // 112
        self.onValidate = options.onValidate;                                                                         // 113
                                                                                                                      //
        // Private attributes                                                                                         // 115
        var collection = options.collection;                                                                          // 116
        var copyTo = options.copyTo;                                                                                  // 117
        var filter = options.filter;                                                                                  // 118
        var name = options.name;                                                                                      // 119
        var transformRead = options.transformRead;                                                                    // 120
        var transformWrite = options.transformWrite;                                                                  // 121
                                                                                                                      //
        // Set default permissions                                                                                    // 123
        if (!(self.permissions instanceof StorePermissions)) {                                                        // 124
            // Uses custom default permissions or UFS default permissions                                             // 125
            if (UploadFS.config.defaultStorePermissions instanceof StorePermissions) {                                // 126
                self.permissions = UploadFS.config.defaultStorePermissions;                                           // 127
            } else {                                                                                                  // 128
                self.permissions = new StorePermissions();                                                            // 129
                console.warn('ufs: permissions are not defined for store "' + name + '"');                            // 130
            }                                                                                                         // 131
        }                                                                                                             // 132
                                                                                                                      //
        // Add the store to the list                                                                                  // 134
        UploadFS.getStores()[name] = self;                                                                            // 135
                                                                                                                      //
        /**                                                                                                           // 137
         * Returns the collection                                                                                     //
         * @return {Mongo.Collection}                                                                                 //
         */                                                                                                           //
        self.getCollection = function () {                                                                            // 141
            return collection;                                                                                        // 142
        };                                                                                                            // 143
                                                                                                                      //
        /**                                                                                                           // 145
         * Returns the file filter                                                                                    //
         * @return {UploadFS.Filter}                                                                                  //
         */                                                                                                           //
        self.getFilter = function () {                                                                                // 149
            return filter;                                                                                            // 150
        };                                                                                                            // 151
                                                                                                                      //
        /**                                                                                                           // 153
         * Returns the store name                                                                                     //
         * @return {string}                                                                                           //
         */                                                                                                           //
        self.getName = function () {                                                                                  // 157
            return name;                                                                                              // 158
        };                                                                                                            // 159
                                                                                                                      //
        /**                                                                                                           // 161
         * Defines the store permissions                                                                              //
         * @param permissions                                                                                         //
         */                                                                                                           //
        self.setPermissions = function (permissions) {                                                                // 165
            if (!(permissions instanceof StorePermissions)) {                                                         // 166
                throw new TypeError("permissions is not an instance of UploadFS.StorePermissions");                   // 167
            }                                                                                                         // 168
            self.permissions = permissions;                                                                           // 169
        };                                                                                                            // 170
                                                                                                                      //
        if (Meteor.isServer) {                                                                                        // 172
                                                                                                                      //
            /**                                                                                                       // 174
             * Checks token validity                                                                                  //
             * @param token                                                                                           //
             * @param fileId                                                                                          //
             * @returns {boolean}                                                                                     //
             */                                                                                                       //
            self.checkToken = function (token, fileId) {                                                              // 180
                check(token, String);                                                                                 // 181
                check(fileId, String);                                                                                // 182
                return Tokens.find({ value: token, fileId: fileId }).count() === 1;                                   // 183
            };                                                                                                        // 184
                                                                                                                      //
            /**                                                                                                       // 186
             * Copies the file to a store                                                                             //
             * @param fileId                                                                                          //
             * @param store                                                                                           //
             * @param callback                                                                                        //
             */                                                                                                       //
            self.copy = function (fileId, store, callback) {                                                          // 192
                check(fileId, String);                                                                                // 193
                                                                                                                      //
                if (!(store instanceof Store)) {                                                                      // 195
                    throw new TypeError('store is not an instance of UploadFS.Store');                                // 196
                }                                                                                                     // 197
                // Get original file                                                                                  // 198
                var file = collection.findOne({ _id: fileId });                                                       // 199
                if (!file) {                                                                                          // 200
                    throw new Meteor.Error('file-not-found', 'File not found');                                       // 201
                }                                                                                                     // 202
                // Silently ignore the file if it does not match filter                                               // 203
                var filter = store.getFilter();                                                                       // 204
                if (filter instanceof Filter && !filter.isValid(file)) {                                              // 205
                    return;                                                                                           // 206
                }                                                                                                     // 207
                                                                                                                      //
                // Prepare copy                                                                                       // 209
                var copy = _.omit(file, '_id', 'url');                                                                // 210
                copy.originalStore = self.getName();                                                                  // 211
                copy.originalId = fileId;                                                                             // 212
                                                                                                                      //
                // Create the copy                                                                                    // 214
                var copyId = store.create(copy);                                                                      // 215
                                                                                                                      //
                // Get original stream                                                                                // 217
                var rs = self.getReadStream(fileId, file);                                                            // 218
                                                                                                                      //
                // Catch errors to avoid app crashing                                                                 // 220
                rs.on('error', Meteor.bindEnvironment(function (err) {                                                // 221
                    callback.call(self, err, null);                                                                   // 222
                }));                                                                                                  // 223
                                                                                                                      //
                // Copy file data                                                                                     // 225
                store.write(rs, copyId, Meteor.bindEnvironment(function (err) {                                       // 226
                    if (err) {                                                                                        // 227
                        collection.remove({ _id: copyId });                                                           // 228
                        self.onCopyError.call(self, err, fileId, file);                                               // 229
                    }                                                                                                 // 230
                    if (typeof callback === 'function') {                                                             // 231
                        callback.call(self, err, copyId, copy, store);                                                // 232
                    }                                                                                                 // 233
                }));                                                                                                  // 234
            };                                                                                                        // 235
                                                                                                                      //
            /**                                                                                                       // 237
             * Creates the file in the collection                                                                     //
             * @param file                                                                                            //
             * @param callback                                                                                        //
             * @return {string}                                                                                       //
             */                                                                                                       //
            self.create = function (file, callback) {                                                                 // 243
                check(file, Object);                                                                                  // 244
                file.store = name;                                                                                    // 245
                return collection.insert(file, callback);                                                             // 246
            };                                                                                                        // 247
                                                                                                                      //
            /**                                                                                                       // 249
             * Creates a token for the file (only needed for client side upload)                                      //
             * @param fileId                                                                                          //
             * @returns {*}                                                                                           //
             */                                                                                                       //
            self.createToken = function (fileId) {                                                                    // 254
                var token = self.generateToken();                                                                     // 255
                                                                                                                      //
                // Check if token exists                                                                              // 257
                if (Tokens.find({ fileId: fileId }).count()) {                                                        // 258
                    Tokens.update({ fileId: fileId }, {                                                               // 259
                        $set: {                                                                                       // 260
                            createdAt: new Date(),                                                                    // 261
                            value: token                                                                              // 262
                        }                                                                                             // 260
                    });                                                                                               // 259
                } else {                                                                                              // 265
                    Tokens.insert({                                                                                   // 266
                        createdAt: new Date(),                                                                        // 267
                        fileId: fileId,                                                                               // 268
                        value: token                                                                                  // 269
                    });                                                                                               // 266
                }                                                                                                     // 271
                return token;                                                                                         // 272
            };                                                                                                        // 273
                                                                                                                      //
            /**                                                                                                       // 275
             * Generates a random token                                                                               //
             * @param pattern                                                                                         //
             * @return {string}                                                                                       //
             */                                                                                                       //
            self.generateToken = function (pattern) {                                                                 // 280
                return (pattern || 'xyxyxyxyxy').replace(/[xy]/g, function (c) {                                      // 281
                    var r = Math.random() * 16 | 0,                                                                   // 282
                        v = c == 'x' ? r : r & 0x3 | 0x8;                                                             // 282
                    var s = v.toString(16);                                                                           // 283
                    return Math.round(Math.random()) ? s.toUpperCase() : s;                                           // 284
                });                                                                                                   // 285
            };                                                                                                        // 286
                                                                                                                      //
            /**                                                                                                       // 288
             * Transforms the file on reading                                                                         //
             * @param readStream                                                                                      //
             * @param writeStream                                                                                     //
             * @param fileId                                                                                          //
             * @param file                                                                                            //
             * @param request                                                                                         //
             * @param headers                                                                                         //
             */                                                                                                       //
            self.transformRead = function (readStream, writeStream, fileId, file, request, headers) {                 // 297
                if (typeof transformRead === 'function') {                                                            // 298
                    transformRead.call(self, readStream, writeStream, fileId, file, request, headers);                // 299
                } else {                                                                                              // 300
                    readStream.pipe(writeStream);                                                                     // 301
                }                                                                                                     // 302
            };                                                                                                        // 303
                                                                                                                      //
            /**                                                                                                       // 305
             * Transforms the file on writing                                                                         //
             * @param readStream                                                                                      //
             * @param writeStream                                                                                     //
             * @param fileId                                                                                          //
             * @param file                                                                                            //
             */                                                                                                       //
            self.transformWrite = function (readStream, writeStream, fileId, file) {                                  // 312
                if (typeof transformWrite === 'function') {                                                           // 313
                    transformWrite.call(self, readStream, writeStream, fileId, file);                                 // 314
                } else {                                                                                              // 315
                    readStream.pipe(writeStream);                                                                     // 316
                }                                                                                                     // 317
            };                                                                                                        // 318
                                                                                                                      //
            /**                                                                                                       // 320
             * Writes the file to the store                                                                           //
             * @param rs                                                                                              //
             * @param fileId                                                                                          //
             * @param callback                                                                                        //
             */                                                                                                       //
            self.write = function (rs, fileId, callback) {                                                            // 326
                var file = collection.findOne({ _id: fileId });                                                       // 327
                var ws = self.getWriteStream(fileId, file);                                                           // 328
                                                                                                                      //
                var errorHandler = Meteor.bindEnvironment(function (err) {                                            // 330
                    collection.remove({ _id: fileId });                                                               // 331
                    self.onWriteError.call(self, err, fileId, file);                                                  // 332
                    callback.call(self, err);                                                                         // 333
                });                                                                                                   // 334
                                                                                                                      //
                ws.on('error', errorHandler);                                                                         // 336
                ws.on('finish', Meteor.bindEnvironment(function () {                                                  // 337
                    var size = 0;                                                                                     // 338
                    var readStream = self.getReadStream(fileId, file);                                                // 339
                                                                                                                      //
                    readStream.on('error', Meteor.bindEnvironment(function (error) {                                  // 341
                        callback.call(self, error, null);                                                             // 342
                    }));                                                                                              // 343
                    readStream.on('data', Meteor.bindEnvironment(function (data) {                                    // 344
                        size += data.length;                                                                          // 345
                    }));                                                                                              // 346
                    readStream.on('end', Meteor.bindEnvironment(function () {                                         // 347
                        // Set file attribute                                                                         // 348
                        file.complete = true;                                                                         // 349
                        file.etag = UploadFS.generateEtag();                                                          // 350
                        file.path = self.getFileRelativeURL(fileId);                                                  // 351
                        file.progress = 1;                                                                            // 352
                        file.size = size;                                                                             // 353
                        file.token = self.generateToken();                                                            // 354
                        file.uploading = false;                                                                       // 355
                        file.uploadedAt = new Date();                                                                 // 356
                        file.url = self.getFileURL(fileId);                                                           // 357
                                                                                                                      //
                        // Sets the file URL when file transfer is complete,                                          // 359
                        // this way, the image will loads entirely.                                                   // 360
                        collection.direct.update({ _id: fileId }, {                                                   // 361
                            $set: {                                                                                   // 362
                                complete: file.complete,                                                              // 363
                                etag: file.etag,                                                                      // 364
                                path: file.path,                                                                      // 365
                                progress: file.progress,                                                              // 366
                                size: file.size,                                                                      // 367
                                token: file.token,                                                                    // 368
                                uploading: file.uploading,                                                            // 369
                                uploadedAt: file.uploadedAt,                                                          // 370
                                url: file.url                                                                         // 371
                            }                                                                                         // 362
                        });                                                                                           // 361
                                                                                                                      //
                        // Return file info                                                                           // 375
                        callback.call(self, null, file);                                                              // 376
                                                                                                                      //
                        // Execute callback                                                                           // 378
                        if (typeof self.onFinishUpload == 'function') {                                               // 379
                            self.onFinishUpload.call(self, file);                                                     // 380
                        }                                                                                             // 381
                                                                                                                      //
                        // Simulate write speed                                                                       // 383
                        if (UploadFS.config.simulateWriteDelay) {                                                     // 384
                            Meteor._sleepForMs(UploadFS.config.simulateWriteDelay);                                   // 385
                        }                                                                                             // 386
                                                                                                                      //
                        // Copy file to other stores                                                                  // 388
                        if (copyTo instanceof Array) {                                                                // 389
                            for (var i = 0; i < copyTo.length; i += 1) {                                              // 390
                                var store = copyTo[i];                                                                // 391
                                                                                                                      //
                                if (!store.getFilter() || store.getFilter().isValid(file)) {                          // 393
                                    self.copy(fileId, store);                                                         // 394
                                }                                                                                     // 395
                            }                                                                                         // 396
                        }                                                                                             // 397
                    }));                                                                                              // 398
                }));                                                                                                  // 399
                                                                                                                      //
                // Execute transformation                                                                             // 401
                self.transformWrite(rs, ws, fileId, file);                                                            // 402
            };                                                                                                        // 403
        }                                                                                                             // 404
                                                                                                                      //
        if (Meteor.isServer) {                                                                                        // 406
            (function () {                                                                                            // 406
                var fs = Npm.require('fs');                                                                           // 407
                                                                                                                      //
                // Code executed after removing file                                                                  // 409
                collection.after.remove(function (userId, file) {                                                     // 410
                    // Remove associated tokens                                                                       // 411
                    Tokens.remove({ fileId: file._id });                                                              // 412
                                                                                                                      //
                    if (copyTo instanceof Array) {                                                                    // 414
                        for (var i = 0; i < copyTo.length; i += 1) {                                                  // 415
                            // Remove copies in stores                                                                // 416
                            copyTo[i].getCollection().remove({ originalId: file._id });                               // 417
                        }                                                                                             // 418
                    }                                                                                                 // 419
                });                                                                                                   // 420
                                                                                                                      //
                // Code executed before inserting file                                                                // 422
                collection.before.insert(function (userId, file) {                                                    // 423
                    if (!self.permissions.checkInsert(userId, file)) {                                                // 424
                        throw new Meteor.Error('forbidden', "Forbidden");                                             // 425
                    }                                                                                                 // 426
                });                                                                                                   // 427
                                                                                                                      //
                // Code executed before updating file                                                                 // 429
                collection.before.update(function (userId, file, fields, modifiers) {                                 // 430
                    if (!self.permissions.checkUpdate(userId, file, fields, modifiers)) {                             // 431
                        throw new Meteor.Error('forbidden', "Forbidden");                                             // 432
                    }                                                                                                 // 433
                });                                                                                                   // 434
                                                                                                                      //
                // Code executed before removing file                                                                 // 436
                collection.before.remove(function (userId, file) {                                                    // 437
                    if (!self.permissions.checkRemove(userId, file)) {                                                // 438
                        throw new Meteor.Error('forbidden', "Forbidden");                                             // 439
                    }                                                                                                 // 440
                                                                                                                      //
                    // Delete the physical file in the store                                                          // 442
                    self['delete'](file._id);                                                                         // 443
                                                                                                                      //
                    var tmpFile = UploadFS.getTempFilePath(file._id);                                                 // 445
                                                                                                                      //
                    // Delete the temp file                                                                           // 447
                    fs.stat(tmpFile, function (err) {                                                                 // 448
                        !err && fs.unlink(tmpFile, function (err) {                                                   // 449
                            err && console.error('ufs: cannot delete temp file at ' + tmpFile + ' (' + err.message + ')');
                        });                                                                                           // 451
                    });                                                                                               // 452
                });                                                                                                   // 453
                                                                                                                      //
                /**                                                                                                   // 455
                 * Deletes a file async                                                                               //
                 * @param fileId                                                                                      //
                 * @param callback                                                                                    //
                 */                                                                                                   //
                self['delete'] = function (fileId, callback) {                                                        // 460
                    throw new Error('delete is not implemented');                                                     // 461
                };                                                                                                    // 462
                                                                                                                      //
                /**                                                                                                   // 464
                 * Returns the file read stream                                                                       //
                 * @param fileId                                                                                      //
                 * @param file                                                                                        //
                 */                                                                                                   //
                self.getReadStream = function (fileId, file) {                                                        // 469
                    throw new Error('getReadStream is not implemented');                                              // 470
                };                                                                                                    // 471
                                                                                                                      //
                /**                                                                                                   // 473
                 * Returns the file write stream                                                                      //
                 * @param fileId                                                                                      //
                 * @param file                                                                                        //
                 */                                                                                                   //
                self.getWriteStream = function (fileId, file) {                                                       // 478
                    throw new Error('getWriteStream is not implemented');                                             // 479
                };                                                                                                    // 480
                                                                                                                      //
                /**                                                                                                   // 482
                 * Callback for copy errors                                                                           //
                 * @param err                                                                                         //
                 * @param fileId                                                                                      //
                 * @param file                                                                                        //
                 * @return boolean                                                                                    //
                 */                                                                                                   //
                self.onCopyError = function (err, fileId, file) {                                                     // 489
                    console.error('ufs: cannot copy file "' + fileId + '" (' + err.message + ')', err);               // 490
                };                                                                                                    // 491
                                                                                                                      //
                /**                                                                                                   // 493
                 * Called when a file has been uploaded                                                               //
                 * @param file                                                                                        //
                 */                                                                                                   //
                self.onFinishUpload = function (file) {};                                                             // 497
                                                                                                                      //
                /**                                                                                                   // 500
                 * Called when a file is read from the store                                                          //
                 * @param fileId                                                                                      //
                 * @param file                                                                                        //
                 * @param request                                                                                     //
                 * @param response                                                                                    //
                 * @return boolean                                                                                    //
                 */                                                                                                   //
                self.onRead = function (fileId, file, request, response) {                                            // 508
                    return true;                                                                                      // 509
                };                                                                                                    // 510
                                                                                                                      //
                /**                                                                                                   // 512
                 * Callback for read errors                                                                           //
                 * @param err                                                                                         //
                 * @param fileId                                                                                      //
                 * @param file                                                                                        //
                 * @return boolean                                                                                    //
                 */                                                                                                   //
                self.onReadError = function (err, fileId, file) {                                                     // 519
                    console.error('ufs: cannot read file "' + fileId + '" (' + err.message + ')', err);               // 520
                };                                                                                                    // 521
                                                                                                                      //
                /**                                                                                                   // 523
                 * Callback for write errors                                                                          //
                 * @param err                                                                                         //
                 * @param fileId                                                                                      //
                 * @param file                                                                                        //
                 * @return boolean                                                                                    //
                 */                                                                                                   //
                self.onWriteError = function (err, fileId, file) {                                                    // 530
                    console.error('ufs: cannot write file "' + fileId + '" (' + err.message + ')', err);              // 531
                };                                                                                                    // 532
            })();                                                                                                     // 406
        }                                                                                                             // 533
    }                                                                                                                 // 534
                                                                                                                      //
    /**                                                                                                               // 536
     * Returns the file URL                                                                                           //
     * @param fileId                                                                                                  //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Store.prototype.getFileRelativeURL = function () {                                                                // 39
        function getFileRelativeURL(fileId) {                                                                         // 39
            var file = this.getCollection().findOne(fileId, { fields: { name: 1 } });                                 // 541
            return file ? this.getRelativeURL(fileId + '/' + file.name) : null;                                       // 542
        }                                                                                                             // 543
                                                                                                                      //
        return getFileRelativeURL;                                                                                    // 39
    }();                                                                                                              // 39
                                                                                                                      //
    /**                                                                                                               // 545
     * Returns the file URL                                                                                           //
     * @param fileId                                                                                                  //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Store.prototype.getFileURL = function () {                                                                        // 39
        function getFileURL(fileId) {                                                                                 // 39
            var file = this.getCollection().findOne(fileId, { fields: { name: 1 } });                                 // 550
            return file ? this.getURL(fileId + '/' + file.name) : null;                                               // 551
        }                                                                                                             // 552
                                                                                                                      //
        return getFileURL;                                                                                            // 39
    }();                                                                                                              // 39
                                                                                                                      //
    /**                                                                                                               // 554
     * Returns the store relative URL                                                                                 //
     * @param path                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Store.prototype.getRelativeURL = function () {                                                                    // 39
        function getRelativeURL(path) {                                                                               // 39
            var rootUrl = Meteor.absoluteUrl().replace(/\/+$/, '');                                                   // 559
            var rootPath = rootUrl.replace(/^[a-z]+:\/\/[^/]+\/*/gi, '');                                             // 560
            var storeName = this.getName();                                                                           // 561
            path = String(path).replace(/\/$/, '').trim();                                                            // 562
            return encodeURI(rootPath + '/' + UploadFS.config.storesPath + '/' + storeName + '/' + path);             // 563
        }                                                                                                             // 564
                                                                                                                      //
        return getRelativeURL;                                                                                        // 39
    }();                                                                                                              // 39
                                                                                                                      //
    /**                                                                                                               // 566
     * Returns the store absolute URL                                                                                 //
     * @param path                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Store.prototype.getURL = function () {                                                                            // 39
        function getURL(path) {                                                                                       // 39
            var rootUrl = Meteor.absoluteUrl().replace(/\/+$/, '');                                                   // 571
            var storeName = this.getName();                                                                           // 572
            path = String(path).replace(/\/$/, '').trim();                                                            // 573
            return encodeURI(rootUrl + '/' + UploadFS.config.storesPath + '/' + storeName + '/' + path);              // 574
        }                                                                                                             // 575
                                                                                                                      //
        return getURL;                                                                                                // 39
    }();                                                                                                              // 39
                                                                                                                      //
    /**                                                                                                               // 577
     * Completes the file upload                                                                                      //
     * @param url                                                                                                     //
     * @param file                                                                                                    //
     * @param callback                                                                                                //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Store.prototype.importFromURL = function () {                                                                     // 39
        function importFromURL(url, file, callback) {                                                                 // 39
            Meteor.call('ufsImportURL', url, file, this.getName(), callback);                                         // 584
        }                                                                                                             // 585
                                                                                                                      //
        return importFromURL;                                                                                         // 39
    }();                                                                                                              // 39
                                                                                                                      //
    /**                                                                                                               // 587
     * Validates the file                                                                                             //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Store.prototype.onValidate = function () {                                                                        // 39
        function onValidate(file) {}                                                                                  // 39
                                                                                                                      //
        return onValidate;                                                                                            // 39
    }();                                                                                                              // 39
                                                                                                                      //
    /**                                                                                                               // 594
     * Validates the file                                                                                             //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Store.prototype.validate = function () {                                                                          // 39
        function validate(file) {                                                                                     // 39
            if (typeof this.onValidate === 'function') {                                                              // 599
                this.onValidate(file);                                                                                // 600
            }                                                                                                         // 601
        }                                                                                                             // 602
                                                                                                                      //
        return validate;                                                                                              // 39
    }();                                                                                                              // 39
                                                                                                                      //
    return Store;                                                                                                     // 39
}();                                                                                                                  // 39
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-template-helpers.js":["meteor/templating",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-template-helpers.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Template;module.import('meteor/templating',{"Template":function(v){Template=v}});/*                               // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      //
var isMIME = function isMIME(type, mime) {                                                                            // 29
    return typeof type === 'string' && typeof mime === 'string' && mime.indexOf(type + '/') === 0;                    // 30
};                                                                                                                    // 33
                                                                                                                      //
Template.registerHelper('isApplication', function (type) {                                                            // 35
    return isMIME('application', this.type || type);                                                                  // 36
});                                                                                                                   // 37
                                                                                                                      //
Template.registerHelper('isAudio', function (type) {                                                                  // 39
    return isMIME('audio', this.type || type);                                                                        // 40
});                                                                                                                   // 41
                                                                                                                      //
Template.registerHelper('isImage', function (type) {                                                                  // 43
    return isMIME('image', this.type || type);                                                                        // 44
});                                                                                                                   // 45
                                                                                                                      //
Template.registerHelper('isText', function (type) {                                                                   // 47
    return isMIME('text', this.type || type);                                                                         // 48
});                                                                                                                   // 49
                                                                                                                      //
Template.registerHelper('isVideo', function (type) {                                                                  // 51
    return isMIME('video', this.type || type);                                                                        // 52
});                                                                                                                   // 53
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-tokens.js":["meteor/mongo",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-tokens.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Tokens:function(){return Tokens}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});/*
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      //
/**                                                                                                                   // 28
 * Collection of upload tokens                                                                                        //
 * @type {Mongo.Collection}                                                                                           //
 */                                                                                                                   //
var Tokens = new Mongo.Collection('ufsTokens');                                                                       // 32
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"ufs-uploader.js":["babel-runtime/helpers/typeof","babel-runtime/helpers/classCallCheck","meteor/underscore","meteor/meteor","./ufs-store",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/jalik_ufs/ufs-uploader.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
module.export({Uploader:function(){return Uploader}});var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var _;module.import('meteor/underscore',{"_":function(v){_=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Store;module.import('./ufs-store',{"Store":function(v){Store=v}});
                                                                                                                      //
/*                                                                                                                    // 1
 * The MIT License (MIT)                                                                                              //
 *                                                                                                                    //
 * Copyright (c) 2017 Karl STEIN                                                                                      //
 *                                                                                                                    //
 * Permission is hereby granted, free of charge, to any person obtaining a copy                                       //
 * of this software and associated documentation files (the "Software"), to deal                                      //
 * in the Software without restriction, including without limitation the rights                                       //
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell                                          //
 * copies of the Software, and to permit persons to whom the Software is                                              //
 * furnished to do so, subject to the following conditions:                                                           //
 *                                                                                                                    //
 * The above copyright notice and this permission notice shall be included in all                                     //
 * copies or substantial portions of the Software.                                                                    //
 *                                                                                                                    //
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                                         //
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                           //
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                                        //
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                             //
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                                      //
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE                                      //
 * SOFTWARE.                                                                                                          //
 *                                                                                                                    //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      // 26
                                                                                                                      // 27
                                                                                                                      // 28
                                                                                                                      //
/**                                                                                                                   // 31
 * File uploader                                                                                                      //
 */                                                                                                                   //
var Uploader = function () {                                                                                          // 34
    function Uploader(options) {                                                                                      // 36
        _classCallCheck(this, Uploader);                                                                              // 36
                                                                                                                      //
        var self = this;                                                                                              // 37
                                                                                                                      //
        // Set default options                                                                                        // 39
        options = _.extend({                                                                                          // 40
            adaptive: true,                                                                                           // 41
            capacity: 0.9,                                                                                            // 42
            chunkSize: 16 * 1024,                                                                                     // 43
            data: null,                                                                                               // 44
            file: null,                                                                                               // 45
            maxChunkSize: 4 * 1024 * 1000,                                                                            // 46
            maxTries: 5,                                                                                              // 47
            onAbort: this.onAbort,                                                                                    // 48
            onComplete: this.onComplete,                                                                              // 49
            onCreate: this.onCreate,                                                                                  // 50
            onError: this.onError,                                                                                    // 51
            onProgress: this.onProgress,                                                                              // 52
            onStart: this.onStart,                                                                                    // 53
            onStop: this.onStop,                                                                                      // 54
            retryDelay: 2000,                                                                                         // 55
            store: null,                                                                                              // 56
            transferDelay: 100                                                                                        // 57
        }, options);                                                                                                  // 40
                                                                                                                      //
        // Check options                                                                                              // 60
        if (typeof options.adaptive !== 'boolean') {                                                                  // 61
            throw new TypeError('adaptive is not a number');                                                          // 62
        }                                                                                                             // 63
        if (typeof options.capacity !== 'number') {                                                                   // 64
            throw new TypeError('capacity is not a number');                                                          // 65
        }                                                                                                             // 66
        if (options.capacity <= 0 || options.capacity > 1) {                                                          // 67
            throw new RangeError('capacity must be a float between 0.1 and 1.0');                                     // 68
        }                                                                                                             // 69
        if (typeof options.chunkSize !== 'number') {                                                                  // 70
            throw new TypeError('chunkSize is not a number');                                                         // 71
        }                                                                                                             // 72
        if (!(options.data instanceof Blob) && !(options.data instanceof File)) {                                     // 73
            throw new TypeError('data is not an Blob or File');                                                       // 74
        }                                                                                                             // 75
        if (options.file === null || _typeof(options.file) !== 'object') {                                            // 76
            throw new TypeError('file is not an object');                                                             // 77
        }                                                                                                             // 78
        if (typeof options.maxChunkSize !== 'number') {                                                               // 79
            throw new TypeError('maxChunkSize is not a number');                                                      // 80
        }                                                                                                             // 81
        if (typeof options.maxTries !== 'number') {                                                                   // 82
            throw new TypeError('maxTries is not a number');                                                          // 83
        }                                                                                                             // 84
        if (typeof options.retryDelay !== 'number') {                                                                 // 85
            throw new TypeError('retryDelay is not a number');                                                        // 86
        }                                                                                                             // 87
        if (typeof options.transferDelay !== 'number') {                                                              // 88
            throw new TypeError('transferDelay is not a number');                                                     // 89
        }                                                                                                             // 90
        if (typeof options.onAbort !== 'function') {                                                                  // 91
            throw new TypeError('onAbort is not a function');                                                         // 92
        }                                                                                                             // 93
        if (typeof options.onComplete !== 'function') {                                                               // 94
            throw new TypeError('onComplete is not a function');                                                      // 95
        }                                                                                                             // 96
        if (typeof options.onCreate !== 'function') {                                                                 // 97
            throw new TypeError('onCreate is not a function');                                                        // 98
        }                                                                                                             // 99
        if (typeof options.onError !== 'function') {                                                                  // 100
            throw new TypeError('onError is not a function');                                                         // 101
        }                                                                                                             // 102
        if (typeof options.onProgress !== 'function') {                                                               // 103
            throw new TypeError('onProgress is not a function');                                                      // 104
        }                                                                                                             // 105
        if (typeof options.onStart !== 'function') {                                                                  // 106
            throw new TypeError('onStart is not a function');                                                         // 107
        }                                                                                                             // 108
        if (typeof options.onStop !== 'function') {                                                                   // 109
            throw new TypeError('onStop is not a function');                                                          // 110
        }                                                                                                             // 111
        if (typeof options.store !== 'string' && !(options.store instanceof Store)) {                                 // 112
            throw new TypeError('store must be the name of the store or an instance of UploadFS.Store');              // 113
        }                                                                                                             // 114
                                                                                                                      //
        // Public attributes                                                                                          // 116
        self.adaptive = options.adaptive;                                                                             // 117
        self.capacity = parseFloat(options.capacity);                                                                 // 118
        self.chunkSize = parseInt(options.chunkSize);                                                                 // 119
        self.maxChunkSize = parseInt(options.maxChunkSize);                                                           // 120
        self.maxTries = parseInt(options.maxTries);                                                                   // 121
        self.retryDelay = parseInt(options.retryDelay);                                                               // 122
        self.transferDelay = parseInt(options.transferDelay);                                                         // 123
        self.onAbort = options.onAbort;                                                                               // 124
        self.onComplete = options.onComplete;                                                                         // 125
        self.onCreate = options.onCreate;                                                                             // 126
        self.onError = options.onError;                                                                               // 127
        self.onProgress = options.onProgress;                                                                         // 128
        self.onStart = options.onStart;                                                                               // 129
        self.onStop = options.onStop;                                                                                 // 130
                                                                                                                      //
        // Private attributes                                                                                         // 132
        var store = options.store;                                                                                    // 133
        var data = options.data;                                                                                      // 134
        var capacityMargin = 0.1;                                                                                     // 135
        var file = options.file;                                                                                      // 136
        var fileId = null;                                                                                            // 137
        var offset = 0;                                                                                               // 138
        var loaded = 0;                                                                                               // 139
        var total = data.size;                                                                                        // 140
        var tries = 0;                                                                                                // 141
        var postUrl = null;                                                                                           // 142
        var token = null;                                                                                             // 143
        var complete = false;                                                                                         // 144
        var uploading = false;                                                                                        // 145
                                                                                                                      //
        var timeA = null;                                                                                             // 147
        var timeB = null;                                                                                             // 148
                                                                                                                      //
        var elapsedTime = 0;                                                                                          // 150
        var startTime = 0;                                                                                            // 151
                                                                                                                      //
        // Keep only the name of the store                                                                            // 153
        if (store instanceof Store) {                                                                                 // 154
            store = store.getName();                                                                                  // 155
        }                                                                                                             // 156
                                                                                                                      //
        // Assign file to store                                                                                       // 158
        file.store = store;                                                                                           // 159
                                                                                                                      //
        function finish() {                                                                                           // 161
            // Finish the upload by telling the store the upload is complete                                          // 162
            Meteor.call('ufsComplete', fileId, store, token, function (err, uploadedFile) {                           // 163
                if (err) {                                                                                            // 164
                    self.onError(err, file);                                                                          // 165
                    self.abort();                                                                                     // 166
                } else if (uploadedFile) {                                                                            // 167
                    uploading = false;                                                                                // 169
                    complete = true;                                                                                  // 170
                    file = uploadedFile;                                                                              // 171
                    self.onComplete(uploadedFile);                                                                    // 172
                }                                                                                                     // 173
            });                                                                                                       // 174
        }                                                                                                             // 175
                                                                                                                      //
        /**                                                                                                           // 177
         * Aborts the current transfer                                                                                //
         */                                                                                                           //
        self.abort = function () {                                                                                    // 180
            // Remove the file from database                                                                          // 181
            Meteor.call('ufsDelete', fileId, store, token, function (err, result) {                                   // 182
                if (err) {                                                                                            // 183
                    self.onError(err, file);                                                                          // 184
                }                                                                                                     // 185
            });                                                                                                       // 186
                                                                                                                      //
            // Reset uploader status                                                                                  // 188
            uploading = false;                                                                                        // 189
            fileId = null;                                                                                            // 190
            offset = 0;                                                                                               // 191
            tries = 0;                                                                                                // 192
            loaded = 0;                                                                                               // 193
            complete = false;                                                                                         // 194
            startTime = null;                                                                                         // 195
            self.onAbort(file);                                                                                       // 196
        };                                                                                                            // 197
                                                                                                                      //
        /**                                                                                                           // 199
         * Returns the average speed in bytes per second                                                              //
         * @returns {number}                                                                                          //
         */                                                                                                           //
        self.getAverageSpeed = function () {                                                                          // 203
            var seconds = self.getElapsedTime() / 1000;                                                               // 204
            return self.getLoaded() / seconds;                                                                        // 205
        };                                                                                                            // 206
                                                                                                                      //
        /**                                                                                                           // 208
         * Returns the elapsed time in milliseconds                                                                   //
         * @returns {number}                                                                                          //
         */                                                                                                           //
        self.getElapsedTime = function () {                                                                           // 212
            if (startTime && self.isUploading()) {                                                                    // 213
                return elapsedTime + (Date.now() - startTime);                                                        // 214
            }                                                                                                         // 215
            return elapsedTime;                                                                                       // 216
        };                                                                                                            // 217
                                                                                                                      //
        /**                                                                                                           // 219
         * Returns the file                                                                                           //
         * @return {object}                                                                                           //
         */                                                                                                           //
        self.getFile = function () {                                                                                  // 223
            return file;                                                                                              // 224
        };                                                                                                            // 225
                                                                                                                      //
        /**                                                                                                           // 227
         * Returns the loaded bytes                                                                                   //
         * @return {number}                                                                                           //
         */                                                                                                           //
        self.getLoaded = function () {                                                                                // 231
            return loaded;                                                                                            // 232
        };                                                                                                            // 233
                                                                                                                      //
        /**                                                                                                           // 235
         * Returns current progress                                                                                   //
         * @return {number}                                                                                           //
         */                                                                                                           //
        self.getProgress = function () {                                                                              // 239
            return Math.min(loaded / total * 100 / 100, 1.0);                                                         // 240
        };                                                                                                            // 241
                                                                                                                      //
        /**                                                                                                           // 243
         * Returns the remaining time in milliseconds                                                                 //
         * @returns {number}                                                                                          //
         */                                                                                                           //
        self.getRemainingTime = function () {                                                                         // 247
            var averageSpeed = self.getAverageSpeed();                                                                // 248
            var remainingBytes = total - self.getLoaded();                                                            // 249
            return averageSpeed && remainingBytes ? Math.max(remainingBytes / averageSpeed, 0) : 0;                   // 250
        };                                                                                                            // 251
                                                                                                                      //
        /**                                                                                                           // 253
         * Returns the upload speed in bytes per second                                                               //
         * @returns {number}                                                                                          //
         */                                                                                                           //
        self.getSpeed = function () {                                                                                 // 257
            if (timeA && timeB && self.isUploading()) {                                                               // 258
                var seconds = (timeB - timeA) / 1000;                                                                 // 259
                return self.chunkSize / seconds;                                                                      // 260
            }                                                                                                         // 261
            return 0;                                                                                                 // 262
        };                                                                                                            // 263
                                                                                                                      //
        /**                                                                                                           // 265
         * Returns the total bytes                                                                                    //
         * @return {number}                                                                                           //
         */                                                                                                           //
        self.getTotal = function () {                                                                                 // 269
            return total;                                                                                             // 270
        };                                                                                                            // 271
                                                                                                                      //
        /**                                                                                                           // 273
         * Checks if the transfer is complete                                                                         //
         * @return {boolean}                                                                                          //
         */                                                                                                           //
        self.isComplete = function () {                                                                               // 277
            return complete;                                                                                          // 278
        };                                                                                                            // 279
                                                                                                                      //
        /**                                                                                                           // 281
         * Checks if the transfer is active                                                                           //
         * @return {boolean}                                                                                          //
         */                                                                                                           //
        self.isUploading = function () {                                                                              // 285
            return uploading;                                                                                         // 286
        };                                                                                                            // 287
                                                                                                                      //
        /**                                                                                                           // 289
         * Reads a portion of file                                                                                    //
         * @param start                                                                                               //
         * @param length                                                                                              //
         * @param callback                                                                                            //
         * @returns {Blob}                                                                                            //
         */                                                                                                           //
        self.readChunk = function (start, length, callback) {                                                         // 296
            if (typeof callback != 'function') {                                                                      // 297
                throw new Error('readChunk is missing callback');                                                     // 298
            }                                                                                                         // 299
            try {                                                                                                     // 300
                var end = void 0;                                                                                     // 301
                                                                                                                      //
                // Calculate the chunk size                                                                           // 303
                if (length && start + length > total) {                                                               // 304
                    end = total;                                                                                      // 305
                } else {                                                                                              // 306
                    end = start + length;                                                                             // 307
                }                                                                                                     // 308
                // Get chunk                                                                                          // 309
                var chunk = data.slice(start, end);                                                                   // 310
                // Pass chunk to callback                                                                             // 311
                callback.call(self, null, chunk);                                                                     // 312
            } catch (err) {                                                                                           // 314
                console.error('read error', err);                                                                     // 315
                // Retry to read chunk                                                                                // 316
                Meteor.setTimeout(function () {                                                                       // 317
                    if (tries < self.maxTries) {                                                                      // 318
                        tries += 1;                                                                                   // 319
                        self.readChunk(start, length, callback);                                                      // 320
                    }                                                                                                 // 321
                }, self.retryDelay);                                                                                  // 322
            }                                                                                                         // 323
        };                                                                                                            // 324
                                                                                                                      //
        /**                                                                                                           // 326
         * Sends a file chunk to the store                                                                            //
         */                                                                                                           //
        self.sendChunk = function () {                                                                                // 329
            if (!complete && startTime !== null) {                                                                    // 330
                if (offset < total) {                                                                                 // 331
                    (function () {                                                                                    // 331
                        var chunkSize = self.chunkSize;                                                               // 332
                                                                                                                      //
                        // Use adaptive length                                                                        // 334
                        if (self.adaptive && timeA && timeB && timeB > timeA) {                                       // 335
                            var duration = (timeB - timeA) / 1000;                                                    // 336
                            var max = self.capacity * (1 + capacityMargin);                                           // 337
                            var min = self.capacity * (1 - capacityMargin);                                           // 338
                                                                                                                      //
                            if (duration >= max) {                                                                    // 340
                                chunkSize = Math.abs(Math.round(chunkSize * (max - duration)));                       // 341
                            } else if (duration < min) {                                                              // 343
                                chunkSize = Math.round(chunkSize * (min / duration));                                 // 344
                            }                                                                                         // 345
                            // Limit to max chunk size                                                                // 346
                            if (self.maxChunkSize > 0 && chunkSize > self.maxChunkSize) {                             // 347
                                chunkSize = self.maxChunkSize;                                                        // 348
                            }                                                                                         // 349
                        }                                                                                             // 350
                                                                                                                      //
                        // Limit to max chunk size                                                                    // 352
                        if (self.maxChunkSize > 0 && chunkSize > self.maxChunkSize) {                                 // 353
                            chunkSize = self.maxChunkSize;                                                            // 354
                        }                                                                                             // 355
                                                                                                                      //
                        // Reduce chunk size to fit total                                                             // 357
                        if (offset + chunkSize > total) {                                                             // 358
                            chunkSize = total - offset;                                                               // 359
                        }                                                                                             // 360
                                                                                                                      //
                        // Prepare the chunk                                                                          // 362
                        self.readChunk(offset, chunkSize, function (err, chunk) {                                     // 363
                            if (err) {                                                                                // 364
                                self.onError(err, file);                                                              // 365
                                return;                                                                               // 366
                            }                                                                                         // 367
                                                                                                                      //
                            var xhr = new XMLHttpRequest();                                                           // 369
                            xhr.onreadystatechange = function () {                                                    // 370
                                if (xhr.readyState === 4) {                                                           // 371
                                    if (_.contains([200, 201, 202, 204], xhr.status)) {                               // 372
                                        timeB = Date.now();                                                           // 373
                                        offset += chunkSize;                                                          // 374
                                        loaded += chunkSize;                                                          // 375
                                                                                                                      //
                                        // Send next chunk                                                            // 377
                                        self.onProgress(file, self.getProgress());                                    // 378
                                                                                                                      //
                                        // Finish upload                                                              // 380
                                        if (loaded >= total) {                                                        // 381
                                            elapsedTime = Date.now() - startTime;                                     // 382
                                            finish();                                                                 // 383
                                        } else {                                                                      // 384
                                            Meteor.setTimeout(self.sendChunk, self.transferDelay);                    // 385
                                        }                                                                             // 386
                                    } else if (!_.contains([402, 403, 404, 500], xhr.status)) {                       // 387
                                        // Retry until max tries is reach                                             // 389
                                        // But don't retry if these errors occur                                      // 390
                                        if (tries <= self.maxTries) {                                                 // 391
                                            tries += 1;                                                               // 392
                                            // Wait before retrying                                                   // 393
                                            Meteor.setTimeout(self.sendChunk, self.retryDelay);                       // 394
                                        } else {                                                                      // 395
                                            self.abort();                                                             // 396
                                        }                                                                             // 397
                                    } else {                                                                          // 398
                                        self.abort();                                                                 // 400
                                    }                                                                                 // 401
                                }                                                                                     // 402
                            };                                                                                        // 403
                                                                                                                      //
                            // Calculate upload progress                                                              // 405
                            var progress = (offset + chunkSize) / total;                                              // 406
                            // let formData = new FormData();                                                         // 407
                            // formData.append('progress', progress);                                                 // 408
                            // formData.append('chunk', chunk);                                                       // 409
                            var url = postUrl + '&progress=' + progress;                                              // 410
                                                                                                                      //
                            timeA = Date.now();                                                                       // 412
                            timeB = null;                                                                             // 413
                            uploading = true;                                                                         // 414
                                                                                                                      //
                            // Send chunk to the store                                                                // 416
                            xhr.open('POST', url, true);                                                              // 417
                            xhr.send(chunk);                                                                          // 418
                        });                                                                                           // 419
                    })();                                                                                             // 331
                }                                                                                                     // 420
            }                                                                                                         // 421
        };                                                                                                            // 422
                                                                                                                      //
        /**                                                                                                           // 424
         * Starts or resumes the transfer                                                                             //
         */                                                                                                           //
        self.start = function () {                                                                                    // 427
            if (!fileId) {                                                                                            // 428
                // Create the file document and get the token                                                         // 429
                // that allows the user to send chunks to the store.                                                  // 430
                Meteor.call('ufsCreate', _.extend({}, file), function (err, result) {                                 // 431
                    if (err) {                                                                                        // 432
                        self.onError(err, file);                                                                      // 433
                    } else if (result) {                                                                              // 434
                        token = result.token;                                                                         // 435
                        postUrl = result.url;                                                                         // 436
                        fileId = result.fileId;                                                                       // 437
                        file._id = result.fileId;                                                                     // 438
                        self.onCreate(file);                                                                          // 439
                        tries = 0;                                                                                    // 440
                        startTime = Date.now();                                                                       // 441
                        self.onStart(file);                                                                           // 442
                        self.sendChunk();                                                                             // 443
                    }                                                                                                 // 444
                });                                                                                                   // 445
            } else if (!uploading && !complete) {                                                                     // 446
                // Resume uploading                                                                                   // 447
                tries = 0;                                                                                            // 448
                startTime = Date.now();                                                                               // 449
                self.onStart(file);                                                                                   // 450
                self.sendChunk();                                                                                     // 451
            }                                                                                                         // 452
        };                                                                                                            // 453
                                                                                                                      //
        /**                                                                                                           // 455
         * Stops the transfer                                                                                         //
         */                                                                                                           //
        self.stop = function () {                                                                                     // 458
            if (uploading) {                                                                                          // 459
                // Update elapsed time                                                                                // 460
                elapsedTime = Date.now() - startTime;                                                                 // 461
                startTime = null;                                                                                     // 462
                uploading = false;                                                                                    // 463
                self.onStop(file);                                                                                    // 464
                                                                                                                      //
                Meteor.call('ufsStop', fileId, store, token, function (err, result) {                                 // 466
                    if (err) {                                                                                        // 467
                        self.onError(err, file);                                                                      // 468
                    }                                                                                                 // 469
                });                                                                                                   // 470
            }                                                                                                         // 471
        };                                                                                                            // 472
    }                                                                                                                 // 473
                                                                                                                      //
    /**                                                                                                               // 475
     * Called when the file upload is aborted                                                                         //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Uploader.prototype.onAbort = function () {                                                                        // 34
        function onAbort(file) {}                                                                                     // 34
                                                                                                                      //
        return onAbort;                                                                                               // 34
    }();                                                                                                              // 34
                                                                                                                      //
    /**                                                                                                               // 482
     * Called when the file upload is complete                                                                        //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Uploader.prototype.onComplete = function () {                                                                     // 34
        function onComplete(file) {}                                                                                  // 34
                                                                                                                      //
        return onComplete;                                                                                            // 34
    }();                                                                                                              // 34
                                                                                                                      //
    /**                                                                                                               // 489
     * Called when the file is created in the collection                                                              //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Uploader.prototype.onCreate = function () {                                                                       // 34
        function onCreate(file) {}                                                                                    // 34
                                                                                                                      //
        return onCreate;                                                                                              // 34
    }();                                                                                                              // 34
                                                                                                                      //
    /**                                                                                                               // 496
     * Called when an error occurs during file upload                                                                 //
     * @param err                                                                                                     //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Uploader.prototype.onError = function () {                                                                        // 34
        function onError(err, file) {                                                                                 // 34
            console.error('ufs: ' + err.message);                                                                     // 502
        }                                                                                                             // 503
                                                                                                                      //
        return onError;                                                                                               // 34
    }();                                                                                                              // 34
                                                                                                                      //
    /**                                                                                                               // 505
     * Called when a file chunk has been sent                                                                         //
     * @param file                                                                                                    //
     * @param progress is a float from 0.0 to 1.0                                                                     //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Uploader.prototype.onProgress = function () {                                                                     // 34
        function onProgress(file, progress) {}                                                                        // 34
                                                                                                                      //
        return onProgress;                                                                                            // 34
    }();                                                                                                              // 34
                                                                                                                      //
    /**                                                                                                               // 513
     * Called when the file upload starts                                                                             //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Uploader.prototype.onStart = function () {                                                                        // 34
        function onStart(file) {}                                                                                     // 34
                                                                                                                      //
        return onStart;                                                                                               // 34
    }();                                                                                                              // 34
                                                                                                                      //
    /**                                                                                                               // 520
     * Called when the file upload stops                                                                              //
     * @param file                                                                                                    //
     */                                                                                                               //
                                                                                                                      //
                                                                                                                      //
    Uploader.prototype.onStop = function () {                                                                         // 34
        function onStop(file) {}                                                                                      // 34
                                                                                                                      //
        return onStop;                                                                                                // 34
    }();                                                                                                              // 34
                                                                                                                      //
    return Uploader;                                                                                                  // 34
}();                                                                                                                  // 34
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/jalik:ufs/ufs.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jalik:ufs'] = exports;

})();

//# sourceMappingURL=jalik_ufs.js.map
