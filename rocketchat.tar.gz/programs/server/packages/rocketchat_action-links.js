(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var RocketChatTabBar = Package['rocketchat:lib'].RocketChatTabBar;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:action-links":{"both":{"lib":{"actionLinks.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/rocketchat_action-links/both/lib/actionLinks.js                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
//Action Links namespace creation.                                                                                // 1
RocketChat.actionLinks = {                                                                                        // 2
	actions: {},                                                                                                     // 3
	register: function () {                                                                                          // 4
		function register(name, funct) {                                                                                // 4
			RocketChat.actionLinks.actions[name] = funct;                                                                  // 5
		}                                                                                                               // 6
                                                                                                                  //
		return register;                                                                                                // 4
	}(),                                                                                                             // 4
	getMessage: function () {                                                                                        // 7
		function getMessage(name, messageId) {                                                                          // 7
			if (!Meteor.userId()) {                                                                                        // 8
				throw new Meteor.Error('error-invalid-user', 'Invalid user', { 'function': 'actionLinks.getMessage' });       // 9
			}                                                                                                              // 10
                                                                                                                  //
			var message = RocketChat.models.Messages.findOne({ _id: messageId });                                          // 12
			if (!message) {                                                                                                // 13
				throw new Meteor.Error('error-invalid-message', 'Invalid message', { 'function': 'actionLinks.getMessage' });
			}                                                                                                              // 15
                                                                                                                  //
			var room = RocketChat.models.Rooms.findOne({ _id: message.rid });                                              // 17
			if (Array.isArray(room.usernames) && room.usernames.indexOf(Meteor.user().username) === -1) {                  // 18
				throw new Meteor.Error('error-not-allowed', 'Not allowed', { 'function': 'actionLinks.getMessage' });         // 19
			}                                                                                                              // 20
                                                                                                                  //
			if (!message.actionLinks || !message.actionLinks[name]) {                                                      // 22
				throw new Meteor.Error('error-invalid-actionlink', 'Invalid action link', { 'function': 'actionLinks.getMessage' });
			}                                                                                                              // 24
                                                                                                                  //
			return message;                                                                                                // 26
		}                                                                                                               // 27
                                                                                                                  //
		return getMessage;                                                                                              // 7
	}()                                                                                                              // 7
};                                                                                                                // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"actionLinkHandler.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/rocketchat_action-links/server/actionLinkHandler.js                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
//Action Links Handler. This method will be called off the client.                                                // 1
                                                                                                                  //
Meteor.methods({                                                                                                  // 3
	actionLinkHandler: function () {                                                                                 // 4
		function actionLinkHandler(name, messageId) {                                                                   // 3
			if (!Meteor.userId()) {                                                                                        // 5
				throw new Meteor.Error('error-invalid-user', 'Invalid user', { method: 'actionLinkHandler' });                // 6
			}                                                                                                              // 7
                                                                                                                  //
			var message = RocketChat.actionLinks.getMessage(name, messageId);                                              // 9
                                                                                                                  //
			var actionLink = message.actionLinks[name];                                                                    // 11
                                                                                                                  //
			RocketChat.actionLinks.actions[actionLink.method_id](message, actionLink.params);                              // 13
		}                                                                                                               // 14
                                                                                                                  //
		return actionLinkHandler;                                                                                       // 3
	}()                                                                                                              // 3
});                                                                                                               // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/rocketchat:action-links/both/lib/actionLinks.js");
require("./node_modules/meteor/rocketchat:action-links/server/actionLinkHandler.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:action-links'] = {};

})();

//# sourceMappingURL=rocketchat_action-links.js.map
