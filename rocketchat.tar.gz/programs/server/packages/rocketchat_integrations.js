(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var ECMAScript = Package.ecmascript.ECMAScript;
var Babel = Package['babel-compiler'].Babel;
var BabelCompiler = Package['babel-compiler'].BabelCompiler;
var hljs = Package['simple:highlight.js'].hljs;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var RocketChatTabBar = Package['rocketchat:lib'].RocketChatTabBar;
var Logger = Package['rocketchat:logger'].Logger;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var __coffeescriptShare, logger;

var require = meteorInstall({"node_modules":{"meteor":{"rocketchat:integrations":{"lib":{"rocketchat.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/lib/rocketchat.coffee.js                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.integrations = {};                                                                                        // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"logger.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/logger.js                                                                 //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
/* globals logger:true */                                                                                            // 1
/* exported logger */                                                                                                // 2
                                                                                                                     //
logger = new Logger('Integrations', {                                                                                // 4
	sections: {                                                                                                         // 5
		incoming: 'Incoming WebHook',                                                                                      // 6
		outgoing: 'Outgoing WebHook'                                                                                       // 7
	}                                                                                                                   // 5
});                                                                                                                  // 4
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"validation.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/lib/validation.coffee.js                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };
                                                                                                                     //
RocketChat.integrations.validateOutgoing = function(integration, userId) {                                           // 1
  var babelOptions, channel, channelType, channels, e, i, index, j, k, l, len, len1, len2, len3, record, ref, ref1, ref2, ref3, ref4, ref5, scopedChannels, triggerWord, url, user;
  if ((((ref = integration.channel) != null ? ref.trim : void 0) != null) && integration.channel.trim() === '') {    //
    delete integration.channel;                                                                                      //
  }                                                                                                                  //
  if (integration.username.trim() === '') {                                                                          //
    throw new Meteor.Error('error-invalid-username', 'Invalid username', {                                           // 6
      method: 'addOutgoingIntegration'                                                                               //
    });                                                                                                              //
  }                                                                                                                  //
  if (!Match.test(integration.urls, [String])) {                                                                     //
    throw new Meteor.Error('error-invalid-urls', 'Invalid URLs', {                                                   // 9
      method: 'addOutgoingIntegration'                                                                               //
    });                                                                                                              //
  }                                                                                                                  //
  ref1 = integration.urls;                                                                                           // 11
  for (index = i = 0, len = ref1.length; i < len; index = ++i) {                                                     // 11
    url = ref1[index];                                                                                               //
    if (url.trim() === '') {                                                                                         //
      delete integration.urls[index];                                                                                //
    }                                                                                                                //
  }                                                                                                                  // 11
  integration.urls = _.without(integration.urls, [void 0]);                                                          //
  if (integration.urls.length === 0) {                                                                               //
    throw new Meteor.Error('error-invalid-urls', 'Invalid URLs', {                                                   // 17
      method: 'addOutgoingIntegration'                                                                               //
    });                                                                                                              //
  }                                                                                                                  //
  if (!Match.test(integration.channel, String)) {                                                                    //
    throw new Meteor.Error('error-invalid-channel', 'Invalid Channel', {                                             // 20
      method: 'addOutgoingIntegration'                                                                               //
    });                                                                                                              //
  }                                                                                                                  //
  channels = _.map(integration.channel.split(','), function(channel) {                                               //
    return s.trim(channel);                                                                                          //
  });                                                                                                                //
  scopedChannels = ['all_public_channels', 'all_private_groups', 'all_direct_messages'];                             //
  for (j = 0, len1 = channels.length; j < len1; j++) {                                                               // 25
    channel = channels[j];                                                                                           //
    if (((ref2 = channel[0]) !== '@' && ref2 !== '#') && indexOf.call(scopedChannels, channel) < 0) {                //
      throw new Meteor.Error('error-invalid-channel-start-with-chars', 'Invalid channel. Start with @ or #', {       // 27
        method: 'updateIncomingIntegration'                                                                          //
      });                                                                                                            //
    }                                                                                                                //
  }                                                                                                                  // 25
  if (integration.triggerWords != null) {                                                                            //
    if (!Match.test(integration.triggerWords, [String])) {                                                           //
      throw new Meteor.Error('error-invalid-triggerWords', 'Invalid triggerWords', {                                 // 31
        method: 'addOutgoingIntegration'                                                                             //
      });                                                                                                            //
    }                                                                                                                //
    ref3 = integration.triggerWords;                                                                                 // 33
    for (index = k = 0, len2 = ref3.length; k < len2; index = ++k) {                                                 // 33
      triggerWord = ref3[index];                                                                                     //
      if (triggerWord.trim() === '') {                                                                               //
        delete integration.triggerWords[index];                                                                      //
      }                                                                                                              //
    }                                                                                                                // 33
    integration.triggerWords = _.without(integration.triggerWords, [void 0]);                                        //
  }                                                                                                                  //
  if (integration.scriptEnabled === true && (integration.script != null) && integration.script.trim() !== '') {      //
    try {                                                                                                            // 39
      babelOptions = Babel.getDefaultOptions({                                                                       //
        runtime: false                                                                                               //
      });                                                                                                            //
      babelOptions = _.extend(babelOptions, {                                                                        //
        compact: true,                                                                                               //
        minified: true,                                                                                              //
        comments: false                                                                                              //
      });                                                                                                            //
      integration.scriptCompiled = Babel.compile(integration.script, babelOptions).code;                             //
      integration.scriptError = void 0;                                                                              //
    } catch (error) {                                                                                                //
      e = error;                                                                                                     //
      integration.scriptCompiled = void 0;                                                                           //
      integration.scriptError = _.pick(e, 'name', 'message', 'stack');                                               //
    }                                                                                                                //
  }                                                                                                                  //
  for (l = 0, len3 = channels.length; l < len3; l++) {                                                               // 50
    channel = channels[l];                                                                                           //
    if (indexOf.call(scopedChannels, channel) >= 0) {                                                                //
      if (channel === 'all_public_channels') {                                                                       //
                                                                                                                     // 52
      } else if (!RocketChat.authz.hasPermission(userId, 'manage-integrations')) {                                   //
        throw new Meteor.Error('error-invalid-channel', 'Invalid Channel', {                                         // 55
          method: 'addOutgoingIntegration'                                                                           //
        });                                                                                                          //
      }                                                                                                              //
    } else {                                                                                                         //
      record = void 0;                                                                                               //
      channelType = channel[0];                                                                                      //
      channel = channel.substr(1);                                                                                   //
      switch (channelType) {                                                                                         // 61
        case '#':                                                                                                    // 61
          record = RocketChat.models.Rooms.findOne({                                                                 //
            $or: [                                                                                                   //
              {                                                                                                      //
                _id: channel                                                                                         //
              }, {                                                                                                   //
                name: channel                                                                                        //
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
          break;                                                                                                     // 62
        case '@':                                                                                                    // 61
          record = RocketChat.models.Users.findOne({                                                                 //
            $or: [                                                                                                   //
              {                                                                                                      //
                _id: channel                                                                                         //
              }, {                                                                                                   //
                username: channel                                                                                    //
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
      }                                                                                                              // 61
      if (record === void 0) {                                                                                       //
        throw new Meteor.Error('error-invalid-room', 'Invalid room', {                                               // 76
          method: 'addOutgoingIntegration'                                                                           //
        });                                                                                                          //
      }                                                                                                              //
      if ((record.usernames != null) && (!RocketChat.authz.hasPermission(userId, 'manage-integrations')) && (RocketChat.authz.hasPermission(userId, 'manage-own-integrations')) && (ref4 = (ref5 = Meteor.user()) != null ? ref5.username : void 0, indexOf.call(record.usernames, ref4) < 0)) {
        throw new Meteor.Error('error-invalid-channel', 'Invalid Channel', {                                         // 82
          method: 'addOutgoingIntegration'                                                                           //
        });                                                                                                          //
      }                                                                                                              //
    }                                                                                                                //
  }                                                                                                                  // 50
  user = RocketChat.models.Users.findOne({                                                                           //
    username: integration.username                                                                                   //
  });                                                                                                                //
  if (user == null) {                                                                                                //
    throw new Meteor.Error('error-invalid-user', 'Invalid user', {                                                   // 87
      method: 'addOutgoingIntegration'                                                                               //
    });                                                                                                              //
  }                                                                                                                  //
  integration.type = 'webhook-outgoing';                                                                             //
  integration.userId = user._id;                                                                                     //
  integration.channel = channels;                                                                                    //
  return integration;                                                                                                // 93
};                                                                                                                   // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"models":{"Integrations.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/models/Integrations.coffee.js                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                       //
                                                                                                                     //
RocketChat.models.Integrations = new ((function(superClass) {                                                        // 1
  extend(_Class, superClass);                                                                                        //
                                                                                                                     //
  function _Class() {                                                                                                //
    _Class.__super__.constructor.call(this, 'integrations');                                                         //
  }                                                                                                                  //
                                                                                                                     //
  return _Class;                                                                                                     //
                                                                                                                     //
})(RocketChat.models._Base));                                                                                        //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"integrations.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/publications/integrations.coffee.js                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('integrations', function() {                                                                          // 1
  if (!this.userId) {                                                                                                //
    return this.ready();                                                                                             // 3
  }                                                                                                                  //
  if (RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                          //
    return RocketChat.models.Integrations.find();                                                                    // 6
  } else if (RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations')) {                               //
    return RocketChat.models.Integrations.find({                                                                     // 8
      "_createdBy._id": this.userId                                                                                  //
    });                                                                                                              //
  } else {                                                                                                           //
    throw new Meteor.Error("not-authorized");                                                                        // 10
  }                                                                                                                  //
});                                                                                                                  // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"incoming":{"addIncomingIntegration.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/incoming/addIncomingIntegration.coffee.js                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };
                                                                                                                     //
Meteor.methods({                                                                                                     // 1
  addIncomingIntegration: function(integration) {                                                                    //
    var babelOptions, channel, channelType, channels, e, i, j, len, len1, record, ref, ref1, ref2, token, user;      // 3
    if ((!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) && (!RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations'))) {
      throw new Meteor.Error('not_authorized');                                                                      // 4
    }                                                                                                                //
    if (!_.isString(integration.channel)) {                                                                          //
      throw new Meteor.Error('error-invalid-channel', 'Invalid channel', {                                           // 7
        method: 'addIncomingIntegration'                                                                             //
      });                                                                                                            //
    }                                                                                                                //
    if (integration.channel.trim() === '') {                                                                         //
      throw new Meteor.Error('error-invalid-channel', 'Invalid channel', {                                           // 10
        method: 'addIncomingIntegration'                                                                             //
      });                                                                                                            //
    }                                                                                                                //
    channels = _.map(integration.channel.split(','), function(channel) {                                             //
      return s.trim(channel);                                                                                        //
    });                                                                                                              //
    for (i = 0, len = channels.length; i < len; i++) {                                                               // 14
      channel = channels[i];                                                                                         //
      if ((ref = channel[0]) !== '@' && ref !== '#') {                                                               //
        throw new Meteor.Error('error-invalid-channel-start-with-chars', 'Invalid channel. Start with @ or #', {     // 16
          method: 'updateIncomingIntegration'                                                                        //
        });                                                                                                          //
      }                                                                                                              //
    }                                                                                                                // 14
    if (!_.isString(integration.username)) {                                                                         //
      throw new Meteor.Error('error-invalid-username', 'Invalid username', {                                         // 19
        method: 'addIncomingIntegration'                                                                             //
      });                                                                                                            //
    }                                                                                                                //
    if (integration.username.trim() === '') {                                                                        //
      throw new Meteor.Error('error-invalid-username', 'Invalid username', {                                         // 22
        method: 'addIncomingIntegration'                                                                             //
      });                                                                                                            //
    }                                                                                                                //
    if (integration.scriptEnabled === true && (integration.script != null) && integration.script.trim() !== '') {    //
      try {                                                                                                          // 25
        babelOptions = Babel.getDefaultOptions({                                                                     //
          runtime: false                                                                                             //
        });                                                                                                          //
        babelOptions = _.extend(babelOptions, {                                                                      //
          compact: true,                                                                                             //
          minified: true,                                                                                            //
          comments: false                                                                                            //
        });                                                                                                          //
        integration.scriptCompiled = Babel.compile(integration.script, babelOptions).code;                           //
        integration.scriptError = void 0;                                                                            //
      } catch (error) {                                                                                              //
        e = error;                                                                                                   //
        integration.scriptCompiled = void 0;                                                                         //
        integration.scriptError = _.pick(e, 'name', 'message', 'stack');                                             //
      }                                                                                                              //
    }                                                                                                                //
    for (j = 0, len1 = channels.length; j < len1; j++) {                                                             // 35
      channel = channels[j];                                                                                         //
      record = void 0;                                                                                               //
      channelType = channel[0];                                                                                      //
      channel = channel.substr(1);                                                                                   //
      switch (channelType) {                                                                                         // 40
        case '#':                                                                                                    // 40
          record = RocketChat.models.Rooms.findOne({                                                                 //
            $or: [                                                                                                   //
              {                                                                                                      //
                _id: channel                                                                                         //
              }, {                                                                                                   //
                name: channel                                                                                        //
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
          break;                                                                                                     // 41
        case '@':                                                                                                    // 40
          record = RocketChat.models.Users.findOne({                                                                 //
            $or: [                                                                                                   //
              {                                                                                                      //
                _id: channel                                                                                         //
              }, {                                                                                                   //
                username: channel                                                                                    //
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
      }                                                                                                              // 40
      if (record === void 0) {                                                                                       //
        throw new Meteor.Error('error-invalid-room', 'Invalid room', {                                               // 55
          method: 'addIncomingIntegration'                                                                           //
        });                                                                                                          //
      }                                                                                                              //
      if ((record.usernames != null) && (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) && (RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations')) && (ref1 = (ref2 = Meteor.user()) != null ? ref2.username : void 0, indexOf.call(record.usernames, ref1) < 0)) {
        throw new Meteor.Error('error-invalid-channel', 'Invalid Channel', {                                         // 61
          method: 'addIncomingIntegration'                                                                           //
        });                                                                                                          //
      }                                                                                                              //
    }                                                                                                                // 35
    user = RocketChat.models.Users.findOne({                                                                         //
      username: integration.username                                                                                 //
    });                                                                                                              //
    if (user == null) {                                                                                              //
      throw new Meteor.Error('error-invalid-user', 'Invalid user', {                                                 // 66
        method: 'addIncomingIntegration'                                                                             //
      });                                                                                                            //
    }                                                                                                                //
    token = Random.id(48);                                                                                           //
    integration.type = 'webhook-incoming';                                                                           //
    integration.token = token;                                                                                       //
    integration.channel = channels;                                                                                  //
    integration.userId = user._id;                                                                                   //
    integration._createdAt = new Date;                                                                               //
    integration._createdBy = RocketChat.models.Users.findOne(this.userId, {                                          //
      fields: {                                                                                                      //
        username: 1                                                                                                  //
      }                                                                                                              //
    });                                                                                                              //
    RocketChat.models.Roles.addUserRoles(user._id, 'bot');                                                           //
    integration._id = RocketChat.models.Integrations.insert(integration);                                            //
    return integration;                                                                                              // 81
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"updateIncomingIntegration.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/incoming/updateIncomingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };
                                                                                                                     //
Meteor.methods({                                                                                                     // 1
  updateIncomingIntegration: function(integrationId, integration) {                                                  //
    var babelOptions, channel, channelType, channels, currentIntegration, e, i, j, len, len1, record, ref, ref1, ref2, user;
    if (!_.isString(integration.channel)) {                                                                          //
      throw new Meteor.Error('error-invalid-channel', 'Invalid channel', {                                           // 4
        method: 'updateIncomingIntegration'                                                                          //
      });                                                                                                            //
    }                                                                                                                //
    if (integration.channel.trim() === '') {                                                                         //
      throw new Meteor.Error('error-invalid-channel', 'Invalid channel', {                                           // 7
        method: 'updateIncomingIntegration'                                                                          //
      });                                                                                                            //
    }                                                                                                                //
    channels = _.map(integration.channel.split(','), function(channel) {                                             //
      return s.trim(channel);                                                                                        //
    });                                                                                                              //
    for (i = 0, len = channels.length; i < len; i++) {                                                               // 11
      channel = channels[i];                                                                                         //
      if ((ref = channel[0]) !== '@' && ref !== '#') {                                                               //
        throw new Meteor.Error('error-invalid-channel-start-with-chars', 'Invalid channel. Start with @ or #', {     // 13
          method: 'updateIncomingIntegration'                                                                        //
        });                                                                                                          //
      }                                                                                                              //
    }                                                                                                                // 11
    currentIntegration = null;                                                                                       //
    if (RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                        //
      currentIntegration = RocketChat.models.Integrations.findOne(integrationId);                                    //
    } else if (RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations')) {                             //
      currentIntegration = RocketChat.models.Integrations.findOne({                                                  //
        "_id": integrationId,                                                                                        //
        "_createdBy._id": this.userId                                                                                //
      });                                                                                                            //
    } else {                                                                                                         //
      throw new Meteor.Error('not_authorized');                                                                      // 22
    }                                                                                                                //
    if (currentIntegration == null) {                                                                                //
      throw new Meteor.Error('error-invalid-integration', 'Invalid integration', {                                   // 25
        method: 'updateIncomingIntegration'                                                                          //
      });                                                                                                            //
    }                                                                                                                //
    if (integration.scriptEnabled === true && (integration.script != null) && integration.script.trim() !== '') {    //
      try {                                                                                                          // 28
        babelOptions = Babel.getDefaultOptions({                                                                     //
          runtime: false                                                                                             //
        });                                                                                                          //
        babelOptions = _.extend(babelOptions, {                                                                      //
          compact: true,                                                                                             //
          minified: true,                                                                                            //
          comments: false                                                                                            //
        });                                                                                                          //
        integration.scriptCompiled = Babel.compile(integration.script, babelOptions).code;                           //
        integration.scriptError = void 0;                                                                            //
      } catch (error) {                                                                                              //
        e = error;                                                                                                   //
        integration.scriptCompiled = void 0;                                                                         //
        integration.scriptError = _.pick(e, 'name', 'message', 'stack');                                             //
      }                                                                                                              //
    }                                                                                                                //
    for (j = 0, len1 = channels.length; j < len1; j++) {                                                             // 38
      channel = channels[j];                                                                                         //
      record = void 0;                                                                                               //
      channelType = channel[0];                                                                                      //
      channel = channel.substr(1);                                                                                   //
      switch (channelType) {                                                                                         // 43
        case '#':                                                                                                    // 43
          record = RocketChat.models.Rooms.findOne({                                                                 //
            $or: [                                                                                                   //
              {                                                                                                      //
                _id: channel                                                                                         //
              }, {                                                                                                   //
                name: channel                                                                                        //
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
          break;                                                                                                     // 44
        case '@':                                                                                                    // 43
          record = RocketChat.models.Users.findOne({                                                                 //
            $or: [                                                                                                   //
              {                                                                                                      //
                _id: channel                                                                                         //
              }, {                                                                                                   //
                username: channel                                                                                    //
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
      }                                                                                                              // 43
      if (record === void 0) {                                                                                       //
        throw new Meteor.Error('error-invalid-room', 'Invalid room', {                                               // 58
          method: 'updateIncomingIntegration'                                                                        //
        });                                                                                                          //
      }                                                                                                              //
      if ((record.usernames != null) && (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) && (RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations')) && (ref1 = (ref2 = Meteor.user()) != null ? ref2.username : void 0, indexOf.call(record.usernames, ref1) < 0)) {
        throw new Meteor.Error('error-invalid-channel', 'Invalid Channel', {                                         // 64
          method: 'updateIncomingIntegration'                                                                        //
        });                                                                                                          //
      }                                                                                                              //
    }                                                                                                                // 38
    user = RocketChat.models.Users.findOne({                                                                         //
      username: currentIntegration.username                                                                          //
    });                                                                                                              //
    RocketChat.models.Roles.addUserRoles(user._id, 'bot');                                                           //
    RocketChat.models.Integrations.update(integrationId, {                                                           //
      $set: {                                                                                                        //
        enabled: integration.enabled,                                                                                //
        name: integration.name,                                                                                      //
        avatar: integration.avatar,                                                                                  //
        emoji: integration.emoji,                                                                                    //
        alias: integration.alias,                                                                                    //
        channel: channels,                                                                                           //
        script: integration.script,                                                                                  //
        scriptEnabled: integration.scriptEnabled,                                                                    //
        scriptCompiled: integration.scriptCompiled,                                                                  //
        scriptError: integration.scriptError,                                                                        //
        _updatedAt: new Date,                                                                                        //
        _updatedBy: RocketChat.models.Users.findOne(this.userId, {                                                   //
          fields: {                                                                                                  //
            username: 1                                                                                              //
          }                                                                                                          //
        })                                                                                                           //
      }                                                                                                              //
    });                                                                                                              //
    return RocketChat.models.Integrations.findOne(integrationId);                                                    // 84
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"deleteIncomingIntegration.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/incoming/deleteIncomingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  deleteIncomingIntegration: function(integrationId) {                                                               //
    var integration;                                                                                                 // 3
    integration = null;                                                                                              //
    if (RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                        //
      integration = RocketChat.models.Integrations.findOne(integrationId);                                           //
    } else if (RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations')) {                             //
      integration = RocketChat.models.Integrations.findOne(integrationId, {                                          //
        fields: {                                                                                                    //
          "_createdBy._id": this.userId                                                                              //
        }                                                                                                            //
      });                                                                                                            //
    } else {                                                                                                         //
      throw new Meteor.Error('not_authorized');                                                                      // 10
    }                                                                                                                //
    if (integration == null) {                                                                                       //
      throw new Meteor.Error('error-invalid-integration', 'Invalid integration', {                                   // 13
        method: 'deleteIncomingIntegration'                                                                          //
      });                                                                                                            //
    }                                                                                                                //
    RocketChat.models.Integrations.remove({                                                                          //
      _id: integrationId                                                                                             //
    });                                                                                                              //
    return true;                                                                                                     // 17
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"outgoing":{"addOutgoingIntegration.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/outgoing/addOutgoingIntegration.coffee.js                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  addOutgoingIntegration: function(integration) {                                                                    //
    if ((!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) && !(RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations')) && !(RocketChat.authz.hasPermission(this.userId, 'manage-integrations', 'bot')) && !(RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations', 'bot'))) {
      throw new Meteor.Error('not_authorized');                                                                      // 8
    }                                                                                                                //
    integration = RocketChat.integrations.validateOutgoing(integration, this.userId);                                //
    integration._createdAt = new Date;                                                                               //
    integration._createdBy = RocketChat.models.Users.findOne(this.userId, {                                          //
      fields: {                                                                                                      //
        username: 1                                                                                                  //
      }                                                                                                              //
    });                                                                                                              //
    integration._id = RocketChat.models.Integrations.insert(integration);                                            //
    return integration;                                                                                              // 17
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"updateOutgoingIntegration.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/outgoing/updateOutgoingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  updateOutgoingIntegration: function(integrationId, integration) {                                                  //
    var currentIntegration, ref;                                                                                     // 3
    integration = RocketChat.integrations.validateOutgoing(integration, this.userId);                                //
    if ((integration.token == null) || ((ref = integration.token) != null ? ref.trim() : void 0) === '') {           //
      throw new Meteor.Error('error-invalid-token', 'Invalid token', {                                               // 6
        method: 'updateOutgoingIntegration'                                                                          //
      });                                                                                                            //
    }                                                                                                                //
    currentIntegration = null;                                                                                       //
    if (RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                        //
      currentIntegration = RocketChat.models.Integrations.findOne(integrationId);                                    //
    } else if (RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations')) {                             //
      currentIntegration = RocketChat.models.Integrations.findOne({                                                  //
        "_id": integrationId,                                                                                        //
        "_createdBy._id": this.userId                                                                                //
      });                                                                                                            //
    } else {                                                                                                         //
      throw new Meteor.Error('not_authorized');                                                                      // 15
    }                                                                                                                //
    if (currentIntegration == null) {                                                                                //
      throw new Meteor.Error('invalid_integration', '[methods] updateOutgoingIntegration -> integration not found');
    }                                                                                                                //
    RocketChat.models.Integrations.update(integrationId, {                                                           //
      $set: {                                                                                                        //
        enabled: integration.enabled,                                                                                //
        name: integration.name,                                                                                      //
        avatar: integration.avatar,                                                                                  //
        emoji: integration.emoji,                                                                                    //
        alias: integration.alias,                                                                                    //
        channel: integration.channel,                                                                                //
        impersonateUser: integration.impersonateUser,                                                                //
        username: integration.username,                                                                              //
        userId: integration.userId,                                                                                  //
        urls: integration.urls,                                                                                      //
        token: integration.token,                                                                                    //
        script: integration.script,                                                                                  //
        scriptEnabled: integration.scriptEnabled,                                                                    //
        scriptCompiled: integration.scriptCompiled,                                                                  //
        scriptError: integration.scriptError,                                                                        //
        triggerWords: integration.triggerWords,                                                                      //
        _updatedAt: new Date,                                                                                        //
        _updatedBy: RocketChat.models.Users.findOne(this.userId, {                                                   //
          fields: {                                                                                                  //
            username: 1                                                                                              //
          }                                                                                                          //
        })                                                                                                           //
      }                                                                                                              //
    });                                                                                                              //
    return RocketChat.models.Integrations.findOne(integrationId);                                                    // 42
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"deleteOutgoingIntegration.coffee.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/outgoing/deleteOutgoingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  deleteOutgoingIntegration: function(integrationId) {                                                               //
    var integration;                                                                                                 // 3
    integration = null;                                                                                              //
    if (RocketChat.authz.hasPermission(this.userId, 'manage-integrations') || RocketChat.authz.hasPermission(this.userId, 'manage-integrations', 'bot')) {
      integration = RocketChat.models.Integrations.findOne(integrationId);                                           //
    } else if (RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations') || RocketChat.authz.hasPermission(this.userId, 'manage-own-integrations', 'bot')) {
      integration = RocketChat.models.Integrations.findOne(integrationId, {                                          //
        fields: {                                                                                                    //
          "_createdBy._id": this.userId                                                                              //
        }                                                                                                            //
      });                                                                                                            //
    } else {                                                                                                         //
      throw new Meteor.Error('not_authorized');                                                                      // 10
    }                                                                                                                //
    if (integration == null) {                                                                                       //
      throw new Meteor.Error('error-invalid-integration', 'Invalid integration', {                                   // 13
        method: 'deleteOutgoingIntegration'                                                                          //
      });                                                                                                            //
    }                                                                                                                //
    RocketChat.models.Integrations.remove({                                                                          //
      _id: integrationId                                                                                             //
    });                                                                                                              //
    return true;                                                                                                     // 17
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"api":{"api.coffee.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/api/api.coffee.js                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Api, addIntegrationRest, compiledScripts, createIntegration, executeIntegrationRest, getIntegrationScript, integrationInfoRest, integrationSampleRest, removeIntegration, removeIntegrationRest, vm;
                                                                                                                     //
vm = Npm.require('vm');                                                                                              // 1
                                                                                                                     //
compiledScripts = {};                                                                                                // 3
                                                                                                                     //
getIntegrationScript = function(integration) {                                                                       // 5
  var compiledScript, e, sandbox, script, vmScript;                                                                  // 6
  compiledScript = compiledScripts[integration._id];                                                                 //
  if ((compiledScript != null) && +compiledScript._updatedAt === +integration._updatedAt) {                          //
    return compiledScript.script;                                                                                    // 8
  }                                                                                                                  //
  script = integration.scriptCompiled;                                                                               //
  vmScript = void 0;                                                                                                 //
  sandbox = {                                                                                                        //
    _: _,                                                                                                            //
    s: s,                                                                                                            //
    console: console,                                                                                                //
    Store: {                                                                                                         //
      set: function(key, val) {                                                                                      //
        return store[key] = val;                                                                                     // 18
      },                                                                                                             //
      get: function(key) {                                                                                           //
        return store[key];                                                                                           // 20
      }                                                                                                              //
    },                                                                                                               //
    HTTP: function(method, url, options) {                                                                           //
      var e;                                                                                                         // 22
      try {                                                                                                          // 22
        return {                                                                                                     // 23
          result: HTTP.call(method, url, options)                                                                    //
        };                                                                                                           //
      } catch (error) {                                                                                              //
        e = error;                                                                                                   //
        return {                                                                                                     // 26
          error: e                                                                                                   //
        };                                                                                                           //
      }                                                                                                              //
    }                                                                                                                //
  };                                                                                                                 //
  try {                                                                                                              // 29
    logger.incoming.info('Will evaluate script of Trigger', integration.name);                                       //
    logger.incoming.debug(script);                                                                                   //
    vmScript = vm.createScript(script, 'script.js');                                                                 //
    vmScript.runInNewContext(sandbox);                                                                               //
    if (sandbox.Script != null) {                                                                                    //
      compiledScripts[integration._id] = {                                                                           //
        script: new sandbox.Script(),                                                                                //
        _updatedAt: integration._updatedAt                                                                           //
      };                                                                                                             //
      return compiledScripts[integration._id].script;                                                                // 42
    }                                                                                                                //
  } catch (error) {                                                                                                  //
    e = error;                                                                                                       //
    logger.incoming.error('[Error evaluating Script in Trigger', integration.name, ':]');                            //
    logger.incoming.error(script.replace(/^/gm, '  '));                                                              //
    logger.incoming.error("[Stack:]");                                                                               //
    logger.incoming.error(e.stack.replace(/^/gm, '  '));                                                             //
    throw RocketChat.API.v1.failure('error-evaluating-script');                                                      // 48
  }                                                                                                                  //
  if (sandbox.Script == null) {                                                                                      //
    logger.incoming.error('[Class "Script" not in Trigger', integration.name, ']');                                  //
    throw RocketChat.API.v1.failure('class-script-not-found');                                                       // 52
  }                                                                                                                  //
};                                                                                                                   // 5
                                                                                                                     //
Api = new Restivus({                                                                                                 // 55
  enableCors: true,                                                                                                  //
  apiPath: 'hooks/',                                                                                                 //
  auth: {                                                                                                            //
    user: function() {                                                                                               //
      var e, payloadIsWrapped, payloadKeys, ref, user;                                                               // 60
      payloadKeys = Object.keys(this.bodyParams);                                                                    //
      payloadIsWrapped = (((ref = this.bodyParams) != null ? ref.payload : void 0) != null) && payloadKeys.length === 1;
      if (payloadIsWrapped && this.request.headers['content-type'] === 'application/x-www-form-urlencoded') {        //
        try {                                                                                                        // 64
          this.bodyParams = JSON.parse(this.bodyParams.payload);                                                     //
        } catch (error) {                                                                                            //
          e = error;                                                                                                 //
          return {                                                                                                   // 67
            error: {                                                                                                 //
              statusCode: 400,                                                                                       //
              body: {                                                                                                //
                success: false,                                                                                      //
                error: e.message                                                                                     //
              }                                                                                                      //
            }                                                                                                        //
          };                                                                                                         //
        }                                                                                                            //
      }                                                                                                              //
      this.integration = RocketChat.models.Integrations.findOne({                                                    //
        _id: this.request.params.integrationId,                                                                      //
        token: decodeURIComponent(this.request.params.token)                                                         //
      });                                                                                                            //
      if (this.integration == null) {                                                                                //
        logger.incoming.info("Invalid integration id", this.request.params.integrationId, "or token", this.request.params.token);
        return;                                                                                                      // 83
      }                                                                                                              //
      user = RocketChat.models.Users.findOne({                                                                       //
        _id: this.integration.userId                                                                                 //
      });                                                                                                            //
      return {                                                                                                       // 88
        user: user                                                                                                   //
      };                                                                                                             //
    }                                                                                                                //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
createIntegration = function(options, user) {                                                                        // 91
  logger.incoming.info('Add integration', options.name);                                                             //
  logger.incoming.debug(options);                                                                                    //
  Meteor.runAsUser(user._id, (function(_this) {                                                                      //
    return function() {                                                                                              //
      switch (options['event']) {                                                                                    // 96
        case 'newMessageOnChannel':                                                                                  // 96
          if (options.data == null) {                                                                                //
            options.data = {};                                                                                       //
          }                                                                                                          //
          if ((options.data.channel_name != null) && options.data.channel_name.indexOf('#') === -1) {                //
            options.data.channel_name = '#' + options.data.channel_name;                                             //
          }                                                                                                          //
          return Meteor.call('addOutgoingIntegration', {                                                             //
            username: 'rocket.cat',                                                                                  //
            urls: [options.target_url],                                                                              //
            name: options.name,                                                                                      //
            channel: options.data.channel_name,                                                                      //
            triggerWords: options.data.trigger_words                                                                 //
          });                                                                                                        //
        case 'newMessageToUser':                                                                                     // 96
          if (options.data.username.indexOf('@') === -1) {                                                           //
            options.data.username = '@' + options.data.username;                                                     //
          }                                                                                                          //
          return Meteor.call('addOutgoingIntegration', {                                                             //
            username: 'rocket.cat',                                                                                  //
            urls: [options.target_url],                                                                              //
            name: options.name,                                                                                      //
            channel: options.data.username,                                                                          //
            triggerWords: options.data.trigger_words                                                                 //
          });                                                                                                        //
      }                                                                                                              // 96
    };                                                                                                               //
  })(this));                                                                                                         //
  return RocketChat.API.v1.success();                                                                                // 121
};                                                                                                                   // 91
                                                                                                                     //
removeIntegration = function(options, user) {                                                                        // 124
  var integrationToRemove;                                                                                           // 125
  logger.incoming.info('Remove integration');                                                                        //
  logger.incoming.debug(options);                                                                                    //
  integrationToRemove = RocketChat.models.Integrations.findOne({                                                     //
    urls: options.target_url                                                                                         //
  });                                                                                                                //
  Meteor.runAsUser(user._id, (function(_this) {                                                                      //
    return function() {                                                                                              //
      return Meteor.call('deleteOutgoingIntegration', integrationToRemove._id);                                      //
    };                                                                                                               //
  })(this));                                                                                                         //
  return RocketChat.API.v1.success();                                                                                // 132
};                                                                                                                   // 124
                                                                                                                     //
executeIntegrationRest = function() {                                                                                // 135
  var defaultValues, e, message, ref, ref1, request, result, sandbox, script;                                        // 136
  logger.incoming.info('Post integration', this.integration.name);                                                   //
  logger.incoming.debug('@urlParams', this.urlParams);                                                               //
  logger.incoming.debug('@bodyParams', this.bodyParams);                                                             //
  if (this.integration.enabled !== true) {                                                                           //
    return {                                                                                                         // 141
      statusCode: 503,                                                                                               //
      body: 'Service Unavailable'                                                                                    //
    };                                                                                                               //
  }                                                                                                                  //
  defaultValues = {                                                                                                  //
    channel: this.integration.channel,                                                                               //
    alias: this.integration.alias,                                                                                   //
    avatar: this.integration.avatar,                                                                                 //
    emoji: this.integration.emoji                                                                                    //
  };                                                                                                                 //
  if (this.integration.scriptEnabled === true && (this.integration.scriptCompiled != null) && this.integration.scriptCompiled.trim() !== '') {
    script = void 0;                                                                                                 //
    try {                                                                                                            // 154
      script = getIntegrationScript(this.integration);                                                               //
    } catch (error) {                                                                                                //
      e = error;                                                                                                     //
      return e;                                                                                                      // 157
    }                                                                                                                //
    request = {                                                                                                      //
      url: {                                                                                                         //
        hash: this.request._parsedUrl.hash,                                                                          //
        search: this.request._parsedUrl.search,                                                                      //
        query: this.queryParams,                                                                                     //
        pathname: this.request._parsedUrl.pathname,                                                                  //
        path: this.request._parsedUrl.path                                                                           //
      },                                                                                                             //
      url_raw: this.request.url,                                                                                     //
      url_params: this.urlParams,                                                                                    //
      content: this.bodyParams,                                                                                      //
      content_raw: (ref = this.request._readableState) != null ? (ref1 = ref.buffer) != null ? ref1.toString() : void 0 : void 0,
      headers: this.request.headers,                                                                                 //
      user: {                                                                                                        //
        _id: this.user._id,                                                                                          //
        name: this.user.name,                                                                                        //
        username: this.user.username                                                                                 //
      }                                                                                                              //
    };                                                                                                               //
    try {                                                                                                            // 176
      sandbox = {                                                                                                    //
        _: _,                                                                                                        //
        s: s,                                                                                                        //
        console: console,                                                                                            //
        Store: {                                                                                                     //
          set: function(key, val) {                                                                                  //
            return store[key] = val;                                                                                 // 183
          },                                                                                                         //
          get: function(key) {                                                                                       //
            return store[key];                                                                                       // 185
          }                                                                                                          //
        },                                                                                                           //
        HTTP: function(method, url, options) {                                                                       //
          try {                                                                                                      // 187
            return {                                                                                                 // 188
              result: HTTP.call(method, url, options)                                                                //
            };                                                                                                       //
          } catch (error) {                                                                                          //
            e = error;                                                                                               //
            return {                                                                                                 // 191
              error: e                                                                                               //
            };                                                                                                       //
          }                                                                                                          //
        },                                                                                                           //
        script: script,                                                                                              //
        request: request                                                                                             //
      };                                                                                                             //
      result = vm.runInNewContext('script.process_incoming_request({ request: request })', sandbox, {                //
        timeout: 3000                                                                                                //
      });                                                                                                            //
      if ((result != null ? result.error : void 0) != null) {                                                        //
        return RocketChat.API.v1.failure(result.error);                                                              // 198
      }                                                                                                              //
      this.bodyParams = result != null ? result.content : void 0;                                                    //
      logger.incoming.debug('[Process Incoming Request result of Trigger', this.integration.name, ':]');             //
      logger.incoming.debug('result', this.bodyParams);                                                              //
    } catch (error) {                                                                                                //
      e = error;                                                                                                     //
      logger.incoming.error('[Error running Script in Trigger', this.integration.name, ':]');                        //
      logger.incoming.error(this.integration.scriptCompiled.replace(/^/gm, '  '));                                   //
      logger.incoming.error("[Stack:]");                                                                             //
      logger.incoming.error(e.stack.replace(/^/gm, '  '));                                                           //
      return RocketChat.API.v1.failure('error-running-script');                                                      // 209
    }                                                                                                                //
  }                                                                                                                  //
  if (this.bodyParams == null) {                                                                                     //
    return RocketChat.API.v1.failure('body-empty');                                                                  // 212
  }                                                                                                                  //
  this.bodyParams.bot = {                                                                                            //
    i: this.integration._id                                                                                          //
  };                                                                                                                 //
  try {                                                                                                              // 217
    message = processWebhookMessage(this.bodyParams, this.user, defaultValues);                                      //
    if (_.isEmpty(message)) {                                                                                        //
      return RocketChat.API.v1.failure('unknown-error');                                                             // 221
    }                                                                                                                //
    return RocketChat.API.v1.success();                                                                              // 223
  } catch (error) {                                                                                                  //
    e = error;                                                                                                       //
    return RocketChat.API.v1.failure(e.error);                                                                       // 225
  }                                                                                                                  //
};                                                                                                                   // 135
                                                                                                                     //
addIntegrationRest = function() {                                                                                    // 228
  return createIntegration(this.bodyParams, this.user);                                                              // 229
};                                                                                                                   // 228
                                                                                                                     //
removeIntegrationRest = function() {                                                                                 // 232
  return removeIntegration(this.bodyParams, this.user);                                                              // 233
};                                                                                                                   // 232
                                                                                                                     //
integrationSampleRest = function() {                                                                                 // 236
  logger.incoming.info('Sample Integration');                                                                        //
  return {                                                                                                           // 239
    statusCode: 200,                                                                                                 //
    body: [                                                                                                          //
      {                                                                                                              //
        token: Random.id(24),                                                                                        //
        channel_id: Random.id(),                                                                                     //
        channel_name: 'general',                                                                                     //
        timestamp: new Date,                                                                                         //
        user_id: Random.id(),                                                                                        //
        user_name: 'rocket.cat',                                                                                     //
        text: 'Sample text 1',                                                                                       //
        trigger_word: 'Sample'                                                                                       //
      }, {                                                                                                           //
        token: Random.id(24),                                                                                        //
        channel_id: Random.id(),                                                                                     //
        channel_name: 'general',                                                                                     //
        timestamp: new Date,                                                                                         //
        user_id: Random.id(),                                                                                        //
        user_name: 'rocket.cat',                                                                                     //
        text: 'Sample text 2',                                                                                       //
        trigger_word: 'Sample'                                                                                       //
      }, {                                                                                                           //
        token: Random.id(24),                                                                                        //
        channel_id: Random.id(),                                                                                     //
        channel_name: 'general',                                                                                     //
        timestamp: new Date,                                                                                         //
        user_id: Random.id(),                                                                                        //
        user_name: 'rocket.cat',                                                                                     //
        text: 'Sample text 3',                                                                                       //
        trigger_word: 'Sample'                                                                                       //
      }                                                                                                              //
    ]                                                                                                                //
  };                                                                                                                 //
};                                                                                                                   // 236
                                                                                                                     //
integrationInfoRest = function() {                                                                                   // 271
  logger.incoming.info('Info integration');                                                                          //
  return {                                                                                                           // 274
    statusCode: 200,                                                                                                 //
    body: {                                                                                                          //
      success: true                                                                                                  //
    }                                                                                                                //
  };                                                                                                                 //
};                                                                                                                   // 271
                                                                                                                     //
Api.addRoute(':integrationId/:userId/:token', {                                                                      // 279
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  post: executeIntegrationRest,                                                                                      //
  get: executeIntegrationRest                                                                                        //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute(':integrationId/:token', {                                                                              // 280
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  post: executeIntegrationRest,                                                                                      //
  get: executeIntegrationRest                                                                                        //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('sample/:integrationId/:userId/:token', {                                                               // 282
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  get: integrationSampleRest                                                                                         //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('sample/:integrationId/:token', {                                                                       // 283
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  get: integrationSampleRest                                                                                         //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('info/:integrationId/:userId/:token', {                                                                 // 285
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  get: integrationInfoRest                                                                                           //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('info/:integrationId/:token', {                                                                         // 286
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  get: integrationInfoRest                                                                                           //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('add/:integrationId/:userId/:token', {                                                                  // 288
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  post: addIntegrationRest                                                                                           //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('add/:integrationId/:token', {                                                                          // 289
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  post: addIntegrationRest                                                                                           //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('remove/:integrationId/:userId/:token', {                                                               // 291
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  post: removeIntegrationRest                                                                                        //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('remove/:integrationId/:token', {                                                                       // 292
  authRequired: true                                                                                                 //
}, {                                                                                                                 //
  post: removeIntegrationRest                                                                                        //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"triggers.coffee.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/triggers.coffee.js                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ExecuteTrigger, ExecuteTriggerUrl, ExecuteTriggers, addIntegration, compiledScripts, executeScript, getIntegrationScript, hasScriptAndMethod, removeIntegration, triggers, vm;
                                                                                                                     //
vm = Npm.require('vm');                                                                                              // 1
                                                                                                                     //
compiledScripts = {};                                                                                                // 3
                                                                                                                     //
getIntegrationScript = function(integration) {                                                                       // 5
  var compiledScript, e, sandbox, script, store, vmScript;                                                           // 6
  compiledScript = compiledScripts[integration._id];                                                                 //
  if ((compiledScript != null) && +compiledScript._updatedAt === +integration._updatedAt) {                          //
    return compiledScript.script;                                                                                    // 8
  }                                                                                                                  //
  script = integration.scriptCompiled;                                                                               //
  vmScript = void 0;                                                                                                 //
  store = {};                                                                                                        //
  sandbox = {                                                                                                        //
    _: _,                                                                                                            //
    s: s,                                                                                                            //
    console: console,                                                                                                //
    Store: {                                                                                                         //
      set: function(key, val) {                                                                                      //
        return store[key] = val;                                                                                     // 19
      },                                                                                                             //
      get: function(key) {                                                                                           //
        return store[key];                                                                                           // 21
      }                                                                                                              //
    },                                                                                                               //
    HTTP: function(method, url, options) {                                                                           //
      var e;                                                                                                         // 23
      try {                                                                                                          // 23
        return {                                                                                                     // 24
          result: HTTP.call(method, url, options)                                                                    //
        };                                                                                                           //
      } catch (error1) {                                                                                             //
        e = error1;                                                                                                  //
        return {                                                                                                     // 27
          error: e                                                                                                   //
        };                                                                                                           //
      }                                                                                                              //
    }                                                                                                                //
  };                                                                                                                 //
  try {                                                                                                              // 30
    logger.outgoing.info('Will evaluate script of Trigger', integration.name);                                       //
    logger.outgoing.debug(script);                                                                                   //
    vmScript = vm.createScript(script, 'script.js');                                                                 //
    vmScript.runInNewContext(sandbox);                                                                               //
    if (sandbox.Script != null) {                                                                                    //
      compiledScripts[integration._id] = {                                                                           //
        script: new sandbox.Script(),                                                                                //
        _updatedAt: integration._updatedAt                                                                           //
      };                                                                                                             //
      return compiledScripts[integration._id].script;                                                                // 43
    }                                                                                                                //
  } catch (error1) {                                                                                                 //
    e = error1;                                                                                                      //
    logger.outgoing.error('[Error evaluating Script in Trigger', integration.name, ':]');                            //
    logger.outgoing.error(script.replace(/^/gm, '  '));                                                              //
    logger.outgoing.error("[Stack:]");                                                                               //
    logger.outgoing.error(e.stack.replace(/^/gm, '  '));                                                             //
    throw new Meteor.Error('error-evaluating-script');                                                               // 49
  }                                                                                                                  //
  if (sandbox.Script == null) {                                                                                      //
    logger.outgoing.error('[Class "Script" not in Trigger', integration.name, ']');                                  //
    throw new Meteor.Error('class-script-not-found');                                                                // 53
  }                                                                                                                  //
};                                                                                                                   // 5
                                                                                                                     //
triggers = {};                                                                                                       // 56
                                                                                                                     //
hasScriptAndMethod = function(integration, method) {                                                                 // 58
  var e, script;                                                                                                     // 59
  if (integration.scriptEnabled !== true || (integration.scriptCompiled == null) || integration.scriptCompiled.trim() === '') {
    return false;                                                                                                    // 60
  }                                                                                                                  //
  script = void 0;                                                                                                   //
  try {                                                                                                              // 63
    script = getIntegrationScript(integration);                                                                      //
  } catch (error1) {                                                                                                 //
    e = error1;                                                                                                      //
    return;                                                                                                          // 66
  }                                                                                                                  //
  return script[method] != null;                                                                                     // 68
};                                                                                                                   // 58
                                                                                                                     //
executeScript = function(integration, method, params) {                                                              // 70
  var e, result, sandbox, script;                                                                                    // 71
  script = void 0;                                                                                                   //
  try {                                                                                                              // 72
    script = getIntegrationScript(integration);                                                                      //
  } catch (error1) {                                                                                                 //
    e = error1;                                                                                                      //
    return;                                                                                                          // 75
  }                                                                                                                  //
  if (script[method] == null) {                                                                                      //
    logger.outgoing.error('[Method "', method, '" not found in Trigger', integration.name, ']');                     //
    return;                                                                                                          // 79
  }                                                                                                                  //
  try {                                                                                                              // 81
    sandbox = {                                                                                                      //
      _: _,                                                                                                          //
      s: s,                                                                                                          //
      console: console,                                                                                              //
      Store: {                                                                                                       //
        set: function(key, val) {                                                                                    //
          return store[key] = val;                                                                                   // 88
        },                                                                                                           //
        get: function(key) {                                                                                         //
          return store[key];                                                                                         // 90
        }                                                                                                            //
      },                                                                                                             //
      HTTP: function(method, url, options) {                                                                         //
        try {                                                                                                        // 92
          return {                                                                                                   // 93
            result: HTTP.call(method, url, options)                                                                  //
          };                                                                                                         //
        } catch (error1) {                                                                                           //
          e = error1;                                                                                                //
          return {                                                                                                   // 96
            error: e                                                                                                 //
          };                                                                                                         //
        }                                                                                                            //
      },                                                                                                             //
      script: script,                                                                                                //
      method: method,                                                                                                //
      params: params                                                                                                 //
    };                                                                                                               //
    result = vm.runInNewContext('script[method](params)', sandbox, {                                                 //
      timeout: 3000                                                                                                  //
    });                                                                                                              //
    logger.outgoing.debug('[Script method [', method, '] result of Trigger', integration.name, ':]');                //
    logger.outgoing.debug(result);                                                                                   //
    return result;                                                                                                   // 106
  } catch (error1) {                                                                                                 //
    e = error1;                                                                                                      //
    logger.outgoing.error('[Error running Script in Trigger', integration.name, ':]');                               //
    logger.outgoing.error(integration.scriptCompiled.replace(/^/gm, '  '));                                          //
    logger.outgoing.error("[Stack:]");                                                                               //
    logger.outgoing.error(e.stack.replace(/^/gm, '  '));                                                             //
  }                                                                                                                  //
};                                                                                                                   // 70
                                                                                                                     //
addIntegration = function(record) {                                                                                  // 115
  var channel, channels, i, len, results;                                                                            // 116
  if (_.isEmpty(record.channel)) {                                                                                   //
    channels = ['__any'];                                                                                            //
  } else {                                                                                                           //
    channels = [].concat(record.channel);                                                                            //
  }                                                                                                                  //
  results = [];                                                                                                      // 121
  for (i = 0, len = channels.length; i < len; i++) {                                                                 //
    channel = channels[i];                                                                                           //
    if (triggers[channel] == null) {                                                                                 //
      triggers[channel] = {};                                                                                        //
    }                                                                                                                //
    results.push(triggers[channel][record._id] = record);                                                            //
  }                                                                                                                  // 121
  return results;                                                                                                    //
};                                                                                                                   // 115
                                                                                                                     //
removeIntegration = function(record) {                                                                               // 125
  var channel, results, trigger;                                                                                     // 126
  results = [];                                                                                                      // 126
  for (channel in triggers) {                                                                                        //
    trigger = triggers[channel];                                                                                     //
    results.push(delete trigger[record._id]);                                                                        //
  }                                                                                                                  // 126
  return results;                                                                                                    //
};                                                                                                                   // 125
                                                                                                                     //
RocketChat.models.Integrations.find({                                                                                // 129
  type: 'webhook-outgoing'                                                                                           //
}).observe({                                                                                                         //
  added: function(record) {                                                                                          //
    return addIntegration(record);                                                                                   //
  },                                                                                                                 //
  changed: function(record) {                                                                                        //
    removeIntegration(record);                                                                                       //
    return addIntegration(record);                                                                                   //
  },                                                                                                                 //
  removed: function(record) {                                                                                        //
    return removeIntegration(record);                                                                                //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
ExecuteTriggerUrl = function(url, trigger, message, room, tries) {                                                   // 141
  var data, i, len, opts, ref, ref1, sandbox, sendMessage, triggerWord, word;                                        // 142
  if (tries == null) {                                                                                               //
    tries = 0;                                                                                                       //
  }                                                                                                                  //
  word = void 0;                                                                                                     //
  if (((ref = trigger.triggerWords) != null ? ref.length : void 0) > 0) {                                            //
    ref1 = trigger.triggerWords;                                                                                     // 144
    for (i = 0, len = ref1.length; i < len; i++) {                                                                   // 144
      triggerWord = ref1[i];                                                                                         //
      if (message.msg.indexOf(triggerWord) === 0) {                                                                  //
        word = triggerWord;                                                                                          //
        break;                                                                                                       // 147
      }                                                                                                              //
    }                                                                                                                // 144
    if (word == null) {                                                                                              //
      return;                                                                                                        // 151
    }                                                                                                                //
  }                                                                                                                  //
  data = {                                                                                                           //
    message_id: message._id,                                                                                         //
    token: trigger.token,                                                                                            //
    channel_id: room._id,                                                                                            //
    channel_name: room.name,                                                                                         //
    timestamp: message.ts,                                                                                           //
    user_id: message.u._id,                                                                                          //
    user_name: message.u.username,                                                                                   //
    text: message.msg                                                                                                //
  };                                                                                                                 //
  if (message.alias != null) {                                                                                       //
    data.alias = message.alias;                                                                                      //
  }                                                                                                                  //
  if (message.bot != null) {                                                                                         //
    data.bot = message.bot;                                                                                          //
  } else {                                                                                                           //
    data.bot = false;                                                                                                //
  }                                                                                                                  //
  if (word != null) {                                                                                                //
    data.trigger_word = word;                                                                                        //
  }                                                                                                                  //
  logger.outgoing.info('Will execute trigger', trigger.name, 'to', url);                                             //
  logger.outgoing.debug(data);                                                                                       //
  sendMessage = function(message) {                                                                                  //
    var defaultValues, ref2, user;                                                                                   // 178
    if ((ref2 = trigger.impersonateUser) != null ? ref2 : false) {                                                   //
      user = RocketChat.models.Users.findOneByUsername(data.user_name);                                              //
    } else {                                                                                                         //
      user = RocketChat.models.Users.findOneByUsername(trigger.username);                                            //
    }                                                                                                                //
    message.bot = {                                                                                                  //
      i: trigger._id                                                                                                 //
    };                                                                                                               //
    defaultValues = {                                                                                                //
      alias: trigger.alias,                                                                                          //
      avatar: trigger.avatar,                                                                                        //
      emoji: trigger.emoji                                                                                           //
    };                                                                                                               //
    if (room.t === 'd') {                                                                                            //
      message.channel = '@' + room._id;                                                                              //
    } else {                                                                                                         //
      message.channel = '#' + room._id;                                                                              //
    }                                                                                                                //
    return message = processWebhookMessage(message, user, defaultValues);                                            //
  };                                                                                                                 //
  opts = {                                                                                                           //
    params: {},                                                                                                      //
    method: 'POST',                                                                                                  //
    url: url,                                                                                                        //
    data: data,                                                                                                      //
    auth: void 0,                                                                                                    //
    npmRequestOptions: {                                                                                             //
      rejectUnauthorized: !RocketChat.settings.get('Allow_Invalid_SelfSigned_Certs'),                                //
      strictSSL: !RocketChat.settings.get('Allow_Invalid_SelfSigned_Certs')                                          //
    },                                                                                                               //
    headers: {                                                                                                       //
      'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'
    }                                                                                                                //
  };                                                                                                                 //
  if (hasScriptAndMethod(trigger, 'prepare_outgoing_request')) {                                                     //
    sandbox = {                                                                                                      //
      request: opts                                                                                                  //
    };                                                                                                               //
    opts = executeScript(trigger, 'prepare_outgoing_request', sandbox);                                              //
  }                                                                                                                  //
  if (opts == null) {                                                                                                //
    return;                                                                                                          // 218
  }                                                                                                                  //
  if (opts.message != null) {                                                                                        //
    sendMessage(opts.message);                                                                                       //
  }                                                                                                                  //
  if ((opts.url == null) || (opts.method == null)) {                                                                 //
    return;                                                                                                          // 224
  }                                                                                                                  //
  return HTTP.call(opts.method, opts.url, opts, function(error, result) {                                            //
    var ref2, ref3, ref4, ref5, scriptResult, waitTime;                                                              // 227
    if (result == null) {                                                                                            //
      logger.outgoing.info('Result for trigger', trigger.name, 'to', url, 'is empty');                               //
    } else {                                                                                                         //
      logger.outgoing.info('Status code for trigger', trigger.name, 'to', url, 'is', result.statusCode);             //
    }                                                                                                                //
    scriptResult = void 0;                                                                                           //
    if (hasScriptAndMethod(trigger, 'process_outgoing_response')) {                                                  //
      sandbox = {                                                                                                    //
        request: opts,                                                                                               //
        response: {                                                                                                  //
          error: error,                                                                                              //
          status_code: result.statusCode,                                                                            //
          content: result.data,                                                                                      //
          content_raw: result.content,                                                                               //
          headers: result.headers                                                                                    //
        }                                                                                                            //
      };                                                                                                             //
      scriptResult = executeScript(trigger, 'process_outgoing_response', sandbox);                                   //
      if (scriptResult != null ? scriptResult.content : void 0) {                                                    //
        sendMessage(scriptResult.content);                                                                           //
        return;                                                                                                      // 247
      }                                                                                                              //
      if (scriptResult === false) {                                                                                  //
        return;                                                                                                      // 250
      }                                                                                                              //
    }                                                                                                                //
    if ((result == null) || ((ref2 = result.statusCode) !== 200 && ref2 !== 201 && ref2 !== 202)) {                  //
      if (error != null) {                                                                                           //
        logger.outgoing.error('Error for trigger', trigger.name, 'to', url, error);                                  //
      }                                                                                                              //
      if (result != null) {                                                                                          //
        logger.outgoing.error('Error for trigger', trigger.name, 'to', url, result);                                 //
        if (result.statusCode === 410) {                                                                             //
          RocketChat.models.Integrations.remove({                                                                    //
            _id: trigger._id                                                                                         //
          });                                                                                                        //
          return;                                                                                                    // 260
        }                                                                                                            //
        if (result.statusCode === 500) {                                                                             //
          logger.outgoing.error('Error [500] for trigger', trigger.name, 'to', url);                                 //
          logger.outgoing.error(result.content);                                                                     //
          return;                                                                                                    // 265
        }                                                                                                            //
      }                                                                                                              //
      if (tries <= 6) {                                                                                              //
        waitTime = Math.pow(10, tries + 2);                                                                          //
        logger.outgoing.info('Trying trigger', trigger.name, 'to', url, 'again in', waitTime, 'seconds');            //
        Meteor.setTimeout(function() {                                                                               //
          return ExecuteTriggerUrl(url, trigger, message, room, tries + 1);                                          //
        }, waitTime);                                                                                                //
      }                                                                                                              //
      return;                                                                                                        // 275
    }                                                                                                                //
    if ((ref3 = result != null ? result.statusCode : void 0) === 200 || ref3 === 201 || ref3 === 202) {              //
      if (((result != null ? (ref4 = result.data) != null ? ref4.text : void 0 : void 0) != null) || ((result != null ? (ref5 = result.data) != null ? ref5.attachments : void 0 : void 0) != null)) {
        return sendMessage(result.data);                                                                             //
      }                                                                                                              //
    }                                                                                                                //
  });                                                                                                                //
};                                                                                                                   // 141
                                                                                                                     //
ExecuteTrigger = function(trigger, message, room) {                                                                  // 283
  var i, len, ref, results, url;                                                                                     // 284
  ref = trigger.urls;                                                                                                // 284
  results = [];                                                                                                      // 284
  for (i = 0, len = ref.length; i < len; i++) {                                                                      //
    url = ref[i];                                                                                                    //
    results.push(ExecuteTriggerUrl(url, trigger, message, room));                                                    //
  }                                                                                                                  // 284
  return results;                                                                                                    //
};                                                                                                                   // 283
                                                                                                                     //
ExecuteTriggers = function(message, room) {                                                                          // 288
  var i, id, key, len, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, trigger, triggerToExecute, triggersToExecute, username;
  if (room == null) {                                                                                                //
    return;                                                                                                          // 290
  }                                                                                                                  //
  triggersToExecute = [];                                                                                            //
  switch (room.t) {                                                                                                  // 294
    case 'd':                                                                                                        // 294
      id = room._id.replace(message.u._id, '');                                                                      //
      username = _.without(room.usernames, message.u.username);                                                      //
      username = username[0];                                                                                        //
      if (triggers['@' + id] != null) {                                                                              //
        ref = triggers['@' + id];                                                                                    // 302
        for (key in ref) {                                                                                           // 302
          trigger = ref[key];                                                                                        //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 302
      }                                                                                                              //
      if (triggers.all_direct_messages != null) {                                                                    //
        ref1 = triggers.all_direct_messages;                                                                         // 305
        for (key in ref1) {                                                                                          // 305
          trigger = ref1[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 305
      }                                                                                                              //
      if (id !== username && (triggers['@' + username] != null)) {                                                   //
        ref2 = triggers['@' + username];                                                                             // 308
        for (key in ref2) {                                                                                          // 308
          trigger = ref2[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 308
      }                                                                                                              //
      break;                                                                                                         // 295
    case 'c':                                                                                                        // 294
      if (triggers.__any != null) {                                                                                  //
        ref3 = triggers.__any;                                                                                       // 312
        for (key in ref3) {                                                                                          // 312
          trigger = ref3[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 312
      }                                                                                                              //
      if (triggers.all_public_channels != null) {                                                                    //
        ref4 = triggers.all_public_channels;                                                                         // 315
        for (key in ref4) {                                                                                          // 315
          trigger = ref4[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 315
      }                                                                                                              //
      if (triggers['#' + room._id] != null) {                                                                        //
        ref5 = triggers['#' + room._id];                                                                             // 318
        for (key in ref5) {                                                                                          // 318
          trigger = ref5[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 318
      }                                                                                                              //
      if (room._id !== room.name && (triggers['#' + room.name] != null)) {                                           //
        ref6 = triggers['#' + room.name];                                                                            // 321
        for (key in ref6) {                                                                                          // 321
          trigger = ref6[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 321
      }                                                                                                              //
      break;                                                                                                         // 310
    default:                                                                                                         // 294
      if (triggers.all_private_groups != null) {                                                                     //
        ref7 = triggers.all_private_groups;                                                                          // 325
        for (key in ref7) {                                                                                          // 325
          trigger = ref7[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 325
      }                                                                                                              //
      if (triggers['#' + room._id] != null) {                                                                        //
        ref8 = triggers['#' + room._id];                                                                             // 328
        for (key in ref8) {                                                                                          // 328
          trigger = ref8[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 328
      }                                                                                                              //
      if (room._id !== room.name && (triggers['#' + room.name] != null)) {                                           //
        ref9 = triggers['#' + room.name];                                                                            // 331
        for (key in ref9) {                                                                                          // 331
          trigger = ref9[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           //
        }                                                                                                            // 331
      }                                                                                                              //
  }                                                                                                                  // 294
  for (i = 0, len = triggersToExecute.length; i < len; i++) {                                                        // 334
    triggerToExecute = triggersToExecute[i];                                                                         //
    if (triggerToExecute.enabled === true) {                                                                         //
      ExecuteTrigger(triggerToExecute, message, room);                                                               //
    }                                                                                                                //
  }                                                                                                                  // 334
  return message;                                                                                                    // 338
};                                                                                                                   // 288
                                                                                                                     //
RocketChat.callbacks.add('afterSaveMessage', ExecuteTriggers, RocketChat.callbacks.priority.LOW, 'ExecuteTriggers');
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"processWebhookMessage.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/processWebhookMessage.js                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
function retrieveRoomInfo(_ref) {                                                                                    // 1
	var currentUserId = _ref.currentUserId;                                                                             // 1
	var channel = _ref.channel;                                                                                         // 1
	var _ref$ignoreEmpty = _ref.ignoreEmpty;                                                                            // 1
	var ignoreEmpty = _ref$ignoreEmpty === undefined ? false : _ref$ignoreEmpty;                                        // 1
                                                                                                                     //
	var room = RocketChat.models.Rooms.findOneByIdOrName(channel);                                                      // 2
	if (!_.isObject(room) && !ignoreEmpty) {                                                                            // 3
		throw new Meteor.Error('invalid-channel');                                                                         // 4
	}                                                                                                                   // 5
                                                                                                                     //
	if (room && room.t === 'c') {                                                                                       // 7
		//Check if the user already has a Subscription or not, this avoids this issue: https://github.com/RocketChat/Rocket.Chat/issues/5477
		var sub = RocketChat.models.Subscriptions.findOneByRoomIdAndUserId(room._id, currentUserId);                       // 9
                                                                                                                     //
		if (!sub) {                                                                                                        // 11
			Meteor.runAsUser(currentUserId, function () {                                                                     // 12
				return Meteor.call('joinRoom', room._id);                                                                        // 13
			});                                                                                                               // 14
		}                                                                                                                  // 15
	}                                                                                                                   // 16
                                                                                                                     //
	return room;                                                                                                        // 18
}                                                                                                                    // 19
                                                                                                                     //
function retrieveDirectMessageInfo(_ref2) {                                                                          // 21
	var currentUserId = _ref2.currentUserId;                                                                            // 21
	var channel = _ref2.channel;                                                                                        // 21
	var _ref2$findByUserIdOnl = _ref2.findByUserIdOnly;                                                                 // 21
	var findByUserIdOnly = _ref2$findByUserIdOnl === undefined ? false : _ref2$findByUserIdOnl;                         // 21
                                                                                                                     //
	var roomUser = undefined;                                                                                           // 22
                                                                                                                     //
	if (findByUserIdOnly) {                                                                                             // 24
		roomUser = RocketChat.models.Users.findOneById(channel);                                                           // 25
	} else {                                                                                                            // 26
		roomUser = RocketChat.models.Users.findOne({                                                                       // 27
			$or: [{ _id: channel }, { username: channel }]                                                                    // 28
		});                                                                                                                // 27
	}                                                                                                                   // 30
                                                                                                                     //
	var rid = _.isObject(roomUser) ? [currentUserId, roomUser._id].sort().join('') : channel;                           // 32
	var room = RocketChat.models.Rooms.findOneById(rid);                                                                // 33
                                                                                                                     //
	if (!_.isObject(room)) {                                                                                            // 35
		if (!_.isObject(roomUser)) {                                                                                       // 36
			throw new Meteor.Error('invalid-channel');                                                                        // 37
		}                                                                                                                  // 38
                                                                                                                     //
		room = Meteor.runAsUser(currentUserId, function () {                                                               // 40
			var _Meteor$call = Meteor.call('createDirectMessage', roomUser.username);                                         // 40
                                                                                                                     //
			var rid = _Meteor$call.rid;                                                                                       // 40
                                                                                                                     //
			return RocketChat.models.Rooms.findOneById(rid);                                                                  // 42
		});                                                                                                                // 43
	}                                                                                                                   // 44
                                                                                                                     //
	return room;                                                                                                        // 46
}                                                                                                                    // 47
                                                                                                                     //
this.processWebhookMessage = function (messageObj, user, defaultValues) {                                            // 49
	var attachment, channel, channels, channelType, i, len, message, ref, room, ret;                                    // 50
	ret = [];                                                                                                           // 51
                                                                                                                     //
	if (!defaultValues) {                                                                                               // 53
		defaultValues = {                                                                                                  // 54
			channel: '',                                                                                                      // 55
			alias: '',                                                                                                        // 56
			avatar: '',                                                                                                       // 57
			emoji: ''                                                                                                         // 58
		};                                                                                                                 // 54
	}                                                                                                                   // 60
                                                                                                                     //
	channel = messageObj.channel || messageObj.roomId || defaultValues.channel;                                         // 62
                                                                                                                     //
	channels = [].concat(channel);                                                                                      // 64
                                                                                                                     //
	for (var _iterator = channels, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
		if (_isArray) {                                                                                                    // 66
			if (_i >= _iterator.length) break;                                                                                // 66
			channel = _iterator[_i++];                                                                                        // 66
		} else {                                                                                                           // 66
			_i = _iterator.next();                                                                                            // 66
			if (_i.done) break;                                                                                               // 66
			channel = _i.value;                                                                                               // 66
		}                                                                                                                  // 66
                                                                                                                     //
		channelType = channel[0];                                                                                          // 67
                                                                                                                     //
		channel = channel.substr(1);                                                                                       // 69
                                                                                                                     //
		switch (channelType) {                                                                                             // 71
			case '#':                                                                                                         // 72
				room = retrieveRoomInfo({ currentUserId: user._id, channel: channel });                                          // 73
				break;                                                                                                           // 74
			case '@':                                                                                                         // 75
				room = retrieveDirectMessageInfo({ currentUserId: user._id, channel: channel });                                 // 76
				break;                                                                                                           // 77
			default:                                                                                                          // 78
				channel = channelType + channel;                                                                                 // 79
                                                                                                                     //
				//Try to find the room by id or name if they didn't include the prefix.                                          // 81
				room = retrieveRoomInfo({ currentUserId: user._id, channel: channel, ignoreEmpty: true });                       // 82
				if (room) {                                                                                                      // 83
					break;                                                                                                          // 84
				}                                                                                                                // 85
                                                                                                                     //
				//We didn't get a room, let's try finding direct messages                                                        // 87
				room = retrieveDirectMessageInfo({ currentUserId: user._id, channel: channel, findByUserIdOnly: true });         // 88
				if (room) {                                                                                                      // 89
					break;                                                                                                          // 90
				}                                                                                                                // 91
                                                                                                                     //
				//No room, so throw an error                                                                                     // 93
				throw new Meteor.Error('invalid-channel');                                                                       // 94
		}                                                                                                                  // 71
                                                                                                                     //
		if (messageObj.attachments && !_.isArray(messageObj.attachments)) {                                                // 97
			console.log('Attachments should be Array, ignoring value'.red, messageObj.attachments);                           // 98
			messageObj.attachments = undefined;                                                                               // 99
		}                                                                                                                  // 100
                                                                                                                     //
		message = {                                                                                                        // 102
			alias: messageObj.username || messageObj.alias || defaultValues.alias,                                            // 103
			msg: _.trim(messageObj.text || messageObj.msg || ''),                                                             // 104
			attachments: messageObj.attachments,                                                                              // 105
			parseUrls: messageObj.parseUrls !== undefined ? messageObj.parseUrls : !messageObj.attachments,                   // 106
			bot: messageObj.bot,                                                                                              // 107
			groupable: messageObj.groupable !== undefined ? messageObj.groupable : false                                      // 108
		};                                                                                                                 // 102
                                                                                                                     //
		if (!_.isEmpty(messageObj.icon_url) || !_.isEmpty(messageObj.avatar)) {                                            // 111
			message.avatar = messageObj.icon_url || messageObj.avatar;                                                        // 112
		} else if (!_.isEmpty(messageObj.icon_emoji) || !_.isEmpty(messageObj.emoji)) {                                    // 113
			message.emoji = messageObj.icon_emoji || messageObj.emoji;                                                        // 114
		} else if (!_.isEmpty(defaultValues.avatar)) {                                                                     // 115
			message.avatar = defaultValues.avatar;                                                                            // 116
		} else if (!_.isEmpty(defaultValues.emoji)) {                                                                      // 117
			message.emoji = defaultValues.emoji;                                                                              // 118
		}                                                                                                                  // 119
                                                                                                                     //
		if (_.isArray(message.attachments)) {                                                                              // 121
			ref = message.attachments;                                                                                        // 122
			for (i = 0, len = ref.length; i < len; i++) {                                                                     // 123
				attachment = ref[i];                                                                                             // 124
				if (attachment.msg) {                                                                                            // 125
					attachment.text = _.trim(attachment.msg);                                                                       // 126
					delete attachment.msg;                                                                                          // 127
				}                                                                                                                // 128
			}                                                                                                                 // 129
		}                                                                                                                  // 130
                                                                                                                     //
		var messageReturn = RocketChat.sendMessage(user, message, room);                                                   // 132
		ret.push({ channel: channel, message: messageReturn });                                                            // 133
	}                                                                                                                   // 134
	return ret;                                                                                                         // 135
};                                                                                                                   // 136
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{"extensions":[".js",".json",".coffee"]});
require("./node_modules/meteor/rocketchat:integrations/lib/rocketchat.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/logger.js");
require("./node_modules/meteor/rocketchat:integrations/server/lib/validation.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/models/Integrations.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/publications/integrations.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/methods/incoming/addIncomingIntegration.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/methods/incoming/updateIncomingIntegration.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/methods/incoming/deleteIncomingIntegration.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/methods/outgoing/addOutgoingIntegration.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/methods/outgoing/updateOutgoingIntegration.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/methods/outgoing/deleteOutgoingIntegration.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/api/api.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/triggers.coffee.js");
require("./node_modules/meteor/rocketchat:integrations/server/processWebhookMessage.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:integrations'] = {};

})();

//# sourceMappingURL=rocketchat_integrations.js.map
