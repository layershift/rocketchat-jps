(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:emoji-emojione'] = {};

})();
